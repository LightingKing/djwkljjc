"""Small, persistent local implementations for non-economy game systems.

The retired service exposed a large number of actor, equipment, card, mail,
relation and PVP endpoints.  This module keeps those seams usable for a local
guest without pretending to reproduce server data: state is deliberately
small, deterministic and stored in the existing game SQLite database.
"""

from __future__ import annotations

import json
import time
from contextlib import closing
from pathlib import Path
from typing import Any, Mapping, Optional
from urllib.parse import urlsplit

from google.protobuf import message_factory


Body = bytes | bytearray | str | None
Response = tuple[int, Any]


def _route(path: str) -> str:
    value = urlsplit(path or "").path or "/"
    return value.rstrip("/") or "/"


def _json(body: Body) -> dict[str, Any]:
    if body is None:
        return {}
    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return dict(value) if isinstance(value, Mapping) else {}


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


class LocalSystems:
    """Authenticated local actor/card/mail/relation/PVP compatibility layer."""

    def __init__(self, game: Any, *, clock=None) -> None:
        self.game = game
        self._lock = game._lock
        self._clock = clock or game._now
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS local_system_state (
                    account_id INTEGER PRIMARY KEY,
                    state_json TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )

    def _now(self) -> int:
        return int(self._clock())

    def _message(self, name: str):
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName(name))
        return cls()

    def _request(self, body: Body, name: str):
        raw = body.encode("utf-8") if isinstance(body, str) else bytes(body or b"")
        if not raw:
            return None
        try:
            msg = self._message(name)
            msg.ParseFromString(raw)
            return msg
        except Exception:
            return None

    @staticmethod
    def _default_state(profile: Mapping[str, Any]) -> dict[str, Any]:
        actor_ids = profile.get("actor_ids", [])
        if not isinstance(actor_ids, list) or not actor_ids:
            actor_ids = [profile.get("actor_id")] if profile.get("actor_id") else [1001]
        actors = {
            str(_int(actor_id)): {
                "id": _int(actor_id), "level": 1, "star": 1, "exp": 0,
                "quality": 1, "locked": False, "skin": 0,
                "skills": {}, "favourLevel": 1, "favourExp": 0,
            }
            for actor_id in actor_ids
            if _int(actor_id)
        }
        if not actors:
            actors = {"1001": {"id": 1001, "level": 1, "star": 1, "exp": 0,
                                "quality": 1, "locked": False, "skin": 0,
                                "skills": {}, "favourLevel": 1, "favourExp": 0}}
        return {
            "actors": actors,
            "equips": {},
            "items": {},
            "medals": {},
            "seals": {"cells": {}, "rewards": {}, "newOpenFlag": False},
            "cultivation": {},
            "gacha_count": 0,
            "gacha_records": [],
            "mails": [
                {
                    "id": 1,
                    "title": "本地测试邮件",
                    "content": "这是本地沙盒邮件，不来自官方服务器。",
                    "senderName": "Local Sandbox",
                    # A real attachment makes the local mail window exercise
                    # the same obtain -> resource refresh path as the game.
                    # It is deliberately a small sandbox grant and is never
                    # backed by a remote payment or official account.
                    "attachments": [{"type": 7, "id": 0, "count": 100, "param": 0}],
                    "read": False,
                    "attachmentsGot": False,
                }
            ],
            "friends": [],
            # Task rows are expanded by ``_normalise_tasks`` before they are
            # sent to the client.  Keep this compact seed for old databases
            # and make the normalizer the single source of schema defaults.
            "tasks": {"1": {"progress": 0, "maxProgress": 1, "rewardGot": False, "endTime": 0}},
            "taskTargetDone": [],
            "guild": None,
            # Player profile presentation state.  The retired playeraction
            # descriptor is damaged in the recovered APK, so these values
            # use a small JSON compatibility seam until a valid descriptor
            # is recovered.  They are still persisted per local account.
            "player_profile": {
                "socialPicture": "",
                "sex": 0,
                "headPhoto": 0,
                "fightMedal": 0,
                "presentTargetActor": 0,
                "friendApplyLevelLimit": 0,
                "homeBackGround": {"current": 0, "isRandom": False},
                "collections": {"actors": [], "equips": [], "novels": []},
                "novelCovers": [],
                "roleNotePad": {},
                "emojis": [],
            },
        }

    @staticmethod
    def _task_reward(value: Any) -> list[dict[str, int]]:
        """Return a JSON-safe local reward list with the STResource shape."""

        raw = value if isinstance(value, list) else []
        result: list[dict[str, int]] = []
        for item in raw:
            if not isinstance(item, Mapping):
                continue
            result.append(
                {
                    "type": _int(item.get("type")),
                    "id": _int(item.get("id")),
                    "count": _int(item.get("count")),
                    "param": _int(item.get("param")),
                }
            )
        return result or [{"type": 7, "id": 0, "count": 100, "param": 0}]

    def _normalise_task(self, key: Any, value: Any, now: int) -> dict[str, Any]:
        """Expand a stored task into the fields read by Common/TaskUtil.

        The original client dereferences ``task.res`` and several optional
        booleans before it renders the city task panel.  Historical local
        accounts only stored progress/reward state, so every read upgrades the
        row to this schema and persists it through ``_state``.
        """

        raw = dict(value) if isinstance(value, Mapping) else {}
        task_id = _int(raw.get("id"), _int(key, 1)) or 1
        max_progress = max(1, _int(raw.get("maxProgress", raw.get("max_progress", 1)), 1))
        progress = max(0, _int(raw.get("progress"), 0))
        reward_got = bool(raw.get("rewardGot", raw.get("reward_got", False)))
        is_done = bool(raw.get("isDone", raw.get("is_done", progress >= max_progress)))
        if progress >= max_progress:
            is_done = True
        # A finite future deadline keeps arithmetic in the native Lua client
        # defined while still behaving like a long-lived local task.
        end_time = _int(raw.get("endTime", raw.get("end_time", 0)), 0)
        if end_time <= now:
            end_time = now + 365 * 86400
        start_time = _int(raw.get("startTime", raw.get("start_time", now)), now)
        if start_time <= 0:
            start_time = now

        raw_res = raw.get("res")
        res = dict(raw_res) if isinstance(raw_res, Mapping) else {}
        reward = self._task_reward(res.get("reward", raw.get("reward")))
        # TaskInfo.xlsx's proto3 defaults are included explicitly.  This is
        # useful for Lua code that tests a field for nil rather than relying
        # on protobuf's implicit zero value.
        res_defaults: dict[str, Any] = {
            "id": task_id,
            "priority": 0,
            "goalType": 0,
            "maxProgress": max_progress,
            "taskParam": [],
            "reward": reward,
            "activePoint": 0,
            "preTaskId": 0,
            "gotoId": 0,
            "category": 1,
            "addFollowTask": False,
            "recordBeforeGot": False,
            "refreshAfterGot": False,
            "deleteAfterReward": False,
            "syncByServer": False,
            "life": 0,
            "series": 0,
            "checkWhenRefresh": False,
            "outstanding": False,
            "isActivity": False,
            "extraActivePointType": 0,
            "extraActivePoint": 0,
            "actorCultivationActivityId": 0,
            "actorCultivationRewardProgress": 0,
            "dailyRefresh": bool(raw.get("dailyRefresh", False)),
        }
        for field, default in res_defaults.items():
            res.setdefault(field, default)
        # Ensure values carried over from old JSON are scalar/list types the
        # client can safely consume.
        res["id"] = _int(res.get("id"), task_id)
        res["priority"] = _int(res.get("priority"))
        res["goalType"] = _int(res.get("goalType"))
        res["maxProgress"] = max_progress
        res["taskParam"] = [
            _int(item) for item in res.get("taskParam", [])
        ] if isinstance(res.get("taskParam"), list) else []
        res["reward"] = reward
        res["category"] = max(1, _int(res.get("category"), 1))

        task = dict(raw)
        task.update(
            {
                "id": task_id,
                "progress": progress,
                "maxProgress": max_progress,
                "rewardGot": reward_got,
                "isDone": is_done,
                "startTime": start_time,
                "endTime": end_time,
                "dailyRefresh": bool(raw.get("dailyRefresh", res.get("dailyRefresh", False))),
                "actorCultivationVipOnly": bool(raw.get("actorCultivationVipOnly", False)),
                "timeout": bool(raw.get("timeout", False)),
                "res": res,
                # Keep the legacy top-level reward/status fields for tooling
                # that used the early local JSON seam.
                "reward": reward,
                "status": 1 if is_done else 0,
            }
        )
        return task

    def _normalise_tasks(self, state: dict[str, Any]) -> bool:
        tasks = state.get("tasks")
        if not isinstance(tasks, Mapping):
            tasks = {"1": {"progress": 0, "maxProgress": 1, "rewardGot": False}}
        now = self._now()
        normalised: dict[str, dict[str, Any]] = {}
        for key, value in tasks.items():
            task = self._normalise_task(key, value, now)
            normalised[str(task["id"])] = task
        if not normalised:
            task = self._normalise_task("1", {}, now)
            normalised["1"] = task
        changed = normalised != tasks
        state["tasks"] = normalised
        return changed

    def _state(self, profile: Mapping[str, Any]) -> dict[str, Any]:
        account_id = int(profile["account_id"])
        with self._lock, closing(self.game._connect()) as connection, connection:
            row = connection.execute(
                "SELECT state_json FROM local_system_state WHERE account_id = ?", (account_id,)
            ).fetchone()
            if row is None:
                state = self._default_state(profile)
                self._normalise_tasks(state)
                connection.execute(
                    "INSERT OR IGNORE INTO local_system_state(account_id,state_json,updated_at) VALUES(?,?,?)",
                    (account_id, json.dumps(state, separators=(",", ":")), self._now()),
                )
                return state
            try:
                state = json.loads(row["state_json"] or "{}")
            except (TypeError, ValueError):
                state = {}
            defaults = self._default_state(profile)
            if not isinstance(state, dict):
                state = {}
            for key, value in defaults.items():
                state.setdefault(key, value)
            changed = self._normalise_tasks(state)
            if changed:
                connection.execute(
                    "UPDATE local_system_state SET state_json = ?, updated_at = ? WHERE account_id = ?",
                    (json.dumps(state, separators=(",", ":")), self._now(), account_id),
                )
            return state

    def _save(self, profile: Mapping[str, Any], state: Mapping[str, Any]) -> None:
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                "UPDATE local_system_state SET state_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(dict(state), separators=(",", ":")), self._now(), int(profile["account_id"])),
            )

    def _actor_message(self, actor: Mapping[str, Any]):
        result = self._message("ApiActor.result")
        result.result.id = _int(actor.get("id"))
        result.result.uid = _int(actor.get("id"))
        result.result.level = _int(actor.get("level"), 1)
        result.result.star = _int(actor.get("star"), 1)
        result.result.cur_exp = _int(actor.get("exp"))
        result.result.quality = _int(actor.get("quality"), 1)
        result.result.is_lock = bool(actor.get("locked", actor.get("isLock", False)))
        result.result.actor_skin = _int(actor.get("skin"))
        skills = actor.get("skills", {})
        if isinstance(skills, Mapping):
            for key, value in skills.items():
                skill = result.result.skills.add()
                skill.id = _int(key)
                if isinstance(value, Mapping):
                    skill.level = max(1, _int(value.get("level"), 1))
                    skill.is_read = bool(value.get("read", value.get("isRead", False)))
                else:
                    skill.level = max(1, _int(value, 1))
        return result

    def _resource_count(self, profile: Mapping[str, Any], resource: Mapping[str, Any]) -> int:
        """Read one resource balance from the game's canonical profile JSON."""
        rtype, rid, param = _int(resource.get("type")), _int(resource.get("id")), _int(resource.get("param"))
        for item in profile.get("resources", []):
            if isinstance(item, Mapping) and (_int(item.get("type")), _int(item.get("id")), _int(item.get("param"))) == (rtype, rid, param):
                return _int(item.get("count"))
        return 0

    def _change_resources(self, profile: Mapping[str, Any], changes: list[Mapping[str, Any]]) -> tuple[bool, list[dict[str, int]], str | None]:
        """Use LocalEconomy's canonical atomic resource mutation seam."""
        return self.game.economy._change_resources(profile, changes)

    def _dynamic(self, changes: list[Mapping[str, Any]]) -> list[dict[str, int]]:
        return [{"type": _int(x.get("type")), "id": _int(x.get("id")), "param": _int(x.get("param")),
                 "count": _int(x.get("count")), "countDelta": _int(x.get("countDelta"))} for x in changes]

    @staticmethod
    def _request_values(body: Body) -> dict[str, Any]:
        value = _json(body)
        # A few clients wrap JSON payloads under ``data``/``request``.
        for key in ("data", "request", "param"):
            if isinstance(value.get(key), Mapping):
                merged = dict(value)
                merged.update(value[key])
                value = merged
        return value

    @staticmethod
    def _first_int(value: Mapping[str, Any], *keys: str, default: int = 0) -> int:
        for key in keys:
            if key in value:
                return _int(value.get(key), default)
        return default

    def _actor(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        parts = [part for part in route.split("/") if part]
        actor_id = _int(_json(body).get("id"))
        if not actor_id:
            msg = self._request(body, "ApiActor")
            actor_id = _int(getattr(msg, "id", 0)) if msg is not None else 0
        if len(parts) >= 3 and parts[1].lower() == "actor" and parts[2].isdigit():
            actor_id = int(parts[2])
        actors = state.setdefault("actors", {})
        actor = actors.setdefault(str(actor_id or 1001), {"id": actor_id or 1001, "level": 1, "star": 1, "exp": 0,
                                                           "quality": 1, "locked": False, "skin": 0,
                                                           "skills": {}, "favourLevel": 1, "favourExp": 0})
        # Upgrade state created by older local versions in place.
        actor.setdefault("quality", 1); actor.setdefault("locked", False); actor.setdefault("skin", 0)
        actor.setdefault("skills", {}); actor.setdefault("favourLevel", 1); actor.setdefault("favourExp", 0)
        lower = route.lower()
        if lower in {"/fci/actor", "/fci/actor/"} and method == "GET":
            return 200, self._actor_message(actor)
        if lower.endswith("/levelup") or lower.endswith("/level-up"):
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = self._request(body, "ApiActorLevelUp")
            payload = self._request_values(body)
            delta = max(1, _int(payload.get("levels", payload.get("level", 1))))
            if request is not None and request.food_res:
                delta = max(delta, len(request.food_res))
            current = max(1, _int(actor.get("level"), 1)); target = min(60, current + delta)
            if target == current:
                return 409, {"error": "actor_level_max"}
            # The extracted ActorLevel table is incomplete.  These explicitly
            # local sandbox costs scale with the requested level and are kept
            # in the canonical resource ledger (type 7 = gold).
            cost = sum(100 * level for level in range(current, target))
            ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": -cost}])
            if not ok:
                return 409, {"error": error or "insufficient_resource", "required": cost}
            actor["level"] = target
            actor["exp"] = _int(actor.get("exp"))
            self._save(profile, state)
            result = self._message("ApiActorLevelUp.post")
            for change in self._dynamic(changes):
                entry = result.res_change.add(); entry.base_res.type = change["type"]; entry.base_res.id = change["id"]; entry.base_res.param = change["param"]; entry.base_res.count = change["count"]; entry.base_res.count_delta = change["countDelta"]
            return 200, result
        if lower.endswith("/starlevelup") or lower.endswith("/star-level-up"):
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            current = max(1, _int(actor.get("star"), 1)); target = min(6, current + 1)
            if target == current:
                return 409, {"error": "actor_star_max"}
            # Local actor shards use resource type 15 and the actor id.  This
            # makes the operation deterministic without inventing official
            # star tables that were not recovered from the APK.
            shard_cost = 2 * target
            shard_resource = {"type": 15, "id": actor_id, "param": 0, "count": -shard_cost}
            # Fresh local guests do not start with actor chips.  Allow the
            # first upgrade to use the starter gold balance as a deterministic
            # sandbox fallback; once chips exist they are consumed first.
            if self._resource_count(profile, {"type": 15, "id": actor_id, "param": 0}) >= shard_cost:
                payment = shard_resource
            else:
                payment = {"type": 7, "id": 0, "param": 0, "count": -(200 * target)}
            ok, changes, error = self._change_resources(profile, [payment])
            if not ok:
                return 409, {"error": error or "insufficient_resource", "required": shard_cost}
            actor["star"] = target
            self._save(profile, state)
            result = self._message("ApiActorStarLevelUp.post")
            for change in self._dynamic(changes):
                entry = result.res_change.add(); entry.base_res.type = change["type"]; entry.base_res.id = change["id"]; entry.base_res.param = change["param"]; entry.base_res.count = change["count"]; entry.base_res.count_delta = change["countDelta"]
            return 200, result
        if method in {"PATCH", "POST"} and lower.startswith("/fci/actor/"):
            request = self._request_values(body)
            # PATCH is a local administrative seam; preserve the existing
            # compatibility behavior while still normalizing new fields.
            actor["level"] = max(1, min(60, _int(request.get("level", actor.get("level", 1)))))
            actor["star"] = max(1, min(6, _int(request.get("star", actor.get("star", 1)))))
            if "locked" in request or "isLock" in request: actor["locked"] = bool(request.get("locked", request.get("isLock")))
            if "skin" in request or "actorSkin" in request: actor["skin"] = self._first_int(request, "skin", "actorSkin", default=0)
            self._save(profile, state)
            return 200, self._actor_message(actor)
        if method == "GET" and (lower.startswith("/fci/actor/") or lower == "/fci/actor"):
            return 200, self._actor_message(actor)
        return None

    def _equip(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if not lower.startswith("/fci/equip"):
            return None
        request = self._request_values(body)
        msg = self._request(body, "ApiEquip")
        equip_id = _int(request.get("id", request.get("uid", getattr(msg, "id", 20001) if msg else 20001)), 20001)
        equips = state.setdefault("equips", {})
        equip = equips.setdefault(str(equip_id), {"id": equip_id, "uid": equip_id, "level": 1, "exp": 0, "locked": False, "actorUid": 0, "plan": 0})
        equip.setdefault("locked", False); equip.setdefault("actorUid", 0); equip.setdefault("plan", 0)
        if method == "GET":
            # Package/list aliases return all owned equipment in a compact
            # JSON projection for clients without a dedicated descriptor.
            if lower in {"/fci/equip", "/fci/equip/", "/fci/equippackage", "/fci/equippackage/"}:
                return 200, {"equips": [dict(value) for value in equips.values()]}
            result = self._message("ApiEquip.result")
            result.result.id = _int(equip["id"])
            result.result.uid = _int(equip["uid"])
            result.result.level = _int(equip.get("level"), 1)
            result.result.cur_exp = _int(equip.get("exp"))
            result.result.actor_uid = _int(equip.get("actorUid"))
            result.result.is_lock = bool(equip.get("locked"))
            return 200, result
        if method in {"PATCH", "POST"} and not (lower.endswith("/enhance") or lower.endswith("/enhance/")):
            equip["level"] = max(1, min(100, _int(request.get("level", equip.get("level", 1))))); self._save(profile, state)
            result = self._message("ApiEquip.result"); result.result.id = _int(equip["id"]); result.result.uid = _int(equip["uid"]); result.result.level = _int(equip["level"]); return 200, result
        if not (lower.endswith("/enhance") or lower.endswith("/enhance/")):
            return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        current = max(1, _int(equip.get("level"), 1)); target = min(100, current + max(1, _int(request.get("levels", 1))))
        if target == current:
            return 409, {"error": "equip_level_max"}
        cost = sum(50 * level for level in range(current, target))
        ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": -cost}])
        if not ok:
            return 409, {"error": error or "insufficient_resource", "required": cost}
        equip["level"] = target
        equip["exp"] = _int(equip.get("exp"))
        self._save(profile, state)
        result = self._message("ApiEquipEnhance.result")
        for change in self._dynamic(changes):
            entry = result.res_change.add(); entry.base_res.type = change["type"]; entry.base_res.id = change["id"]; entry.base_res.param = change["param"]; entry.base_res.count = change["count"]; entry.base_res.count_delta = change["countDelta"]
        return 200, result

    def _actor_for(self, state: dict[str, Any], actor_id: int) -> dict[str, Any]:
        actors = state.setdefault("actors", {})
        actor = actors.setdefault(str(actor_id or 1001), {"id": actor_id or 1001, "level": 1, "star": 1, "exp": 0,
                                                           "quality": 1, "locked": False, "skin": 0,
                                                           "skills": {}, "favourLevel": 1, "favourExp": 0})
        actor.setdefault("id", actor_id or 1001); actor.setdefault("level", 1); actor.setdefault("star", 1); actor.setdefault("exp", 0)
        actor.setdefault("quality", 1); actor.setdefault("locked", False); actor.setdefault("skin", 0); actor.setdefault("skills", {})
        actor.setdefault("favourLevel", 1); actor.setdefault("favourExp", 0)
        return actor

    def _st_actor(self, actor: Mapping[str, Any]):
        """Project one local actor into the shared ``STActor`` wire type."""
        result = self._message("STActor")
        result.id = _int(actor.get("id"))
        result.uid = _int(actor.get("id"))
        result.level = max(1, _int(actor.get("level"), 1))
        result.star = max(1, _int(actor.get("star"), 1))
        result.cur_exp = max(0, _int(actor.get("exp")))
        result.quality = max(1, _int(actor.get("quality"), 1))
        result.is_lock = bool(actor.get("locked", actor.get("isLock", False)))
        result.actor_skin = max(0, _int(actor.get("skin")))
        for key, value in (actor.get("skills") or {}).items():
            skill = result.skills.add()
            skill.id = _int(key)
            if isinstance(value, Mapping):
                skill.level = max(1, _int(value.get("level"), 1))
                skill.is_read = bool(value.get("read", value.get("isRead", False)))
            else:
                skill.level = max(1, _int(value, 1))
        return result

    def _st_equip(self, equip: Mapping[str, Any]):
        """Project one local equipment row into the shared ``STEquip`` type."""
        result = self._message("STEquip")
        result.uid = _int(equip.get("uid", equip.get("id")))
        result.id = _int(equip.get("id", equip.get("uid")))
        result.cur_exp = max(0, _int(equip.get("exp")))
        result.level = max(1, _int(equip.get("level"), 1))
        result.actor_uid = max(0, _int(equip.get("actorUid", equip.get("actor_uid"))))
        result.is_lock = bool(equip.get("locked", equip.get("isLock", False)))
        result.is_new = bool(equip.get("isNew", False))
        result.match_index = max(0, _int(equip.get("matchIndex", equip.get("match_index"))))
        return result

    def _actor_maintenance(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if not (lower.startswith("/fci/actor") or "unlockedactorskins" in lower or "unlocked-actor-skins" in lower or "setactorlock" in lower or "actorlock" in lower or "favour" in lower or "present" in lower):
            return None
        payload = self._request_values(body)
        parts = [part for part in lower.split("/") if part]
        actor_id = self._first_int(payload, "actorId", "actor_id", "id", "uid", default=1001)
        for index, part in enumerate(parts):
            if part.isdigit() and index > 1:
                actor_id = _int(part, actor_id); break
        actor = self._actor_for(state, actor_id)

        # Actor inheritance has two observed request shapes.  The ordinary
        # form uses the actor in the URL as the source and only carries
        # ``targetActorUid``; the cross-actor form sends both ``actorUid`` and
        # ``targetActorUid``.  The retired service is unavailable, so keep a
        # deterministic local transaction: copy level/star/skills to the
        # target, move equipment ownership, charge a small sandbox gold fee,
        # and return the recovered protobuf response when available.
        inherit_tokens = ("actorinheriting", "actor-inheriting", "actorinherit", "actor-inherit", "diffactorinherit", "diff-actor-inherit")
        if any(token in lower for token in inherit_tokens):
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            is_diff = "diffactorinherit" in lower or "diff-actor-inherit" in lower
            request_name = "ApiDiffActorInherit" if is_diff else "ApiActorInheriting"
            request = self._request(body, request_name)
            source_id = self._first_int(payload, "actorUid", "actor_uid", "sourceActorUid", "source_actor_uid", default=actor_id)
            target_id = self._first_int(payload, "targetActorUid", "target_actor_uid", "targetId", "target_id", default=0)
            if request is not None:
                source_id = _int(getattr(request, "actor_uid", source_id), source_id)
                target_id = _int(getattr(request, "target_actor_uid", target_id), target_id)
            source_id = source_id or actor_id or 1001
            target_id = target_id or (1002 if source_id != 1002 else 1001)
            if source_id == target_id:
                return 409, {"error": "actor_inherit_same_target"}
            source = self._actor_for(state, source_id)
            target = self._actor_for(state, target_id)
            # Keep the cost explicit and local.  This avoids silently creating
            # progression while remaining affordable for a fresh sandbox
            # account.  All changes go through the canonical economy ledger.
            ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": -500}])
            if not ok:
                return 409, {"error": error or "insufficient_resource", "required": 500}
            target["level"] = max(1, _int(source.get("level"), 1))
            target["star"] = max(1, _int(source.get("star"), 1))
            target["exp"] = max(0, _int(source.get("exp")))
            target["quality"] = max(1, _int(source.get("quality"), 1))
            target["skills"] = json.loads(json.dumps(source.get("skills", {}))) if isinstance(source.get("skills"), Mapping) else {}
            target["favourLevel"] = max(1, _int(source.get("favourLevel"), 1))
            target["favourExp"] = max(0, _int(source.get("favourExp")))
            equipment_changes: list[tuple[int, int]] = []
            for equip in state.setdefault("equips", {}).values():
                if not isinstance(equip, dict) or _int(equip.get("actorUid")) != source_id:
                    continue
                equip["actorUid"] = target_id
                equipment_changes.append((_int(equip.get("uid", equip.get("id"))), target_id))
            self._save(profile, state)
            try:
                result = self._message(f"{request_name}.post")
                for change in self._dynamic(changes):
                    item = result.res_change.add()
                    item.base_res.type = change["type"]; item.base_res.id = change["id"]; item.base_res.param = change["param"]
                    item.base_res.count = change["count"]; item.base_res.count_delta = change["countDelta"]
                for key, value in equipment_changes:
                    # The generated descriptor represents EquipChangeEntry as
                    # a uint32->uint32 map, even though the source metadata
                    # lists it as a repeated entry message.
                    try:
                        result.equip_change[key] = value
                    except (TypeError, AttributeError):
                        item = result.equip_change.add(); item.key = key; item.value = value
                return 200, result
            except Exception:
                return 200, {"sourceActorUid": source_id, "targetActorUid": target_id, "equipChange": [{"key": key, "value": value} for key, value in equipment_changes], "resChange": self._dynamic(changes), "sandbox": True}

        # ``ActorLike`` was a small player-action endpoint in the retired
        # service, but its descriptor was not recovered with the rest of
        # playeraction.proto.  Keep the interaction usable through a stable
        # JSON compatibility seam.  Likes are account-local and idempotent:
        # retrying the same POST does not inflate the count, while DELETE (or
        # an explicit ``liked=false``) removes the local like.  The aggregate
        # count is persisted so the actor page remains consistent after a
        # restart.
        if any(token in lower for token in ("actorlike", "actor-like", "rolelike", "role-like")):
            likes = state.setdefault("actorLikes", {})
            if not isinstance(likes, dict):
                likes = {}
                state["actorLikes"] = likes
            key = str(actor_id)
            entry = likes.setdefault(key, {"count": 0, "liked": False})
            if not isinstance(entry, dict):
                entry = {"count": 0, "liked": False}
                likes[key] = entry
            entry["count"] = max(0, _int(entry.get("count")))
            entry["liked"] = bool(entry.get("liked", False))
            if method == "GET":
                try:
                    result = self._message("ApiActorLike.get")
                    result.like_num = entry["count"]
                    result.is_like = entry["liked"]
                    return 200, result
                except Exception:
                    return 200, {"actorId": actor_id, "likeCount": entry["count"], "liked": entry["liked"], "sandbox": True}
            if method not in {"POST", "DELETE"}:
                return 405, {"error": "method_not_allowed", "message": "POST or DELETE required"}
            payload = self._request_values(body)
            request = self._request(body, "ApiActorLike")
            if request is not None and request.is_cancel:
                payload["liked"] = False
            remove = method == "DELETE" or payload.get("liked") is False or payload.get("isLike") is False
            if remove:
                if entry["liked"]:
                    entry["count"] = max(0, entry["count"] - 1)
                entry["liked"] = False
            elif not entry["liked"]:
                entry["count"] += 1
                entry["liked"] = True
            self._save(profile, state)
            try:
                result = self._message("ApiActorLike.post")
                result.result = True
                result.like_num = entry["count"]
                result.is_like = entry["liked"]
                return 200, result
            except Exception:
                return 200, {"actorId": actor_id, "likeCount": entry["count"], "liked": entry["liked"], "sandbox": True}

        if any(token in lower for token in ("setactorlock", "actor-lock", "actorlock")):
            if method == "GET":
                return 200, {"actorId": actor_id, "isLock": bool(actor.get("locked"))}
            if method not in {"POST", "PATCH"}: return 405, {"error": "method_not_allowed", "message": "POST required"}
            lock = bool(payload.get("isLock", payload.get("locked", payload.get("lock", not actor.get("locked")))))
            actor["locked"] = lock; self._save(profile, state)
            try:
                result = self._message("ApiSetActorLock.result"); result.result.CopyFrom(self._actor_message(actor).result); return 200, result
            except Exception: return 200, {"actorId": actor_id, "isLock": lock}

        # ``ActorFavourFull`` is the one-tap completion used by the present
        # panel.  Keep it local and idempotent: it raises the actor to the
        # configured sandbox cap and emits the recovered typed response.
        if "actorfavourfull" in lower or "actor-favour-full" in lower or "favourfull" in lower:
            if method == "GET":
                try:
                    result = self._message("ApiActorFavourFull.result")
                    result.result = _int(actor.get("favourLevel"), 1) >= 10
                    return 200, result
                except Exception:
                    return 200, {"actorId": actor_id, "favourLevel": _int(actor.get("favourLevel"), 1), "complete": True, "sandbox": True}
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            actor["favourLevel"] = 10
            actor["favourExp"] = 0
            self._save(profile, state)
            try:
                result = self._message("ApiActorFavourFull.result")
                result.result = True
                return 200, result
            except Exception:
                return 200, {"actorId": actor_id, "favourLevel": 10, "complete": True, "sandbox": True}

        if "decompose" in lower and ("actor" in lower or "role" in lower):
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            if actor.get("locked"): return 409, {"error": "actor_locked"}
            # Keep the starter actor owned; decomposition removes only actors
            # acquired after the first slot and refunds local actor shards.
            if actor_id == 1001 and len(state.get("actors", {})) <= 1:
                return 409, {"error": "starter_actor_protected"}
            state.setdefault("actors", {}).pop(str(actor_id), None)
            refund = {"type": 15, "id": actor_id, "param": 0, "count": 1}
            ok, changes, error = self._change_resources(profile, [refund])
            if not ok: return 409, {"error": error or "resource_update_failed"}
            self._save(profile, state)
            try:
                result = self._message("ApiActorDecompose.post")
                for change in self._dynamic(changes):
                    item = result.res_change.add(); item.base_res.type = change["type"]; item.base_res.id = change["id"]; item.base_res.param = change["param"]; item.base_res.count = change["count"]; item.base_res.count_delta = change["countDelta"]
                return 200, result
            except Exception: return 200, {"resChange": self._dynamic(changes)}

        if "skill" in lower and ("learn" in lower or "learning" in lower or lower.endswith("/skill")):
            skill_id = self._first_int(payload, "skillId", "skill_id", default=0)
            if not skill_id:
                skill_id = 1001001 + len(actor.get("skills", {}))
            skills = actor.setdefault("skills", {})
            key = str(skill_id)
            if method == "GET":
                return 200, {"actorId": actor_id, "skills": [{"id": _int(k), **(v if isinstance(v, Mapping) else {"level": _int(v, 1), "read": False})} for k, v in skills.items()]}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            if key in skills: return 409, {"error": "skill_already_learned"}
            ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": -100}])
            if not ok: return 409, {"error": error or "insufficient_resource", "required": 100}
            skills[key] = {"level": 1, "read": False}; self._save(profile, state)
            try:
                result = self._message("ApiActorSkillLearnning.post"); result.new_skill.id = skill_id; result.new_skill.level = 1
                for change in self._dynamic(changes):
                    item = result.res_change.add(); item.base_res.type = change["type"]; item.base_res.id = change["id"]; item.base_res.param = change["param"]; item.base_res.count = change["count"]; item.base_res.count_delta = change["countDelta"]
                return 200, result
            except Exception: return 200, {"skill": skills[key], "resChange": self._dynamic(changes)}

        if "skill" in lower and "read" in lower:
            skill_id = self._first_int(payload, "skillId", "skill_id", "id", default=0)
            skill = actor.setdefault("skills", {}).setdefault(str(skill_id), {"level": 1, "read": False})
            skill["read"] = bool(payload.get("isRead", payload.get("read", True)))
            self._save(profile, state)
            try:
                result = self._message("ApiActorSkillRead.result"); result.is_read = bool(skill["read"]); return 200, result
            except Exception: return 200, {"isRead": bool(skill["read"])}

        if "unlockedactorskins" in lower or "unlocked-actor-skins" in lower:
            unlocked = state.setdefault("unlockedSkins", {})
            values = [int(item) for item in unlocked.get(str(actor_id), []) if _int(item) > 0]
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            try:
                result = self._message("ApiUnlockedActorSkins.result")
                result.unlocked_skins.extend(values)
                return 200, result
            except Exception:
                return 200, {"actorId": actor_id, "unlockedSkins": values, "sandbox": True}

        if "skin" in lower:
            if method == "GET":
                try:
                    result = self._message("ApiActorSkin.result")
                    result.actor_skin = _int(actor.get("skin"))
                    return 200, result
                except Exception:
                    return 200, {"actorId": actor_id, "skin": _int(actor.get("skin"))}
            if method not in {"POST", "PATCH"}: return 405, {"error": "method_not_allowed", "message": "POST required"}
            skin = self._first_int(payload, "skin", "skinId", "actorSkin", default=0)
            if skin < 0:
                return 400, {"error": "invalid_skin"}
            unlocked = state.setdefault("unlockedSkins", {})
            owned = unlocked.setdefault(str(actor_id), [])
            if skin and skin not in owned:
                owned.append(skin)
                owned.sort()
            actor["skin"] = skin
            self._save(profile, state)
            try:
                result = self._message("ApiActorSkin.result")
                result.actor_skin = skin
                return 200, result
            except Exception:
                return 200, {"actorId": actor_id, "skin": skin, "sandbox": True}

        if "favour" in lower or "favor" in lower or "present" in lower:
            if method == "GET":
                return 200, {"actorId": actor_id, "favourLevel": _int(actor.get("favourLevel"), 1), "favourExp": _int(actor.get("favourExp"))}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            gift_id = self._first_int(payload, "itemId", "giftId", "id", default=0)
            gift_count = max(1, self._first_int(payload, "count", "num", default=1))
            # Gifts are item resources (type 11).  If no item was supplied,
            # accept a local direct present with a small gold fee.
            changes_in = [{"type": 11, "id": gift_id, "param": 0, "count": -gift_count}] if gift_id else [{"type": 7, "id": 0, "param": 0, "count": -10 * gift_count}]
            ok, changes, error = self._change_resources(profile, changes_in)
            if not ok: return 409, {"error": error or "insufficient_resource"}
            actor["favourExp"] = _int(actor.get("favourExp")) + 10 * gift_count
            while _int(actor.get("favourExp")) >= 100 and _int(actor.get("favourLevel"), 1) < 10:
                actor["favourExp"] -= 100; actor["favourLevel"] = _int(actor.get("favourLevel"), 1) + 1
            self._save(profile, state)
            try:
                result = self._message("ApiFavourGift.result" if "gift" in lower else "ApiRolePresent.result")
                # Both response types have an optional favour change in some
                # client builds; JSON is the stable fallback.
                if hasattr(result, "favour_level"): result.favour_level = _int(actor.get("favourLevel"))
                return 200, result
            except Exception: return 200, {"actorId": actor_id, "favourLevel": _int(actor.get("favourLevel")), "favourExp": _int(actor.get("favourExp")), "resChange": self._dynamic(changes)}
        return None

    def _equipment_maintenance(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if not lower.startswith("/fci/equip") and "setequiplock" not in lower and "equiplock" not in lower:
            return None
        if not any(token in lower for token in ("lock", "equipon", "equipoff", "onall", "decompose", "dismantle", "plan", "custommatch", "modifymatchname", "modify-match-name")):
            return None
        payload = self._request_values(body); parts = [part for part in lower.split("/") if part]
        equip_id = self._first_int(payload, "equipUid", "equip_uid", "uid", "id", default=20001)
        for index, part in enumerate(parts):
            if part.isdigit() and index > 1: equip_id = _int(part, equip_id); break
        equips = state.setdefault("equips", {})
        equip = equips.setdefault(str(equip_id), {"id": equip_id, "uid": equip_id, "level": 1, "exp": 0, "locked": False, "actorUid": 0, "plan": 0})
        if "lock" in lower:
            if method == "GET": return 200, {"uid": equip_id, "isLock": bool(equip.get("locked"))}
            if method not in {"POST", "PATCH"}: return 405, {"error": "method_not_allowed", "message": "POST required"}
            equip["locked"] = bool(payload.get("isLock", payload.get("locked", payload.get("lock", not equip.get("locked")))))
            self._save(profile, state)
            try:
                result = self._message("ApiSetEquipLock.result"); result.equip.uid = equip_id; result.equip.id = _int(equip.get("id")); result.equip.level = _int(equip.get("level"), 1); result.equip.is_lock = bool(equip["locked"]); return 200, result
            except Exception: return 200, {"uid": equip_id, "isLock": bool(equip["locked"])}

        # Equipment loadouts are stored per account.  The protobuf map uses a
        # numeric key and a DBGamePlayer.EquipCustomMatch value; accept both
        # that wire shape and the compact JSON shape used by the local tools.
        if "custommatch" in lower or "custom-match" in lower:
            plans = state.setdefault("equipPlans", {})
            if method == "GET":
                try:
                    result = self._message("ApiEquipCustomMatch.result")
                    for key, raw in plans.items():
                        plan = result.equip_custom_match[_int(key, 1)]
                        if isinstance(raw, Mapping):
                            plan.match_name = str(raw.get("matchName", raw.get("name", f"方案{key}")))[:32]
                            selected = raw.get("equipUids", raw.get("equip_uids", []))
                        else:
                            selected = []
                        if isinstance(selected, list):
                            for uid in selected:
                                plan.match_equip_uids[_int(uid, 0)] = _int(uid, 0)
                    return 200, result
                except Exception:
                    return 200, {"plans": plans, "sandbox": True}
            if method != "POST" and method != "PATCH":
                return 405, {"error": "method_not_allowed", "message": "POST or PATCH required"}
            plan_id = self._first_int(payload, "planId", "plan_id", "matchId", "match_id", default=1)
            selected = payload.get("equipUids", payload.get("equip_uids", payload.get("uids", [])))
            if not isinstance(selected, list):
                selected = [equip_id]
            selected = sorted({_int(uid) for uid in selected if _int(uid) > 0})
            plans[str(plan_id)] = {"matchName": str(payload.get("matchName", payload.get("name", f"方案{plan_id}")))[:32], "equipUids": selected}
            self._save(profile, state)
            try:
                result = self._message("ApiEquipCustomMatch.result")
                plan = result.equip_custom_match[plan_id]
                plan.match_name = plans[str(plan_id)]["matchName"]
                for uid in selected:
                    plan.match_equip_uids[uid] = uid
                for uid in selected:
                    if str(uid) in equips:
                        result.change_equips.add().CopyFrom(self._st_equip(equips[str(uid)]))
                return 200, result
            except Exception:
                return 200, {"planId": plan_id, "plan": plans[str(plan_id)], "sandbox": True}

        if "modifymatchname" in lower or "modify-match-name" in lower:
            if method != "POST" and method != "PATCH":
                return 405, {"error": "method_not_allowed", "message": "POST or PATCH required"}
            plan_id = self._first_int(payload, "planId", "plan_id", "matchId", "match_id", default=1)
            plans = state.setdefault("equipPlans", {})
            value = plans.setdefault(str(plan_id), {"matchName": f"方案{plan_id}", "equipUids": []})
            value["matchName"] = str(payload.get("matchName", payload.get("name", value.get("matchName", f"方案{plan_id}"))))[:32]
            self._save(profile, state)
            try:
                result = self._message("ApiEquipModifyMatchName.result")
                result.match_name = value["matchName"]
                return 200, result
            except Exception:
                return 200, {"planId": plan_id, "matchName": value["matchName"], "sandbox": True}
        if "decompose" in lower or "dismantle" in lower:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            if equip.get("locked"): return 409, {"error": "equip_locked"}
            refund = max(1, _int(equip.get("level"), 1) * 25)
            equips.pop(str(equip_id), None)
            ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": refund}])
            if not ok: return 409, {"error": error or "resource_update_failed"}
            self._save(profile, state)
            try:
                result = self._message("ApiEquipDecompose.result")
                for change in self._dynamic(changes):
                    item = result.res_change.add(); item.base_res.type = change["type"]; item.base_res.id = change["id"]; item.base_res.param = change["param"]; item.base_res.count = change["count"]; item.base_res.count_delta = change["countDelta"]
                return 200, result
            except Exception: return 200, {"resChange": self._dynamic(changes)}
        if "equipon" in lower or "onall" in lower or lower.endswith("/on") or lower.endswith("/off") or "equip-off" in lower or "equipoff" in lower:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            actor_uid = self._first_int(payload, "actorUid", "actor_uid", "actorId", default=1001)
            if "off" in lower:
                equip["actorUid"] = 0
            else:
                equip["actorUid"] = actor_uid
            self._save(profile, state)
            if "onall" in lower:
                actor_uid = self._first_int(payload, "actorUid", "actor_uid", "actorId", default=1001)
                selected = payload.get("equipUids", payload.get("equip_uids", []))
                if not isinstance(selected, list): selected = [equip_id]
                for selected_uid in selected:
                    value = equips.setdefault(str(_int(selected_uid)), {"id": _int(selected_uid), "uid": _int(selected_uid), "level": 1, "exp": 0, "locked": False, "actorUid": 0, "plan": 0})
                    value["actorUid"] = actor_uid
                self._save(profile, state)
                try:
                    result = self._message("ApiEquipOnAll.result")
                    actor = self._actor_for(state, actor_uid)
                    result.new_actor.CopyFrom(self._st_actor(actor))
                    for selected_uid in selected:
                        result.new_equips.add().CopyFrom(self._st_equip(equips[str(_int(selected_uid))]))
                    return 200, result
                except Exception:
                    return 200, {"actorUid": actor_uid, "equipUids": [_int(x) for x in selected], "sandbox": True}
            try:
                response_name = "ApiEquipOff.result" if "off" in lower else "ApiEquipOn.result"
                result = self._message(response_name)
                actor = self._actor_for(state, actor_uid)
                if "off" in lower:
                    result.new_actor.CopyFrom(self._st_actor(actor)); result.new_equip.CopyFrom(self._st_equip(equip)); result.off_equips.add().CopyFrom(self._st_equip(equip))
                else:
                    result.new_actor.CopyFrom(self._st_actor(actor)); result.new_equip.CopyFrom(self._st_equip(equip))
                    result.old_actor.CopyFrom(self._st_actor(actor)); result.old_equip.CopyFrom(self._st_equip(equip))
                return 200, result
            except Exception:
                return 200, {"uid": equip_id, "actorUid": _int(equip.get("actorUid")), "sandbox": True}
        if "plan" in lower or "custommatch" in lower:
            if method == "GET": return 200, {"plans": state.setdefault("equipPlans", {})}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            plan_id = str(self._first_int(payload, "planId", "plan_id", default=1)); plans = state.setdefault("equipPlans", {})
            plans[plan_id] = dict(payload); self._save(profile, state); return 200, {"planId": _int(plan_id), "plan": plans[plan_id]}
        return None

    def _item_resource(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower(); payload = self._request_values(body)
        item_route = lower in {"/fci/item", "/fci/item/", "/fci/item/use", "/fci/item/sell"} or any(token in lower for token in ("playeritem", "itemuse", "item-use", "itemsell", "item/sell", "/item/"))
        resource_route = any(token in lower for token in ("baseresource", "base-resource", "resourcecompose", "resource-compose", "/resource/compose", "resource/newflag", "resource-new-flag", "resourcefull"))
        if not (item_route or resource_route): return None
        items = state.setdefault("items", {})

        # The real client uses a typed single-item endpoint for the item
        # detail popup.  Keep the historical list endpoint as JSON below, but
        # answer ``/playeritem/<id>`` with the recovered STItem envelope.
        if lower.startswith("/fci/playeritem/") and lower.rstrip("/").rsplit("/", 1)[-1].isdigit() and method == "GET":
            item_id = _int(lower.rstrip("/").rsplit("/", 1)[-1])
            value = items.get(str(item_id), {})
            try:
                result = self._message("ApiPlayerItem.result")
                result.result.id = item_id
                result.result.count = _int(value.get("count"))
                result.result.got_time = _int(value.get("gotTime"))
                result.result.is_new = bool(value.get("isNew", False))
                return 200, result
            except Exception:
                return 200, {"id": item_id, "count": _int(value.get("count")), "sandbox": True}

        if item_route:
            item_id = self._first_int(payload, "itemId", "item_id", "id", default=0)
            count = max(1, self._first_int(payload, "count", "num", default=1))
            if ("playeritem" in lower or lower in {"/fci/item", "/fci/item/"}) and method == "GET":
                result = []
                for key, value in items.items():
                    if _int(value.get("count")) > 0: result.append({"id": _int(key), "count": _int(value.get("count")), "gotTime": _int(value.get("gotTime")), "isNew": bool(value.get("isNew", True))})
                return 200, {"items": result}
            if "sell" in lower:
                if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
                current = _int(items.get(str(item_id), {}).get("count"))
                if current < count: return 409, {"error": "insufficient_item"}
                items[str(item_id)]["count"] = current - count
                ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": 10 * count}])
                if not ok: return 409, {"error": error or "resource_update_failed"}
                self._save(profile, state)
                try:
                    result = self._message("ApiItemSell.result")
                    for change in self._dynamic(changes):
                        entry = result.res_change.add(); entry.base_res.type = change["type"]; entry.base_res.id = change["id"]; entry.base_res.param = change["param"]; entry.base_res.count = change["count"]; entry.base_res.count_delta = change["countDelta"]
                    return 200, result
                except Exception: return 200, {"resChange": self._dynamic(changes)}
            if "use" in lower:
                if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
                current = _int(items.get(str(item_id), {}).get("count"))
                if current < count: return 409, {"error": "insufficient_item"}
                items[str(item_id)]["count"] = current - count
                # Local consumables grant actor EXP and a small gold reward.
                actor = self._actor_for(state, self._first_int(payload, "actorId", "actor_id", default=1001))
                actor["exp"] = _int(actor.get("exp")) + 50 * count
                ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": 5 * count}])
                if not ok: return 409, {"error": error or "resource_update_failed"}
                self._save(profile, state)
                try:
                    result = self._message("ApiPlayerItemUse.result")
                    for change in self._dynamic(changes):
                        entry = result.res_change.add(); entry.base_res.type = change["type"]; entry.base_res.id = change["id"]; entry.base_res.param = change["param"]; entry.base_res.count = change["count"]; entry.base_res.count_delta = change["countDelta"]
                    return 200, result
                except Exception: return 200, {"resChange": self._dynamic(changes), "actorExp": actor["exp"]}
            # POST to the item endpoint is a local item grant used by tests
            # and by the sandbox shop.  It is explicit and bounded.
            if method == "POST" and item_id:
                entry = items.setdefault(str(item_id), {"id": item_id, "count": 0, "gotTime": self._now(), "isNew": True})
                entry["count"] = _int(entry.get("count")) + count; entry["gotTime"] = self._now(); self._save(profile, state)
                return 200, {"item": dict(entry)}
            return 405, {"error": "method_not_allowed", "message": "GET or POST required"}

        # Base resources are exposed both as typed protobuf where descriptors
        # exist and as JSON for partial builds.  They share the profile ledger.
        if lower in {"/fci/playerbaseresource", "/fci/playerbaseresource/"} and method == "GET":
            try:
                result = self._message("ApiPlayerBaseResource.result")
                for item in profile.get("resources", []):
                    if not isinstance(item, Mapping):
                        continue
                    entry = result.result.add(); entry.type = _int(item.get("type")); entry.id = _int(item.get("id")); entry.count = _int(item.get("count")); entry.param = _int(item.get("param"))
                return 200, result
            except Exception:
                return 200, {"resources": list(profile.get("resources", [])), "sandbox": True}
        if lower in {"/fci/playerbaseresource/full", "/fci/playerbaseresource/full/"} and method == "GET":
            try:
                result = self._message("ApiPlayerBaseResourceFull.result")
                for item in profile.get("resources", []):
                    if not isinstance(item, Mapping):
                        continue
                    entry = result.result.add(); entry.type = _int(item.get("type")); entry.id = _int(item.get("id")); entry.count = _int(item.get("count")); entry.param = _int(item.get("param"))
                return 200, result
            except Exception:
                return 200, {"resources": list(profile.get("resources", [])), "sandbox": True}
        if lower in {"/fci/baseresource", "/fci/baseresource/", "/fci/base-resource", "/fci/base-resource/", "/fci/resource", "/fci/resource/"} and method == "GET":
            resources = [dict(item) for item in profile.get("resources", []) if isinstance(item, Mapping)]
            return 200, {"resources": resources}
        if "newflag" in lower or "new-flag" in lower:
            if method == "GET": return 200, {"isNew": bool(state.get("resourceNewFlag", False)), "resInfo": []}
            if method not in {"POST", "PATCH"}: return 405, {"error": "method_not_allowed", "message": "PATCH required"}
            state["resourceNewFlag"] = bool(payload.get("isNew", payload.get("patch", False))); self._save(profile, state)
            try:
                result = self._message("ApiResourceNewFlag.patch")
                result.patch = bool(state["resourceNewFlag"])
                return 200, result
            except Exception:
                return 200, {"isNew": bool(state["resourceNewFlag"])}
        if "compose" in lower:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            rtype = self._first_int(payload, "type", default=6); rid = self._first_int(payload, "id", default=0); amount = max(1, self._first_int(payload, "count", "num", default=1))
            # One local recipe: three low-tier resources become one higher
            # tier resource.  The recipe is deterministic and atomic.
            source = {"type": rtype, "id": rid, "param": 0, "count": -3 * amount}; target = {"type": rtype, "id": rid + 1, "param": 0, "count": amount}
            ok, changes, error = self._change_resources(profile, [source, target])
            if not ok: return 409, {"error": error or "insufficient_resource"}
            self._save(profile, state)
            try:
                result = self._message("ApiResourceCompose.result")
                for change in self._dynamic(changes):
                    entry = result.res_change.add(); entry.base_res.type = change["type"]; entry.base_res.id = change["id"]; entry.base_res.param = change["param"]; entry.base_res.count = change["count"]; entry.base_res.count_delta = change["countDelta"]
                return 200, result
            except Exception: return 200, {"resChange": self._dynamic(changes)}
        if method == "POST" and lower in {"/fci/baseresource", "/fci/baseresource/", "/fci/resource", "/fci/resource/"}:
            rtype = self._first_int(payload, "type", default=7); rid = self._first_int(payload, "id", default=0); amount = self._first_int(payload, "count", default=0)
            if not amount: return 400, {"error": "invalid_resource_count"}
            ok, changes, error = self._change_resources(profile, [{"type": rtype, "id": rid, "param": 0, "count": amount}])
            if not ok: return 409, {"error": error or "resource_update_failed"}
            return 200, {"resChange": self._dynamic(changes)}
        return None

    def _medal_seal_cultivation(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower(); payload = self._request_values(body)
        if "chip" in lower and "exchange" in lower:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            chip_id = self._first_int(payload, "chipId", "chip_id", "id", default=0)
            amount = max(1, self._first_int(payload, "count", "num", default=1))
            actor_id = self._first_int(payload, "actorId", "actor_id", default=chip_id)
            # Actor chips are represented by resource type 15.  Exchanging
            # them for local gold keeps the operation useful even when the
            # original activity tables are unavailable.
            ok, changes, error = self._change_resources(profile, [
                {"type": 15, "id": actor_id, "param": 0, "count": -amount},
                {"type": 7, "id": 0, "param": 0, "count": 100 * amount},
            ])
            if not ok: return 409, {"error": error or "insufficient_resource"}
            self._save(profile, state)
            return 200, {"chipId": chip_id, "count": amount, "resChange": self._dynamic(changes), "sandbox": True}
        if "medal" in lower:
            medals = state.setdefault("medals", {})
            medal_id = self._first_int(payload, "id", "medalId", default=1)
            if method == "GET": return 200, {"medals": [dict(v) for v in medals.values()]}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            medals[str(medal_id)] = {"id": medal_id, "gotTime": self._now(), "isNew": True}; self._save(profile, state)
            try:
                result = self._message("ApiMedal.result"); result.result.id = medal_id; result.result.got_time = self._now(); result.result.is_new = True; return 200, result
            except Exception: return 200, {"medal": medals[str(medal_id)]}
        if "seal" in lower:
            seals = state.setdefault("seals", {"cells": {}, "rewards": {}, "newOpenFlag": False})
            if method == "GET":
                try:
                    result = self._message("ApiSeal.result")
                    for value in seals.get("cells", {}).values():
                        cell = result.cell_info.add(); cell.info.cell_id = _int(value.get("cellId")); cell.fill = bool(value.get("filled", False))
                    for value in seals.get("rewards", {}).values():
                        reward = result.reward_info.add(); reward.info.reward_id = _int(value.get("id")); reward.got = bool(value.get("claimed", False))
                    return 200, result
                except Exception:
                    return 200, {"cellInfo": list(seals.get("cells", {}).values()), "rewardInfo": list(seals.get("rewards", {}).values()), "sandbox": True}
            if "flag" in lower:
                seals["newOpenFlag"] = bool(payload.get("newOpenFlag", payload.get("isNew", False))); self._save(profile, state)
                try:
                    result = self._message("ApiSealFlag.result"); result.new_open_flag = bool(seals["newOpenFlag"]); return 200, result
                except Exception: return 200, {"newOpenFlag": seals["newOpenFlag"]}
            cell_id = self._first_int(payload, "cellId", "cell_id", "id", default=1)
            if "reward" in lower:
                reward_id = self._first_int(payload, "rewardId", "reward_id", "id", default=1)
                key = str(reward_id)
                if seals.setdefault("rewards", {}).get(key, {}).get("claimed"): return 409, {"error": "seal_reward_already_claimed"}
                ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": 100}])
                if not ok: return 409, {"error": error or "resource_update_failed"}
                seals["rewards"][key] = {"id": reward_id, "claimed": True}; self._save(profile, state)
                try:
                    result = self._message("ApiSealReward.result"); result.reward_id = reward_id
                    for change in self._dynamic(changes):
                        item = result.res_change.add(); item.base_res.type = change["type"]; item.base_res.id = change["id"]; item.base_res.param = change["param"]; item.base_res.count = change["count"]; item.base_res.count_delta = change["countDelta"]
                    return 200, result
                except Exception: return 200, {"rewardId": reward_id, "resChange": self._dynamic(changes)}
            if "fill" in lower:
                if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
                seals.setdefault("cells", {})[str(cell_id)] = {"cellId": cell_id, "filled": True}; self._save(profile, state)
                try:
                    result = self._message("ApiSealFill.result"); result.cell_id = cell_id; return 200, result
                except Exception: return 200, {"cellId": cell_id}
            return 200, {"cellInfo": list(seals.get("cells", {}).values()), "rewardInfo": list(seals.get("rewards", {}).values())}
        if "cultivation" in lower:
            cultivation = state.setdefault("cultivation", {})
            actor_id = self._first_int(payload, "actorId", "actor_id", default=1001); key = str(actor_id)
            info = cultivation.setdefault(key, {"actorId": actor_id, "activityId": 1, "progress": 0, "progressDaily": 0, "progressReward": 0, "progressRewardVip": 0, "vip": False, "startTime": self._now(), "endTime": self._now() + 86400 * 30, "new": False, "showEnd": False})
            if method == "GET": return 200, dict(info)
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            info["progress"] = max(0, _int(info.get("progress")) + self._first_int(payload, "progress", default=1)); info["progressDaily"] = _int(info.get("progressDaily")) + 1
            if "vip" in lower: info["vip"] = True
            if "showend" in lower: info["showEnd"] = True
            self._save(profile, state)
            try:
                name = "ApiActorCultivation.result"
                for marker, response_name in (("newflag", "ApiActorCultivationNewFlag.result"), ("showend", "ApiActorCultivationShowEnd.result"), ("done", "ApiActorCultivationDone.result"), ("upgradevip", "ApiActorCultivationUpgradeVip.result"), ("taskreward", "ApiActorCultivationTaskReward.result"), ("progressreward", "ApiActorCultivationProgressReward.result")):
                    if marker in lower: name = response_name; break
                result = self._message(name)
                field = "result" if hasattr(result, "result") else "info"
                getattr(result, field).CopyFrom(self._cultivation_message(info)); return 200, result
            except Exception: return 200, dict(info)
        return None

    def _cultivation_message(self, info: Mapping[str, Any]):
        result = self._message("ActorCultivationInfo")
        for source, target in (("activityId", "activity_id"), ("actorId", "actor_id"), ("progress", "progress"), ("progressDaily", "progress_daily"), ("progressReward", "progress_reward"), ("progressRewardVip", "progress_reward_vip"), ("vip", "vip"), ("startTime", "start_time"), ("endTime", "end_time"), ("new", "new"), ("showEnd", "show_end")):
            if hasattr(result, target): setattr(result, target, info.get(source, 0))
        return result

    def _gacha(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if lower in {"/fci/gachainfo", "/fci/gachainfo/"}:
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            result = self._message("ApiGachaInfo.get")
            info = result.gacha_info.add()
            info.id = 1
            info.gacha_count_today = _int(state.get("gacha_count"))
            info.next_free_gacha_time = 0
            info.next_get_purple_count = max(0, 10 - (_int(state.get("gacha_count")) % 10))
            return 200, result
        if not (lower.startswith("/fci/gacha") or lower.startswith("/fci/card/gacha")):
            return None
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        request = _json(body)
        msg = self._request(body, "ApiGachaTrade")
        count = max(1, min(10, _int(request.get("count", getattr(msg, "count", 1) if msg else 1))))
        state["gacha_count"] = _int(state.get("gacha_count")) + count
        actor_id = 1002 + (state["gacha_count"] % 3)
        actor = state.setdefault("actors", {}).setdefault(str(actor_id), {"id": actor_id, "level": 1, "star": 1, "exp": 0})
        state["gacha_records"].append({"id": actor_id, "quality": 1, "time": self._now()})
        self._save(profile, state)
        result = self._message("ApiGachaTrade.result")
        result.info.id = actor_id
        result.info.time = self._now()
        result.info.count = count
        result.info.trade_id = state["gacha_count"]
        record = result.actor_record.add()
        record.id = actor_id; record.quality = 1; record.time_order = state["gacha_count"]
        result.gacha_count_today = state["gacha_count"]
        return 200, result

    def _mail(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if not lower.startswith("/fci/mail"):
            return None
        mails = state.setdefault("mails", [])
        # Upgrade old local profiles created before mail attachments were
        # modelled.  Keep this migration deterministic and account-local.
        for value in mails:
            if isinstance(value, dict):
                value.setdefault("attachments", [])
                value.setdefault("attachmentsGot", False)
        if lower in {"/fci/mail", "/fci/mail/"} and method == "GET":
            result = self._message("ApiMail.get")
            result.get.clear_all = False
            for value in mails:
                mail = result.get.mails.add()
                mail.id = _int(value.get("id")); mail.title = str(value.get("title", "")); mail.content = str(value.get("content", "")); mail.sender_name = str(value.get("senderName", "Local Sandbox")); mail.create_time = self._now(); mail.start_time = self._now(); mail.end_time = self._now() + 86400 * 365; mail.read = bool(value.get("read")); mail.attachments_got = bool(value.get("attachmentsGot"))
                for attachment in value.get("attachments", []):
                    if isinstance(attachment, Mapping):
                        entry = mail.attachments.add()
                        entry.base_res.type = _int(attachment.get("type"))
                        entry.base_res.id = _int(attachment.get("id"))
                        entry.base_res.count = _int(attachment.get("count"))
                        entry.base_res.param = _int(attachment.get("param"))
            return 200, result
        request = _json(body)
        mail_id = _int(request.get("id", request.get("mailId", 1)), 1)
        if method == "GET":
            value = next((item for item in mails if _int(item.get("id")) == mail_id), None)
            result = self._message("ApiMail.result"); result.result.id = mail_id
            if isinstance(value, Mapping):
                result.result.title = str(value.get("title", "")); result.result.content = str(value.get("content", "")); result.result.sender_name = str(value.get("senderName", "Local Sandbox")); result.result.read = bool(value.get("read")); result.result.attachments_got = bool(value.get("attachmentsGot"))
                for attachment in value.get("attachments", []):
                    if isinstance(attachment, Mapping):
                        entry = result.result.attachments.add()
                        entry.base_res.type = _int(attachment.get("type"))
                        entry.base_res.id = _int(attachment.get("id"))
                        entry.base_res.count = _int(attachment.get("count"))
                        entry.base_res.param = _int(attachment.get("param"))
            return 200, result
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        value = next((item for item in mails if _int(item.get("id")) == mail_id), None)
        if value is None:
            return 404, {"error": "mail_not_found", "mailId": mail_id}
        value.setdefault("attachments", [])
        value.setdefault("attachmentsGot", False)
        changes: list[dict[str, int]] = []
        if lower.endswith("/read"):
            value["read"] = True
        elif lower.endswith("/obtain") or lower.endswith("/collect"):
            # Claim each message exactly once.  Resource changes go through
            # the canonical ledger so balances and login bootstrap stay in
            # sync across restarts.
            if not value.get("attachmentsGot"):
                attachments = [item for item in value.get("attachments", []) if isinstance(item, Mapping)]
                if attachments:
                    ok, changes, error = self._change_resources(profile, attachments)
                    if not ok:
                        return 409, {"error": error or "resource_update_failed"}
                value["attachmentsGot"] = True
            value["read"] = True
        elif lower.endswith("/delete") or lower.endswith("/auto-delete"):
            # Deleting a mail is local metadata only; unclaimed attachments
            # remain unclaimed and cannot be obtained after deletion.
            mails[:] = [item for item in mails if _int(item.get("id")) != mail_id]
        else:
            value["read"] = True
        self._save(profile, state)
        if lower.endswith("/delete") or lower.endswith("/auto-delete"):
            result = self._message("ApiMailAutoDelete.result"); result.auto_delete = True; result.del_mails.append(mail_id); return 200, result
        result = self._message("ApiMail.result"); result.result.id = mail_id; result.result.read = bool(value.get("read")); result.result.attachments_got = bool(value.get("attachmentsGot"))
        for change in changes:
            entry = result.res_change.add()
            entry.base_res.type = _int(change.get("type"))
            entry.base_res.id = _int(change.get("id"))
            entry.base_res.count = _int(change.get("count"))
            entry.base_res.param = _int(change.get("param"))
            entry.base_res.count_delta = _int(change.get("countDelta"))
        return 200, result

    def _relation(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if not (lower.startswith("/fci/relation") or lower.startswith("/fci/friend")):
            return None
        friends = state.setdefault("friends", [])
        if method == "GET":
            result = self._message("ApiRelationFriendList.get")
            for friend in friends:
                item = result.result.add(); item.player_id = str(friend.get("playerId")); item.name = str(friend.get("name", "Local Friend")); item.level = _int(friend.get("level"), 1); item.is_in_relation = True
            return 200, result
        request = _json(body); msg = self._request(body, "ApiRelationApplyFriend")
        target = str(request.get("targetId", request.get("target_id", getattr(msg, "target_id", "local-friend") if msg else "local-friend")))
        if not any(str(x.get("playerId")) == target for x in friends):
            friends.append({"playerId": target, "name": "Local Friend", "level": 1})
        self._save(profile, state)
        result = self._message("ApiRelationApplyFriend.result"); result.result.player_id = target; result.result.name = "Local Friend"; result.result.level = 1; result.result.is_in_relation = True
        return 200, result

    def _pvp(self, method: str, route: str, body: Body, profile: Mapping[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if lower in {"/fci/asyncpvprecord", "/fci/asyncpvprecord/"}:
            if method != "GET": return 405, {"error": "method_not_allowed", "message": "GET required"}
            return 200, self._message("ApiAsyncPvpRecordInfo.result")
        if lower.startswith("/fci/asyncpvp") or lower.startswith("/fci/match_mirror"):
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            result = self._message("ApiAsyncPvpMatch.result"); result.index = 0; result.target_actor.name = "Local Training Opponent"; result.target_actor.level = 1; result.target_actor.player_id = "local-bot"; return 200, result
        return None

    def _guild_bot_members(self, profile: Mapping[str, Any]) -> list[dict[str, Any]]:
        """Return a deterministic roster used by the local guild.

        The retired service is unavailable, so a guild needs a stable set of
        members for the member, vote and support panels to render.  Reuse the
        same fixed-seed bot pool as social/PVP when it is available; the
        fallback keeps this module usable in isolated unit tests.
        """
        try:
            from social import LocalBotPool

            bots = LocalBotPool(seed=20261028, count=24, clock=self._clock).all()[:5]
        except Exception:  # pragma: no cover - defensive import fallback
            bots = [
                {"playerId": "local-bot-001", "name": "御坂训练员1", "level": 12, "avatar": 1002, "score": 1000, "online": True, "actors": [1001, 1002, 1003]},
                {"playerId": "local-bot-002", "name": "黑雪姬2", "level": 18, "avatar": 1003, "score": 1040, "online": False, "actors": [1002, 1003, 1004]},
                {"playerId": "local-bot-003", "name": "桐人练习生3", "level": 24, "avatar": 1004, "score": 1120, "online": True, "actors": [1001, 1004, 1005]},
                {"playerId": "local-bot-004", "name": "亚丝娜助手4", "level": 30, "avatar": 1005, "score": 1190, "online": False, "actors": [1003, 1005, 1006]},
                {"playerId": "local-bot-005", "name": "司波机器人5", "level": 36, "avatar": 1006, "score": 1250, "online": True, "actors": [1001, 1005, 1007]},
            ]
        return [dict(item, actors=list(item.get("actors", []))) for item in bots]

    def _guild_member_rows(self, guild: Mapping[str, Any], profile: Mapping[str, Any]) -> list[dict[str, Any]]:
        """Build a JSON-safe roster while preserving persisted contribution."""
        self_id = str(profile.get("player_id", "local"))
        self_name = str(profile.get("name", "Local Guest"))
        self_level = _int(profile.get("level"), 1)
        president = str(guild.get("president", self_id))
        raw_members = guild.get("members", [])
        by_id = {
            str(item.get("playerId")): dict(item)
            for item in raw_members
            if isinstance(item, Mapping) and item.get("playerId")
        }
        bots = {str(bot["playerId"]): bot for bot in self._guild_bot_members(profile)}
        if self_id not in by_id:
            by_id[self_id] = {"playerId": self_id, "name": self_name, "level": self_level, "avatar": _int(profile.get("head_photo")), "online": True, "contribution": 0}
        rows: list[dict[str, Any]] = []
        for player_id, item in by_id.items():
            bot = bots.get(player_id, {})
            row = {
                "playerId": player_id,
                "name": str(item.get("name", bot.get("name", "Local Member"))),
                "level": _int(item.get("level", bot.get("level", 1)), 1),
                "avatar": _int(item.get("avatar", bot.get("avatar", 0))),
                "online": bool(item.get("online", bot.get("online", False))),
                "contribution": _int(item.get("contribution", 0)),
                "role": "president" if player_id == president else str(item.get("role", "member")),
                "isBot": player_id.startswith("local-bot-"),
                "actors": list(item.get("actors", bot.get("actors", [])) or []),
            }
            rows.append(row)
        rows.sort(key=lambda row: (0 if row["role"] == "president" else 1, row["playerId"]))
        return rows

    def _guild_normalise(self, guild: dict[str, Any], profile: Mapping[str, Any]) -> dict[str, Any]:
        """Upgrade old one-member guild JSON to the current local schema."""
        self_id = str(profile.get("player_id", "local"))
        guild.setdefault("id", 1)
        guild.setdefault("name", "Local Sandbox Guild")
        guild.setdefault("level", 1)
        guild.setdefault("exp", 0)
        guild.setdefault("contribution", 0)
        guild.setdefault("skills", {})
        guild.setdefault("records", [])
        guild.setdefault("president", self_id)
        guild.setdefault("vicePresidents", [])
        guild.setdefault("pendingMembers", [])
        guild.setdefault("votes", {})
        guild.setdefault("support", {"requests": [], "offers": []})
        guild.setdefault("dungeon", {"stage": 1, "score": 0, "attempts": 0, "history": []})
        if not isinstance(guild.get("members"), list) or not guild["members"]:
            guild["members"] = [
                {"playerId": self_id, "name": str(profile.get("name", "Local Guest")), "level": _int(profile.get("level"), 1), "online": True, "contribution": 0}
            ]
            guild["members"].extend(
                {"playerId": str(bot["playerId"]), "name": str(bot["name"]), "level": _int(bot.get("level"), 1), "avatar": _int(bot.get("avatar")), "online": bool(bot.get("online")), "contribution": 0, "actors": list(bot.get("actors", []))}
                for bot in self._guild_bot_members(profile)
            )
        if not isinstance(guild.get("records"), list):
            guild["records"] = []
        if not isinstance(guild.get("votes"), dict):
            guild["votes"] = {}
        support = guild.get("support")
        if not isinstance(support, dict):
            guild["support"] = {"requests": [], "offers": []}
        else:
            support.setdefault("requests", []); support.setdefault("offers", [])
        dungeon = guild.get("dungeon")
        if not isinstance(dungeon, dict):
            guild["dungeon"] = {"stage": 1, "score": 0, "attempts": 0, "history": []}
        else:
            dungeon.setdefault("stage", 1); dungeon.setdefault("score", 0); dungeon.setdefault("attempts", 0); dungeon.setdefault("history", [])
        return guild

    @staticmethod
    def _guild_record(guild: dict[str, Any], record: Mapping[str, Any]) -> None:
        rows = guild.setdefault("records", [])
        if not isinstance(rows, list):
            rows = []
            guild["records"] = rows
        rows.append(dict(record))
        del rows[:-100]

    def _guild(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        """Provide a persistent local guild with deterministic robot members.

        This is a local compatibility surface.  It gives the client a complete
        single-guild loop (roster, invitations, president vote, support,
        donations, skills, dungeon records and leave) without contacting the
        retired service or claiming that cross-player coordination is restored.
        """
        lower = route.lower()
        if not (lower.startswith("/fci/guild") or lower.startswith("/fci/guild-dungeon-record")):
            return None
        guild = state.get("guild")
        if lower in {"/fci/guild/recommend", "/fci/guild/recommend/", "/fci/guild/search", "/fci/guild/search/"}:
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            name = "Local Sandbox Guild"
            result = self._message("ApiGuildRecommend.result" if "recommend" in lower else "ApiGuildSearch.result")
            result.result.id = 1; result.result.name = name; result.result.level = 1; result.result.exp = 0; result.result.president = "local"; result.result.president_name = "Local Guest"; result.result.members_count = 6
            return 200, result
        if lower in {"/fci/guild/create", "/fci/guild/create/"}:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _json(body); name = str(request.get("name", "Local Sandbox Guild"))[:32] or "Local Sandbox Guild"
            state["guild"] = self._guild_normalise({"id": 1, "name": name, "level": 1}, profile)
            self._save(profile, state)
            result = self._message("ApiGuild.result"); result.base_info.id = 1; result.base_info.name = name; result.base_info.level = 1; result.base_info.president = str(profile.get("player_id", "local")); result.base_info.president_name = str(profile.get("name", "Local Guest")); result.base_info.members_count = len(state["guild"]["members"])
            return 200, result
        if lower in {"/fci/guild/members", "/fci/guild/members/"}:
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            guild = self._guild_normalise(guild or {}, profile)
            state["guild"] = guild
            self._save(profile, state)
            result = self._message("ApiGuildMembers.get"); result.get.player_id = str(profile.get("player_id", "local")); result.get.name = str(profile.get("name", "Local Guest")); result.get.level = _int(profile.get("level"), 1); result.get.type = 1; return 200, result
        if lower in {"/fci/guild/exit", "/fci/guild/exit/"}:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            state["guild"] = None; self._save(profile, state); return 200, {}
        # The retired guild service is unavailable, so these operations use a
        # single persisted local guild and the same resource ledger as the
        # rest of the sandbox.  They keep the guild screens navigable without
        # pretending to reproduce cross-player coordination.
        if lower in {"/fci/guild/join", "/fci/guild/join/"}:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            state["guild"] = self._guild_normalise({"id": 1, "name": "Local Sandbox Guild", "level": 1, "contribution": 0, "skills": {}, "records": []}, profile)
            self._save(profile, state)
            return 200, {"ok": True, "guildId": 1, "name": state["guild"]["name"], "members": len(state["guild"]["members"]), "sandbox": True}
        if not isinstance(guild, dict):
            guild = {"id": 1, "name": "Local Sandbox Guild", "level": 1, "contribution": 0, "skills": {}, "records": []}
            state["guild"] = guild
        guild = self._guild_normalise(guild, profile)

        # JSON roster and guild summary endpoints are intentionally explicit so
        # local tooling can inspect all deterministic members even though the
        # damaged protobuf descriptor exposes only one ``get`` member field.
        if lower in {"/fci/guild/summary", "/fci/guild/info", "/fci/guild/members/list", "/fci/guild/member-list", "/fci/guild/roster"}:
            if method != "GET": return 405, {"error": "method_not_allowed", "message": "GET required"}
            self._save(profile, state)
            rows = self._guild_member_rows(guild, profile)
            return 200, {"guild": {"id": _int(guild.get("id"), 1), "name": str(guild.get("name")), "level": _int(guild.get("level"), 1), "exp": _int(guild.get("exp")), "president": str(guild.get("president")), "members": len(rows)}, "members": rows, "records": list(guild.get("records", [])), "sandbox": True}

        if lower in {"/fci/guild/member/invite", "/fci/guild/invite"}:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _json(body)
            target = str(request.get("playerId", request.get("targetId", ""))).strip()
            bots = {str(bot["playerId"]): bot for bot in self._guild_bot_members(profile)}
            if not target: target = next((key for key in bots if key not in {str(m.get("playerId")) for m in guild["members"]}), "")
            if target not in bots: return 404, {"error": "local_bot_not_found", "playerId": target}
            if any(str(item.get("playerId")) == target for item in guild["members"]):
                return 200, {"ok": True, "alreadyMember": True, "playerId": target, "sandbox": True}
            bot = bots[target]
            guild["pendingMembers"] = [item for item in guild.get("pendingMembers", []) if str(item.get("playerId")) != target]
            guild["members"].append({"playerId": target, "name": str(bot["name"]), "level": _int(bot.get("level"), 1), "avatar": _int(bot.get("avatar")), "online": bool(bot.get("online")), "contribution": 0, "actors": list(bot.get("actors", []))})
            self._guild_record(guild, {"type": "member_join", "playerId": target, "name": str(bot["name"]), "time": self._now(), "actor": str(profile.get("player_id", "local"))})
            self._save(profile, state)
            member = next((row for row in self._guild_member_rows(guild, profile) if row["playerId"] == target), None)
            return 200, {"ok": True, "accepted": True, "playerId": target, "member": member, "sandbox": True}

        if lower in {"/fci/guild/member/kick", "/fci/guild/kick", "/fci/guild/member/remove"}:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            target = str(_json(body).get("playerId", _json(body).get("targetId", ""))).strip()
            if not target: return 400, {"error": "player_id_required"}
            if target == str(guild.get("president")): return 409, {"error": "president_cannot_be_removed"}
            before = len(guild["members"]); guild["members"] = [item for item in guild["members"] if str(item.get("playerId")) != target]
            if len(guild["members"]) == before: return 404, {"error": "member_not_found", "playerId": target}
            self._guild_record(guild, {"type": "member_leave", "playerId": target, "time": self._now(), "actor": str(profile.get("player_id", "local"))})
            self._save(profile, state)
            return 200, {"ok": True, "removed": target, "members": len(guild["members"]), "sandbox": True}

        if lower in {"/fci/guild/vote", "/fci/guild/vote/status", "/fci/guild/president-vote"} and method == "GET":
            active = next((value for value in guild.get("votes", {}).values() if isinstance(value, Mapping) and value.get("status") in {"open", "passed"}), None)
            return 200, {"vote": dict(active) if active else None, "votes": list(guild.get("votes", {}).values()), "president": str(guild.get("president")), "sandbox": True}

        if lower in {"/fci/guild/vote/start", "/fci/guild/president-vote/start", "/fci/guild/transfer/start"}:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _json(body); target = str(request.get("playerId", request.get("targetId", ""))).strip()
            member_ids = {str(item.get("playerId")) for item in guild["members"]}
            if not target: target = next((item for item in member_ids if item.startswith("local-bot-")), "")
            if target not in member_ids: return 404, {"error": "member_not_found", "playerId": target}
            vote_id = str(max([_int(key) for key in guild.get("votes", {}) if str(key).isdigit()] or [0]) + 1)
            vote = {"id": int(vote_id), "candidate": target, "startedBy": str(profile.get("player_id", "local")), "startedAt": self._now(), "endsAt": self._now() + 86400, "status": "open", "votes": {}}
            guild.setdefault("votes", {})[vote_id] = vote
            self._guild_record(guild, {"type": "vote_start", "voteId": int(vote_id), "candidate": target, "time": self._now()})
            self._save(profile, state)
            return 200, {"ok": True, "vote": vote, "sandbox": True}

        if lower in {"/fci/guild/vote/cast", "/fci/guild/president-vote/cast", "/fci/guild/vote/resolve"}:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _json(body); vote_id = str(request.get("voteId", request.get("id", ""))).strip()
            vote = guild.get("votes", {}).get(vote_id)
            if not isinstance(vote, dict): return 404, {"error": "vote_not_found"}
            choice = bool(request.get("agree", request.get("yes", request.get("approve", True))))
            votes = vote.setdefault("votes", {}); votes[str(profile.get("player_id", "local"))] = choice
            # Local bots vote deterministically.  A majority makes the screen
            # useful immediately while preserving an auditable vote record.
            for member in guild["members"]:
                player_id = str(member.get("playerId", ""))
                if player_id.startswith("local-bot-"):
                    votes.setdefault(player_id, True)
            yes = sum(1 for value in votes.values() if bool(value)); total = len(guild["members"])
            vote["yes"] = yes; vote["no"] = len(votes) - yes; vote["status"] = "passed" if yes > total // 2 else "rejected" if (total - yes) > total // 2 else "open"
            if vote["status"] == "passed" and bool(request.get("transfer", False)):
                guild["president"] = str(vote["candidate"])
            self._guild_record(guild, {"type": "vote_cast", "voteId": _int(vote_id), "choice": choice, "status": vote["status"], "time": self._now()})
            self._save(profile, state)
            return 200, {"ok": True, "vote": vote, "president": str(guild.get("president")), "sandbox": True}

        if lower in {"/fci/guild/transfer", "/fci/guild/president-transfer"}:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _json(body); target = str(request.get("playerId", request.get("targetId", ""))).strip()
            if not any(str(item.get("playerId")) == target for item in guild["members"]): return 404, {"error": "member_not_found"}
            vote = next((item for item in guild.get("votes", {}).values() if isinstance(item, Mapping) and item.get("candidate") == target and item.get("status") == "passed"), None)
            if vote is None: return 409, {"error": "president_vote_required"}
            guild["president"] = target
            self._guild_record(guild, {"type": "president_transfer", "target": target, "time": self._now()})
            self._save(profile, state)
            return 200, {"ok": True, "president": target, "sandbox": True}

        if lower in {
            "/fci/guild/support",
            "/fci/guild/support/list",
            "/fci/guild/support/requests",
            "/fci/guild/assist",
            "/fci/guild/assist/list",
            "/fci/guild/assist/requests",
        } and method == "GET":
            support = guild["support"]
            return 200, {"requests": list(support.get("requests", [])), "offers": list(support.get("offers", [])), "sandbox": True}

        if lower in {
            "/fci/guild/support/request",
            "/fci/guild/support/create",
            "/fci/guild/assist/request",
            "/fci/guild/assist/create",
        }:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _json(body); actor_id = _int(request.get("actorId", request.get("id", 1001)), 1001); count = max(1, min(_int(request.get("count", 1), 1), 3))
            request_id = len(guild["support"].get("requests", [])) + 1
            item = {"id": request_id, "playerId": str(profile.get("player_id", "local")), "actorId": actor_id, "count": count, "status": "open", "createdAt": self._now()}
            guild["support"].setdefault("requests", []).append(item)
            # The first bot offers a deterministic support response.
            bot = self._guild_bot_members(profile)[0]
            offer = {"id": request_id, "requestId": request_id, "playerId": str(bot["playerId"]), "actorId": actor_id, "count": count, "status": "offered", "createdAt": self._now()}
            guild["support"].setdefault("offers", []).append(offer)
            self._guild_record(guild, {"type": "support_request", "requestId": request_id, "actorId": actor_id, "time": self._now()})
            self._save(profile, state)
            return 200, {"ok": True, "request": item, "offer": offer, "sandbox": True}

        if lower in {
            "/fci/guild/support/claim",
            "/fci/guild/support/obtain",
            "/fci/guild/assist/claim",
            "/fci/guild/assist/obtain",
        }:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _json(body); request_id = _int(request.get("requestId", request.get("id", 0)))
            found = next((item for item in guild["support"].get("requests", []) if _int(item.get("id")) == request_id), None)
            if found is None: return 404, {"error": "support_request_not_found"}
            if found.get("status") == "claimed": return 200, {"ok": True, "alreadyClaimed": True, "request": found, "sandbox": True}
            found["status"] = "claimed"; found["claimedAt"] = self._now()
            for offer in guild["support"].get("offers", []):
                if _int(offer.get("requestId")) == request_id: offer["status"] = "claimed"
            self._guild_record(guild, {"type": "support_claim", "requestId": request_id, "time": self._now()})
            self._save(profile, state)
            return 200, {"ok": True, "request": found, "actorId": _int(found.get("actorId")), "sandbox": True}

        if lower in {"/fci/guild/dungeon", "/fci/guild/dungeon/enter", "/fci/guild/dungeon/settle", "/fci/guild-dungeon/", "/fci/guild-dungeon"}:
            dungeon = guild["dungeon"]
            if method == "GET":
                return 200, {"guildId": _int(guild.get("id"), 1), "stage": _int(dungeon.get("stage"), 1), "score": _int(dungeon.get("score")), "attempts": _int(dungeon.get("attempts")), "history": list(dungeon.get("history", [])), "sandbox": True}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
            request = _json(body)
            stage = max(1, min(_int(request.get("stage", dungeon.get("stage", 1)), 1), 100))
            score = max(0, min(_int(request.get("score", 100), 100), 100000))
            dungeon["stage"] = max(_int(dungeon.get("stage"), 1), stage)
            dungeon["score"] = _int(dungeon.get("score")) + score
            dungeon["attempts"] = _int(dungeon.get("attempts")) + 1
            result = {"stage": stage, "score": score, "totalScore": _int(dungeon.get("score")), "attempt": _int(dungeon.get("attempts")), "finished": True, "time": self._now()}
            dungeon.setdefault("history", []).append(result); del dungeon["history"][:-50]
            self._guild_record(guild, {"type": "dungeon_clear", "stage": stage, "score": score, "time": self._now()})
            self._save(profile, state)
            return 200, {"ok": True, "result": result, "sandbox": True}

        if lower in {"/fci/guild-dungeon-record", "/fci/guild-dungeon-record/"}:
            if method != "GET": return 405, {"error": "method_not_allowed", "message": "GET required"}
            return 200, {"dungeonRecords": list(guild["dungeon"].get("history", [])), "score": _int(guild["dungeon"].get("score")), "sandbox": True}
        if "donat" in lower:
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            amount = max(1, _int(_json(body).get("amount", _json(body).get("count", 100)), 100))
            amount = min(amount, 10000)
            ok, changes, error = self._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": -amount}])
            if not ok: return 409, {"error": error or "insufficient_resource"}
            guild["contribution"] = _int(guild.get("contribution")) + amount
            guild["exp"] = _int(guild.get("exp")) + amount
            guild["records"].append({"type": "donate", "amount": amount, "time": self._now()}); del guild["records"][:-50]
            self._save(profile, state)
            return 200, {"ok": True, "contribution": guild["contribution"], "resChange": self._dynamic(changes), "sandbox": True}
        if "skill" in lower:
            skill_id = _int(_json(body).get("skillId", _json(body).get("id", 1)), 1)
            skills = guild["skills"]
            if method == "GET": return 200, {"skills": [{"id": _int(key), "level": _int(value, 1)} for key, value in skills.items()]}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            skills[str(skill_id)] = min(10, _int(skills.get(str(skill_id)), 0) + 1); self._save(profile, state)
            return 200, {"ok": True, "skillId": skill_id, "level": skills[str(skill_id)], "sandbox": True}
        if "rent" in lower or "lease" in lower:
            if method == "GET": return 200, {"actors": [{"id": 1001, "uid": 1001, "name": "Local Guild Support", "level": 1}]}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            return 200, {"ok": True, "actorId": 1001, "sandbox": True}
        if "record" in lower or "social-group" in lower:
            if method != "GET": return 405, {"error": "method_not_allowed", "message": "GET required"}
            return 200, {"records": list(guild["records"]), "group": {"id": 1, "name": guild["name"], "members": len(guild.get("members", []))}}
        if "dungeon" in lower:
            if method not in {"GET", "POST"}: return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
            return 200, {"guildId": 1, "stage": _int(guild["dungeon"].get("stage"), 1), "score": _int(guild["dungeon"].get("score")), "finished": method == "POST", "sandbox": True}
        return None

    def _name(self, method: str, route: str, body: Body, profile: Mapping[str, Any]) -> Optional[Response]:
        if route.lower() not in {"/fci/name", "/fci/name/"}:
            return None
        if method == "GET":
            return 200, {"notFirstRename": bool(profile.get("name"))}
        if method not in {"PATCH", "POST"}:
            return 405, {"error": "method_not_allowed", "message": "PATCH required"}
        request = _json(body); name = str(request.get("name", request.get("playerName", ""))).strip()[:16]
        if not name:
            return 400, {"error": "invalid_name"}
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute("UPDATE game_profiles SET name = ?, updated_at = ? WHERE account_id = ?", (name, self._now(), int(profile["account_id"])))
        return 200, {"notFirstRename": True}

    def _player_profile(self, method: str, route: str, body: Body,
                        profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        """Persist the player-facing profile and collection controls.

        ``playeraction.proto`` is one of the recovered files whose syntax
        field is corrupted, so its response messages cannot be safely loaded
        into the descriptor pool.  These routes deliberately return JSON with
        the same camelCase field names used by the Restifizer JSON fallback.
        No remote identity, avatar CDN, or payment service is contacted.
        """
        lower = route.lower()
        # ``LocalProfileFeatures`` owns the recovered protobuf-backed
        # profile/collection/notepad routes.  Keep only the seams that module
        # cannot safely expose because their playeraction descriptors are
        # absent, avoiding a broad JSON handler from shadowing typed replies.
        profile_routes = (
            "/fci/present-target-actor", "/fci/baseresource/level",
            "/fci/signboard", "/fci/emoji", "/fci/emojis",
        )
        if not any(lower == item or lower.startswith(item + "/") for item in profile_routes):
            return None
        # ProfileFeatures owns signboard mutations and typed replies; the
        # entering/bootstrap layer leaves only its GET projection unhandled.
        if lower.startswith("/fci/signboard") and method != "GET":
            return None

        player = state.setdefault("player_profile", {})
        if not isinstance(player, dict):
            player = {}
            state["player_profile"] = player
        defaults = self._default_state(profile)["player_profile"]
        for key, value in defaults.items():
            if key not in player:
                player[key] = json.loads(json.dumps(value))
        payload = self._request_values(body)

        if lower in {"/fci/baseinfo", "/fci/baseinfo/"}:
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            background = dict(player.get("homeBackGround", {}))
            return 200, {"result": {
                "level": _int(profile.get("level"), 1),
                "name": str(profile.get("name") or "Local Guest"),
                "lastLoginTime": self._now(),
                "socialPicture": str(player.get("socialPicture", "")),
                "headPhoto": _int(player.get("headPhoto")),
                "fightMedal": _int(player.get("fightMedal")),
                "sex": _int(player.get("sex")),
                "homeBackGround": {"current": _int(background.get("current")), "isRandom": bool(background.get("isRandom"))},
                "friendApplyLevelLimit": _int(player.get("friendApplyLevelLimit")),
                "sandbox": True,
            }}

        if lower in {"/fci/socialpicture", "/fci/socialpicture/"}:
            if method == "GET":
                return 200, {"result": {"sex": _int(player.get("sex")), "socialPicture": str(player.get("socialPicture", ""))}}
            if method not in {"POST", "PATCH"}:
                return 405, {"error": "method_not_allowed", "message": "POST or PATCH required"}
            if "socialPicture" in payload or "social_picture" in payload:
                player["socialPicture"] = str(payload.get("socialPicture", payload.get("social_picture", "")))[:512]
            if "sex" in payload:
                player["sex"] = max(0, min(2, _int(payload.get("sex"))))
            self._save(profile, state)
            return 200, {"result": {"sex": _int(player.get("sex")), "socialPicture": str(player.get("socialPicture", ""))}}

        if lower in {"/fci/home-back-ground", "/fci/home-back-ground/"}:
            if method == "GET":
                return 200, {"result": dict(player["homeBackGround"])}
            if method not in {"POST", "PATCH"}:
                return 405, {"error": "method_not_allowed", "message": "POST or PATCH required"}
            current = self._first_int(payload, "homeBackGround", "home_back_ground", "current", default=_int(player["homeBackGround"].get("current")))
            is_random = bool(payload.get("isRandom", payload.get("is_random", player["homeBackGround"].get("isRandom", False))))
            player["homeBackGround"] = {"current": max(0, current), "isRandom": is_random}
            self._save(profile, state)
            return 200, {"result": dict(player["homeBackGround"])}

        if lower in {"/fci/present-target-actor", "/fci/present-target-actor/"}:
            if method == "GET":
                return 200, {"result": {"presentTargetActor": _int(player.get("presentTargetActor"))}}
            if method not in {"POST", "PATCH"}:
                return 405, {"error": "method_not_allowed", "message": "POST or PATCH required"}
            player["presentTargetActor"] = max(0, self._first_int(payload, "presentTargetActor", "present_target_actor", "actorId", default=0))
            self._save(profile, state)
            return 200, {"result": {"presentTargetActor": _int(player.get("presentTargetActor"))}}

        if lower in {"/fci/baseresource/level", "/fci/baseresource/level/"}:
            if method == "GET":
                return 200, {"result": _int(profile.get("level"), 1)}
            if method not in {"POST", "PATCH"}:
                return 405, {"error": "method_not_allowed", "message": "POST or PATCH required"}
            level = max(1, min(60, self._first_int(payload, "level", default=_int(profile.get("level"), 1))))
            with self._lock, closing(self.game._connect()) as connection, connection:
                connection.execute("UPDATE game_profiles SET level = ?, updated_at = ? WHERE account_id = ?", (level, self._now(), int(profile["account_id"])))
            return 200, {"result": level, "sandbox": True}

        if lower in {"/fci/signboard", "/fci/signboard/"}:
            if method == "GET":
                return 200, dict(profile.get("signboard") or {"signboard": 101, "unlockedSignboardId": [101], "checkSignboardTime": 0})
            if method not in {"POST", "PATCH"}:
                return 405, {"error": "method_not_allowed", "message": "POST or PATCH required"}
            current = self._first_int(payload, "signboard", "signboardId", "id", default=_int((profile.get("signboard") or {}).get("signboard"), 101))
            unlocked = payload.get("unlockedSignboardId", payload.get("unlocked_signboard_id", [current]))
            if not isinstance(unlocked, list):
                unlocked = [current]
            signboard = {"signboard": max(0, current), "unlockedSignboardId": sorted({_int(item) for item in unlocked if _int(item) >= 0}), "checkSignboardTime": self._now()}
            with self._lock, closing(self.game._connect()) as connection, connection:
                connection.execute("UPDATE game_profiles SET signboard_json = ?, updated_at = ? WHERE account_id = ?", (json.dumps(signboard, separators=(",", ":")), self._now(), int(profile["account_id"])))
            try:
                result = self._message("ApiSignboard.result")
                result.signboard = signboard["signboard"]
                result.check_signboard_time = signboard["checkSignboardTime"]
                result.unlocked_signboard_id.extend(signboard["unlockedSignboardId"])
                return 200, result
            except Exception:
                return 200, signboard

        if lower.startswith(("/fci/collection", "/fci/collections")):
            collections = player.setdefault("collections", {"actors": [], "equips": [], "novels": []})
            if method == "GET":
                if lower.startswith("/fci/collections/actor"):
                    try:
                        result = self._message("ApiCollectionsActor.result")
                        for value in collections.get("actors", []):
                            row = result.actors.add(); row.id = _int(value); row.add_time = self._now()
                        return 200, result
                    except Exception:
                        pass
                return 200, {"collections": collections, "sandbox": True}
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            category = str(payload.get("category", payload.get("type", "actors"))).lower()
            category = {"actor": "actors", "equip": "equips", "novel": "novels"}.get(category, category)
            if category not in collections:
                return 400, {"error": "invalid_collection_category"}
            item_id = self._first_int(payload, "id", "itemId", "actorId", "equipId", "novelId", default=0)
            if item_id <= 0:
                return 400, {"error": "invalid_collection_id"}
            values = {int(item) for item in collections[category] if str(item).isdigit()}
            values.add(item_id); collections[category] = sorted(values)
            self._save(profile, state)
            if category == "actors":
                try:
                    result = self._message("ApiCollectionsActor.result")
                    for value in collections[category]:
                        row = result.actors.add(); row.id = value; row.add_time = self._now()
                    return 200, result
                except Exception:
                    pass
            if category == "equips":
                try:
                    result = self._message("ApiCollectionsEquip.result")
                    for value in collections[category]:
                        result.equips.add().equip_id = value
                    return 200, result
                except Exception:
                    pass
            return 200, {"collections": collections, "added": item_id, "sandbox": True}

        if lower.startswith(("/fci/novel-cover", "/fci/novelcover")):
            if method == "GET":
                return 200, {"novelCovers": list(player.get("novelCovers", [])), "sandbox": True}
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            cover_id = self._first_int(payload, "id", "coverId", "novelId", default=0)
            if cover_id <= 0:
                return 400, {"error": "invalid_cover_id"}
            covers = {int(item) for item in player.get("novelCovers", []) if str(item).isdigit()}; covers.add(cover_id)
            player["novelCovers"] = sorted(covers); self._save(profile, state)
            try:
                result = self._message("ApiCollectionsNovel.result")
                for value in player["novelCovers"]:
                    row = result.novels.add(); row.novel_id = value; row.cur_cover = value; row.cur_reward_num = 0; row.can_get_reward = False
                return 200, result
            except Exception:
                return 200, {"novelCovers": player["novelCovers"], "added": cover_id, "sandbox": True}

        if lower.startswith(("/fci/role-notepad", "/fci/rolenotepad")):
            note_id = self._first_int(payload, "id", "actorId", "roleId", default=0)
            if method == "GET":
                return 200, {"roleNotePad": dict(player.get("roleNotePad", {})), "sandbox": True}
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            if note_id <= 0:
                return 400, {"error": "invalid_role_id"}
            player.setdefault("roleNotePad", {})[str(note_id)] = {"id": note_id, "updatedAt": self._now(), "text": str(payload.get("text", ""))[:2000]}
            self._save(profile, state)
            try:
                result = self._message("ApiRoleNotePad.result")
                info = result.role_notepad
                info.role_id = note_id
                info.favour = 0
                info.favour_level = 1
                info.unlock_time = self._now()
                info.present_state = 0
                info.read_tag = _int(payload.get("readTag", payload.get("read_tag", 0)))
                return 200, result
            except Exception:
                return 200, {"roleNotePad": dict(player["roleNotePad"]), "sandbox": True}

        if lower.startswith(("/fci/emoji", "/fci/emojis")):
            if method == "GET":
                return 200, {"emojis": list(player.get("emojis", [])), "sandbox": True}
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            emoji_id = self._first_int(payload, "id", "emojiId", default=0)
            if emoji_id <= 0:
                return 400, {"error": "invalid_emoji_id"}
            values = {int(item) for item in player.get("emojis", []) if str(item).isdigit()}; values.add(emoji_id)
            player["emojis"] = sorted(values); self._save(profile, state)
            return 200, {"emojis": player["emojis"], "added": emoji_id, "sandbox": True}

        return None

    def _task(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if not lower.startswith("/fci/task"):
            return None
        # ``TaskFirstCheck`` posts this endpoint from the city update loop.
        # Treat it as an idempotent local telemetry update; it must not be
        # mistaken for the reward-claim endpoint below.
        if lower in {"/fci/task/target-done-add", "/fci/task/target-done-add/"}:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _json(body)
            target_id = _int(request.get("targetId", request.get("target_id", 0)))
            done = state.setdefault("taskTargetDone", [])
            if not isinstance(done, list):
                done = []
                state["taskTargetDone"] = done
            if target_id and target_id not in done:
                done.append(target_id)
                self._save(profile, state)
            # Empty JSON is valid for Restifizer's untyped POST callback and
            # keeps the client from trying to parse a nonexistent result.
            return 200, {}

        self._normalise_tasks(state)
        tasks = state["tasks"]
        if lower in {"/fci/task", "/fci/task/"} and method == "GET":
            rows = []
            for key, value in tasks.items():
                # Values are normalized above, but keep this projection
                # explicit so malformed historical state cannot leak through
                # to the wire response.
                task = self._normalise_task(key, value, self._now())
                rows.append(task)
            return 200, {
                "tasks": rows,
                "delTasks": [],
                "disableCategory": [],
                "activePoint": 0,
                "activePointRewardGot": [],
                "taskTargetDone": list(state.get("taskTargetDone", [])),
                "clearAll": True,
            }
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        request = _json(body)
        task_id = str(_int(request.get("taskId", request.get("id", 1)), 1))
        value = tasks.setdefault(task_id, self._normalise_task(task_id, {}, self._now()))
        value.update(self._normalise_task(task_id, value, self._now()))
        changes = []
        if not value.get("rewardGot"):
            value["progress"] = max(_int(value.get("progress")), _int(value.get("maxProgress"), 1)); value["rewardGot"] = True; value["isDone"] = True; value["status"] = 1
            ok, changes, _ = self.game.economy._change_resources(profile, [{"type": 7, "id": 0, "count": 100, "param": 0}])
            if not ok:
                return 409, {"error": "resource_update_failed"}
        self._save(profile, state)
        return 200, {"tasks": [], "resChange": [{"type": item.get("type", 0), "id": item.get("id", 0), "count": item.get("count", 0), "countDelta": item.get("countDelta", 0), "param": item.get("param", 0)} for item in changes]}

    def _handle_http_unlocked(self, method: str, path: str, body: Body, profile: Mapping[str, Any]) -> Optional[Response]:
        method = method.upper(); route = _route(path)
        state = self._state(profile)
        # More specific maintenance routes must run before the historical
        # broad actor/equipment handlers (which intentionally accept generic
        # PATCH payloads for compatibility).
        for handler in (self._player_profile, self._actor_maintenance, self._equipment_maintenance, self._item_resource, self._medal_seal_cultivation,
                        self._gacha, self._actor, self._equip, self._mail, self._relation, self._guild):
            result = handler(method, route, body, profile, state)
            if result is not None:
                return result
        result = self._task(method, route, body, profile, state)
        if result is not None:
            return result
        result = self._name(method, route, body, profile)
        if result is not None:
            return result
        result = self._pvp(method, route, body, profile)
        if result is not None:
            return result
        return None


    def handle_http(self, method: str, path: str, body: Body, profile: Mapping[str, Any]) -> Optional[Response]:
        """Serialize actor/equipment/mail/social mutations per profile."""
        with self._lock:
            return self._handle_http_unlocked(method, path, body, profile)



__all__ = ["LocalSystems"]

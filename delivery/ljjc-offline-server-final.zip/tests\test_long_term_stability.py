from __future__ import annotations

import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

from accounts import LocalAccounts
from events import LocalEvents
from game import LocalGame
from server.core.activity_schedule import ActivitySchedule
from server.core.clock import ServerClock


def _guest(accounts: LocalAccounts) -> dict:
    """Create the same local guest account shape used by the API tests."""

    first = accounts.handle("POST", "/AccountSession/", b"", "application/wireformat")
    account_token = "AccountToken " + first[1]["accountToken"]
    entry = accounts.handle(
        "POST", "/EntryReg/", b'{"entryType":"guest"}', "application/json", account_token
    )[1]["entry"]["entry"]
    accounts.handle("POST", "/Account/", b'{"entryType":"guest"}', "application/json", account_token)
    second = accounts.handle("POST", "/AccountSession/", b"", "application/wireformat")
    auth_token = "AccountToken " + second[1]["accountToken"]
    value = entry.encode() if isinstance(entry, str) else entry
    request = b"\x0a" + bytes((len(value),)) + value + b"\x12\x05guest"
    result = accounts.handle("POST", "/Auth/", request, "application/wireformat", auth_token)
    return accounts.verify_access_token(result[1]["tokenAccess"])


class LongTermStabilityTests(unittest.TestCase):
    def test_passive_power_recovery_persists_and_writes_audit_entry(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            now = [1_767_247_140]  # 2026-01-01 05:59 UTC
            clock = ServerClock(source=lambda: now[0])
            accounts = LocalAccounts(root / "state", clock=clock.now)
            game = LocalGame(root / "state", accounts, clock=clock.now)
            account = _guest(accounts)

            initial = game._profile(account)
            power = next(item for item in initial["resources"] if item["type"] == 6)
            self.assertEqual(power["count"], 120)
            ok, _changes, error = game.economy._change_resources(
                initial, [{"type": 6, "id": 0, "param": 0, "count": -10}]
            )
            self.assertTrue(ok, error)
            self.assertEqual(next(item for item in game._profile(account)["resources"] if item["type"] == 6)["count"], 110)

            # Two six-minute intervals recover two points after reconnect.
            now[0] += 2 * 360
            recovered = game._profile(account)
            self.assertEqual(next(item for item in recovered["resources"] if item["type"] == 6)["count"], 112)
            with closing(game._connect()) as connection:
                rows = connection.execute(
                    "SELECT operation, resource_type, delta, balance_after, reason FROM local_resource_ledger WHERE account_id = ?",
                    (account["accountId"],),
                ).fetchall()
            self.assertEqual([(row[0], row[1], row[2], row[3], row[4]) for row in rows],
                             [("grant", 6, 2, 112, "passive_energy_recovery")])

            # Re-reading at the same timestamp must not duplicate the grant,
            # including after constructing a fresh game instance.
            again = LocalGame(root / "state", accounts, clock=clock.now)
            reread = again._profile(account)
            self.assertEqual(next(item for item in reread["resources"] if item["type"] == 6)["count"], 112)
            with closing(again._connect()) as connection:
                self.assertEqual(
                    connection.execute(
                        "SELECT COUNT(*) FROM local_resource_ledger WHERE account_id = ?",
                        (account["accountId"],),
                    ).fetchone()[0],
                    1,
                )

    def test_twenty_eight_day_restart_loop_covers_daily_weekly_and_month_card_state(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            start = int(datetime(2026, 10, 26, 6, tzinfo=timezone.utc).timestamp())
            now = [start]
            clock = ServerClock(source=lambda: now[0])
            accounts = LocalAccounts(root / "state", clock=clock.now)
            game = LocalGame(root / "state", accounts, clock=clock.now)
            game.daily_key = lambda value=None: clock.daily_key(value, refresh_at="06:00:00")
            account = _guest(accounts)

            # Establish the recovery marker and a non-full balance before the
            # simulated restarts begin.
            profile = game._profile(account)
            ok, _changes, error = game.economy._change_resources(
                profile, [{"type": 6, "id": 0, "param": 0, "count": -14}]
            )
            self.assertTrue(ok, error)
            sign_in_days = []
            # Include both endpoints: 29 sign-ins exercise 28 daily reset
            # boundaries and four weekly buckets, which is the full activity
            # cycle used by the local schedule.
            for day in range(29):
                restarted = LocalGame(root / "state", accounts, clock=clock.now)
                restarted.daily_key = lambda value=None, _clock=clock: _clock.daily_key(value, refresh_at="06:00:00")
                active_profile = restarted._profile(account)
                events = LocalEvents(restarted, clock=clock.now)
                status, signin = events.handle_http("POST", "/fci/signin", None, active_profile)
                self.assertEqual(status, 200)
                sign_in_days.append(int(signin.days))
                status, _reward = restarted.economy.handle_http(
                    "POST", "/fci/recharge/month-card/reward/",
                    b'{"monthCardCfgId":1}', account,
                )
                self.assertEqual(status, 200)
                if day < 28:
                    now[0] += 86400

            self.assertEqual(sign_in_days, list(range(1, 30)))
            final = game._profile(account)
            self.assertEqual(next(item for item in final["resources"] if item["type"] == 6)["count"], 120)
            paid = next(item for item in final["resources"] if item["type"] == 5)
            self.assertEqual(paid["count"], 30 * 29)
            self.assertEqual(clock.period_elapsed(start, now[0], period="weekly", refresh_at="06:00"), 4)

    def test_activity_rotation_is_deterministic_across_cycle_boundaries(self):
        source = Path(__file__).resolve().parents[1] / "data" / "server-only" / "activity-schedule.yaml"
        schedule = ActivitySchedule(source, clock=lambda: 0)
        anchor = datetime(2026, 10, 26, 6, tzinfo=timezone.utc)
        at_start = schedule.snapshot(anchor)
        at_week = schedule.snapshot(anchor.timestamp() + 7 * 86400)
        at_cycle = schedule.snapshot(anchor.timestamp() + 28 * 86400)
        self.assertEqual(at_start["cycleDay"], 0)
        self.assertEqual({item["id"] for item in at_start["active"]}, {"sign-in", "shop"})
        self.assertEqual({item["id"] for item in at_week["active"]}, {"shop", "sandbox-gacha"})
        self.assertEqual({item["id"] for item in at_cycle["active"]}, {"sign-in", "shop"})


if __name__ == "__main__":
    unittest.main()

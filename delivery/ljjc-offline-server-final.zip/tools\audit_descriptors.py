#!/usr/bin/env python3
"""Audit protobuf descriptors against the recovered API contract table.

The descriptor set came from a retired client and contains a few malformed or
incomplete files.  This tool deliberately reports those gaps instead of
inventing fields.  It is useful for M2.6 acceptance and is safe to run against
the read-only APK analysis outputs.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

import yaml
from google.protobuf import (
    any_pb2,
    api_pb2,
    descriptor_pb2,
    descriptor_pool,
    duration_pb2,
    empty_pb2,
    field_mask_pb2,
    source_context_pb2,
    struct_pb2,
    timestamp_pb2,
    type_pb2,
    wrappers_pb2,
)


def _load_contracts(path: Path) -> list[Mapping[str, Any]]:
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, Mapping) or not isinstance(raw.get("interfaces"), list):
        raise ValueError("contract file must contain an interfaces list")
    return [item for item in raw["interfaces"] if isinstance(item, Mapping)]


def _load_descriptors(path: Path) -> tuple[
    list[descriptor_pb2.FileDescriptorProto],
    list[dict[str, str]],
    list[dict[str, str]],
]:
    document = descriptor_pb2.FileDescriptorSet.FromString(path.read_bytes())
    valid: list[descriptor_pb2.FileDescriptorProto] = []
    skipped: list[dict[str, str]] = []
    repaired: list[dict[str, str]] = []
    for item in document.file:
        if isinstance(item.syntax, bytes) or item.syntax not in {"", "proto2", "proto3"}:
            # Some exports were produced through a Python protobuf helper that
            # accidentally serialized the syntax string as arbitrary bytes.
            # The descriptor body (including nested messages and field
            # numbers) remains intact.  Normalize only this metadata field so
            # the pool can resolve the recovered messages, and record the
            # repair explicitly in the report.  We never infer fields.
            original = (
                bytes(item.syntax).hex()
                if isinstance(item.syntax, bytes)
                else str(item.syntax).encode("utf-8", "backslashreplace").hex()
            )
            item.syntax = "proto3"
            repaired.append({
                "file": item.name,
                "reason": "malformed syntax field normalized to proto3; message fields were not changed",
                "originalHex": original,
            })
        valid.append(item)
    return valid, skipped, repaired


def _build_pool(files: Iterable[descriptor_pb2.FileDescriptorProto]) -> tuple[descriptor_pool.DescriptorPool, list[dict[str, str]]]:
    # Use a fresh pool so repeated audits do not depend on whichever modules a
    # caller imported earlier.  The recovered set references these standard
    # protobuf files, including timestamp.proto from account91.proto.
    pool = descriptor_pool.DescriptorPool()
    standard_modules = (
        descriptor_pb2, any_pb2, duration_pb2, empty_pb2, field_mask_pb2,
        source_context_pb2, struct_pb2, timestamp_pb2, type_pb2,
        wrappers_pb2, api_pb2,
    )
    for module in standard_modules:
        try:
            pool.AddSerializedFile(module.DESCRIPTOR.serialized_pb)
        except Exception:
            # A standard descriptor may already be provided as part of an
            # imported dependency.  The audit still has its local input set.
            pass
    pending = list(files)
    unresolved: list[dict[str, str]] = []
    while pending:
        next_pending: list[descriptor_pb2.FileDescriptorProto] = []
        progress = 0
        for file_descriptor in pending:
            try:
                pool.FindFileByName(file_descriptor.name)
                progress += 1
                continue
            except KeyError:
                pass
            try:
                pool.Add(file_descriptor)
                progress += 1
            except Exception as exc:  # descriptor errors are report data
                next_pending.append((file_descriptor, exc))
        if not next_pending:
            break
        if progress == 0:
            unresolved = [
                {
                    "file": item.name,
                    "error": str(error).encode("ascii", "replace").decode("ascii"),
                }
                for item, error in next_pending
            ]
            break
        pending = [item for item, _error in next_pending]
    return pool, unresolved


def _declared_messages(files: Iterable[descriptor_pb2.FileDescriptorProto]) -> set[str]:
    names: set[str] = set()
    for file_descriptor in files:
        prefix = f"{file_descriptor.package}." if file_descriptor.package else ""

        def visit(messages: Iterable[descriptor_pb2.DescriptorProto], parent: str) -> None:
            for message in messages:
                full_name = f"{parent}{message.name}"
                names.add(full_name)
                visit(message.nested_type, f"{full_name}.")

        visit(file_descriptor.message_type, prefix)
    return names


def _message_count(messages: Iterable[descriptor_pb2.DescriptorProto]) -> int:
    """Count top-level and nested messages without flattening their fields."""

    total = 0
    for message in messages:
        total += 1 + _message_count(message.nested_type)
    return total


def _descriptor_inventory(
    files: Iterable[descriptor_pb2.FileDescriptorProto],
    repaired_files: Iterable[Mapping[str, str]],
) -> list[dict[str, Any]]:
    repaired_names = {str(item.get("file")) for item in repaired_files}
    inventory: list[dict[str, Any]] = []
    for file_descriptor in files:
        serialized = file_descriptor.SerializeToString()
        inventory.append({
            "file": file_descriptor.name,
            "package": file_descriptor.package,
            "syntax": "proto3" if file_descriptor.syntax == "proto3" else (file_descriptor.syntax or "unspecified"),
            "syntaxStatus": "normalized_metadata" if file_descriptor.name in repaired_names else "as_extracted",
            "sha256": hashlib.sha256(serialized).hexdigest(),
            "dependencies": sorted(file_descriptor.dependency),
            "topLevelMessages": len(file_descriptor.message_type),
            "messageCountIncludingNested": _message_count(file_descriptor.message_type),
            "enumCount": len(file_descriptor.enum_type),
            "serviceCount": len(file_descriptor.service),
            "extensionCount": len(file_descriptor.extension),
        })
    return sorted(inventory, key=lambda item: str(item["file"]))


def _contract_types(interfaces: Iterable[Mapping[str, Any]]) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    uses: dict[str, list[str]] = defaultdict(list)
    enum_uses: dict[str, list[str]] = defaultdict(list)
    for interface in interfaces:
        name = str(interface.get("interface", "unknown"))
        response_fields = interface.get("responseFields") or {}
        request_fields = [field for field in interface.get("requestFields") or [] if isinstance(field, Mapping)]
        for field_group in list(response_fields.values()) + [request_fields]:
            if not isinstance(field_group, list):
                continue
            for field in field_group:
                if not isinstance(field, Mapping):
                    continue
                type_name = str(field.get("type_name") or "")
                if type_name.startswith("."):
                    type_name = type_name[1:]
                if not type_name:
                    continue
                target = enum_uses if str(field.get("type", "")).lower() == "enum" else uses
                if name not in target[type_name]:
                    target[type_name].append(name)
    return dict(uses), dict(enum_uses)


def audit(descriptor_path: Path, contracts_path: Path) -> dict[str, Any]:
    files, skipped_files, repaired_files = _load_descriptors(descriptor_path)
    pool, unresolved_files = _build_pool(files)
    inventory = _descriptor_inventory(files, repaired_files)
    declared = _declared_messages(files)
    uses, enum_uses = _contract_types(_load_contracts(contracts_path))
    resolved: list[str] = []
    missing: list[str] = []
    declared_but_unresolved: list[str] = []
    for type_name in sorted(uses):
        try:
            pool.FindMessageTypeByName(type_name)
        except KeyError:
            missing.append(type_name)
            if type_name in declared:
                declared_but_unresolved.append(type_name)
        else:
            resolved.append(type_name)
    missing_enums: list[str] = []
    resolved_enums: list[str] = []
    for type_name in sorted(enum_uses):
        try:
            pool.FindEnumTypeByName(type_name)
        except KeyError:
            missing_enums.append(type_name)
        else:
            resolved_enums.append(type_name)
    return {
        "schemaVersion": 1,
        "descriptorSet": str(descriptor_path),
        "contracts": str(contracts_path),
        "fileCount": len(files),
        "skippedFiles": skipped_files,
        "repairedFiles": repaired_files,
        "unresolvedFiles": unresolved_files,
        "descriptorInventory": inventory,
        "descriptorTotals": {
            "messageCountIncludingNested": sum(item["messageCountIncludingNested"] for item in inventory),
            "enumCount": sum(item["enumCount"] for item in inventory),
            "serviceCount": sum(item["serviceCount"] for item in inventory),
            "dependencyEdges": sum(len(item["dependencies"]) for item in inventory),
        },
        "contractMessageTypes": {
            "total": len(uses),
            "resolved": len(resolved),
            "missing": len(missing),
            "resolvedNames": resolved,
            "missingNames": missing,
            "declaredButUnresolved": declared_but_unresolved,
            "usedBy": {name: uses[name] for name in sorted(uses)},
        },
        "contractEnumTypes": {
            "total": len(enum_uses),
            "resolved": len(resolved_enums),
            "missing": len(missing_enums),
            "resolvedNames": resolved_enums,
            "missingNames": missing_enums,
            "usedBy": {name: enum_uses[name] for name in sorted(enum_uses)},
        },
        "notes": [
            "Missing types are reported for follow-up; no fields are fabricated.",
            "A declared-but-unresolved type is present in the recovered descriptor set but blocked by another malformed or missing dependency.",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--descriptor-set", type=Path, default=Path("data/descriptor_set.pb"))
    parser.add_argument("--contracts", type=Path, default=Path("contracts/api.yaml"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.descriptor_set, args.contracts)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), **result["contractMessageTypes"], "enumTypes": result["contractEnumTypes"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


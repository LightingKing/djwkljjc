[CmdletBinding()]
param(
    [string]$SdkRoot = 'C:\Users\Administrator\AppData\Local\Android\Sdk',
    [string]$Serial = 'emulator-5562',
    [string]$PackageName = 'com.tencent.tmgp.fcicv',
    [int]$Runs = 5,
    [string]$Output = ''
)

$ErrorActionPreference = 'Stop'
if ($Runs -lt 1 -or $Runs -gt 20) { throw 'Runs must be between 1 and 20.' }
$adb = Join-Path $SdkRoot 'platform-tools\adb.exe'
if (-not (Test-Path -LiteralPath $adb)) { throw "adb not found: $adb" }
$state = @()
try {
    $state = @(& $adb -s $Serial get-state 2>$null)
} catch {
    $state = @()
}
if ($state -notcontains 'device') { throw "$Serial is not an online adb device." }
$outputPath = if ($Output) { [IO.Path]::GetFullPath($Output) } else { Join-Path $PSScriptRoot 'cold-start-report.json' }
$records = @()

for ($index = 1; $index -le $Runs; $index++) {
    $started = Get-Date
    # Force-stop only the target package. No pm clear/uninstall is used, so
    # this check preserves the local save while testing repeated launches.
    & $adb -s $Serial shell am force-stop $PackageName | Out-Null
    & $adb -s $Serial shell monkey -p $PackageName 1 | Out-Null
    Start-Sleep -Seconds 3
    $focusedLine = & $adb -s $Serial shell dumpsys activity activities 2>$null | Select-String -Pattern $PackageName | Select-Object -First 1
    $focused = if ($focusedLine) { $focusedLine.ToString() } else { '' }
    $fatal = @(& $adb -s $Serial logcat -d -t 400 2>$null | Select-String -Pattern 'FATAL EXCEPTION|has died|Process .* crashed')
    $records += [pscustomobject]@{
        run = $index
        startedAt = $started.ToUniversalTime().ToString('o')
        focusedPackage = ($focused -match [regex]::Escape($PackageName))
        fatalLogLines = $fatal.Count
    }
}

$report = [pscustomobject]@{
    serial = $Serial
    package = $PackageName
    runs = $Runs
    passed = @($records | Where-Object { $_.focusedPackage -and $_.fatalLogLines -eq 0 }).Count -eq $Runs
    records = $records
}
$parent = Split-Path -Parent $outputPath
if ($parent) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
$report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $outputPath -Encoding UTF8
$report | ConvertTo-Json -Depth 5
if (-not $report.passed) { exit 2 }

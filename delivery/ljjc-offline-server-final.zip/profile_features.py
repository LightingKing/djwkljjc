"""Persistent local player profile, notice and web activity compatibility.

The retired service exposed these endpoints as small protobuf resources.  The
local implementation keeps the data in the same SQLite database as the game
profile and only models fields the client can use.  It is deliberately a
local sandbox: names, pictures, collections, notice flags and vote counts do
not leave the machine and no remote web activity is contacted.
"""

from __future__ import annotations

import json
import time
from contextlib import closing
from typing import Any, Mapping, Optional
from urllib.parse import urlsplit

from google.protobuf import message_factory


Body = bytes | bytearray | str | None
Response = tuple[int, Any]


def _route(path: str) -> str:
    value = urlsplit(path or "").path or "/"
    return value.rstrip("/") or "/"


def _json(body: Body) -> dict[str, Any]:
    if body is None:
        return {}
    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return dict(value) if isinstance(value, Mapping) else {}


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


class LocalProfileFeatures:
    """Local player-info, notices, collections and web-vote state."""

    def __init__(self, game: Any, *, clock=None) -> None:
        self.game = game
        self._lock = game._lock
        self._clock = clock or game._now
        with self._lock, closing(game._connect()) as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS local_profile_features (
                    account_id INTEGER PRIMARY KEY,
                    state_json TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )

    def _now(self) -> int:
        return int(self._clock())

    def _message(self, name: str):
        # ``playeraction.proto`` in the recovered APK has a damaged syntax
        # field.  The pool safely skips that file, so a handful of player
        # profile messages are unavailable even though adjacent messages are
        # usable.  Callers fall back to the same camelCase JSON shape instead
        # of turning a cosmetic profile request into a 500.
        try:
            return message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName(name))()
        except Exception:
            return None

    def _request(self, body: Body, name: str):
        raw = body.encode("utf-8") if isinstance(body, str) else bytes(body or b"")
        if not raw:
            return None
        try:
            value = self._message(name)
            value.ParseFromString(raw)
            return value
        except Exception:
            return None

    @staticmethod
    def _default_state(profile: Mapping[str, Any]) -> dict[str, Any]:
        return {
            "socialPicture": "",
            "sex": 0,
            "headPhoto": 0,
            "fightMedal": 0,
            "homeBackground": {"current": 0, "isRandom": False},
            "friendApplyLevelLimit": 0,
            "signboard": dict(profile.get("signboard") or {"signboard": 101, "unlockedSignboardId": [101], "checkSignboardTime": 0}),
            "readNotices": [],
            "sharedNotices": [],
            "noticeRewards": [],
            "notepad": {},
            "collections": {"actors": [], "equips": [], "novels": []},
            "webVote": {
                "roles": [
                    {"roleId": 1001, "roleName": "逢坂大河", "image": "", "voteCount": 0, "sortId": 1, "novel": "", "novelId": 1},
                    {"roleId": 1002, "roleName": "司波深雪", "image": "", "voteCount": 0, "sortId": 2, "novel": "", "novelId": 2},
                    {"roleId": 1003, "roleName": "桐乃", "image": "", "voteCount": 0, "sortId": 3, "novel": "", "novelId": 3},
                ],
                "ticketNum": 10,
                "bangNum": 0,
                "myVotes": {},
            },
            "share": {"weeklyRewarded": False, "actorRewardGot": 0},
            "jigsaw": {"cells": [], "received": False},
            "postcard": {"cells": [], "received": False},
            "clawCrane": {"draws": 0, "prizes": [], "bingo": []},
        }

    def _state(self, profile: Mapping[str, Any]) -> dict[str, Any]:
        account_id = int(profile["account_id"])
        with self._lock, closing(self.game._connect()) as connection, connection:
            row = connection.execute(
                "SELECT state_json FROM local_profile_features WHERE account_id = ?", (account_id,)
            ).fetchone()
            if row is None:
                state = self._default_state(profile)
                connection.execute(
                    "INSERT OR IGNORE INTO local_profile_features(account_id,state_json,updated_at) VALUES(?,?,?)",
                    (account_id, json.dumps(state, ensure_ascii=False, separators=(",", ":")), self._now()),
                )
                return state
            try:
                state = json.loads(row["state_json"] or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                state = {}
            if not isinstance(state, dict):
                state = {}
            defaults = self._default_state(profile)
            changed = False
            for key, value in defaults.items():
                if key not in state:
                    state[key] = value
                    changed = True
            if changed:
                connection.execute(
                    "UPDATE local_profile_features SET state_json = ?, updated_at = ? WHERE account_id = ?",
                    (json.dumps(state, ensure_ascii=False, separators=(",", ":")), self._now(), account_id),
                )
            return state

    def _save(self, profile: Mapping[str, Any], state: Mapping[str, Any]) -> None:
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                "UPDATE local_profile_features SET state_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(dict(state), ensure_ascii=False, separators=(",", ":")), self._now(), int(profile["account_id"])),
            )

    def _set_profile_columns(self, profile: Mapping[str, Any], **values: Any) -> None:
        allowed = {"name", "level"}
        values = {key: value for key, value in values.items() if key in allowed}
        if not values:
            return
        assignments = ", ".join(f"{key} = ?" for key in values)
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                f"UPDATE game_profiles SET {assignments}, updated_at = ? WHERE account_id = ?",
                [*values.values(), self._now(), int(profile["account_id"])],
            )

    def _set_signboard_profile(self, profile: Mapping[str, Any], signboard: Mapping[str, Any]) -> None:
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                "UPDATE game_profiles SET signboard_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(dict(signboard), ensure_ascii=False, separators=(",", ":")), self._now(), int(profile["account_id"])),
            )

    def _base_info(self, profile: Mapping[str, Any], state: Mapping[str, Any]):
        result = self._message("ApiPlayerBaseInfo.result")
        if result is None:
            background = state.get("homeBackground") if isinstance(state.get("homeBackground"), Mapping) else {}
            return {"result": {
                "level": _int(profile.get("level"), 1), "name": str(profile.get("name", "")),
                "lastLoginTime": _int(profile.get("updated_at"), self._now()),
                "socialPicture": str(state.get("socialPicture", "")), "headPhoto": _int(state.get("headPhoto")),
                "fightMedal": _int(state.get("fightMedal")), "sex": _int(state.get("sex")),
                "homeBackGround": {"current": _int(background.get("current")), "isRandom": bool(background.get("isRandom", False))},
                "friendApplyLevelLimit": _int(state.get("friendApplyLevelLimit")), "sandbox": True,
            }}
        result.level = _int(profile.get("level"), 1)
        result.name = str(profile.get("name", ""))
        result.last_login_time = _int(profile.get("updated_at"), self._now())
        result.social_picture = str(state.get("socialPicture", ""))
        result.head_photo = _int(state.get("headPhoto"))
        result.fight_medal = _int(state.get("fightMedal"))
        result.sex = _int(state.get("sex"))
        background = state.get("homeBackground") if isinstance(state.get("homeBackground"), Mapping) else {}
        result.home_back_ground.current = _int(background.get("current"))
        result.home_back_ground.is_random = bool(background.get("isRandom", False))
        result.friend_apply_level_limit = _int(state.get("friendApplyLevelLimit"))
        return result

    def _social_picture(self, method: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Response:
        request = _json(body)
        message = self._request(body, "ApiPlayerSocialPicture")
        picture = request.get("socialPicture", request.get("social_picture", getattr(message, "social_picture", "") if message else ""))
        sex = _int(request.get("sex", getattr(message, "sex", state.get("sex", 0)) if message else state.get("sex", 0)))
        if method in {"POST", "PATCH", "PUT"}:
            state["socialPicture"] = str(picture)[:512]
            state["sex"] = max(0, sex)
            self._save(profile, state)
        result = self._message("ApiPlayerSocialPicture.result")
        if result is None:
            return 200, {"result": {"sex": _int(state.get("sex")), "socialPicture": str(state.get("socialPicture", "")), "sandbox": True}}
        result.sex = _int(state.get("sex"))
        result.social_picture = str(state.get("socialPicture", ""))
        return 200, result

    def _home_background(self, method: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Response:
        request = _json(body)
        message = self._request(body, "ApiHomeBackGround")
        current = _int(request.get("homeBackGround", request.get("homeBackground", request.get("current", getattr(message, "home_back_ground", 0) if message else 0))))
        is_random = _int(request.get("isRandom", request.get("is_random", getattr(message, "is_random", 0) if message else 0))) != 0
        if method in {"POST", "PATCH", "PUT"}:
            state["homeBackground"] = {"current": max(0, current), "isRandom": is_random}
            self._save(profile, state)
        result = self._message("ApiHomeBackGround.result")
        if result is None:
            background = state.get("homeBackground", {})
            return 200, {"result": {"current": _int(background.get("current")), "isRandom": bool(background.get("isRandom", False)), "sandbox": True}}
        result.home_back_ground.current = _int(state.get("homeBackground", {}).get("current"))
        result.home_back_ground.is_random = bool(state.get("homeBackground", {}).get("isRandom", False))
        return 200, result

    def _signboard(self, method: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Response:
        request = _json(body)
        message = self._request(body, "ApiSignboard")
        current = _int(request.get("signboard", getattr(message, "signboard", state.get("signboard", {}).get("signboard", 101)) if message else state.get("signboard", {}).get("signboard", 101)))
        signboard = state.setdefault("signboard", {"signboard": 101, "unlockedSignboardId": [101], "checkSignboardTime": 0})
        unlocked = signboard.setdefault("unlockedSignboardId", [signboard.get("signboard", 101)])
        if method in {"POST", "PATCH", "PUT"}:
            # A local sandbox may explicitly seed a recovered board id.  The
            # client has no remote unlock service to consult, so accepting an
            # explicit list keeps the preview/use flow deterministic while
            # retaining the locked-board error for ordinary requests.
            requested_unlocked = request.get("unlockedSignboardId", request.get("unlocked_signboard_id"))
            if isinstance(requested_unlocked, list):
                unlocked[:] = sorted({_int(item) for item in [*unlocked, *requested_unlocked] if _int(item) >= 0})
            if current not in unlocked:
                return 409, {"error": "signboard_locked", "signboard": current}
            signboard["signboard"] = current
            signboard["checkSignboardTime"] = self._now()
            self._set_signboard_profile(profile, signboard)
            self._save(profile, state)
        result = self._message("ApiSignboard.result")
        if result is None:
            return 200, {"result": dict(signboard), "sandbox": True}
        result.signboard = _int(signboard.get("signboard"), 101)
        result.check_signboard_time = _int(signboard.get("checkSignboardTime"))
        result.unlocked_signboard_id.extend(_int(item) for item in unlocked)
        return 200, result

    def _notices(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if not ("notice" in lower or "server-update-info" in lower or "broadcast" in lower):
            return None
        payload = _json(body)
        notice_id = _int(payload.get("noticeId", payload.get("id", 1)), 1)
        index = _int(payload.get("index", 0))
        if "read-status" in lower or lower.endswith("/read"):
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            key = f"{notice_id}:{index}"
            if key not in state.setdefault("readNotices", []):
                state["readNotices"].append(key)
            self._save(profile, state)
            if "status" in lower:
                result = self._message("ApiPlayerNoticeReadStatus.result")
                if result is None:
                    return 200, {"notices": [{"noticeId": notice_id, "readStatus": 1, "index": index}], "sandbox": True}
                item = result.notices.add(); item.notice_id = notice_id; item.read_status = 1; item.index = index
                return 200, result
            result = self._message("ApiPlayerNoticeRead.result")
            if result is None:
                return 200, {"result": {"ret": 1}, "sandbox": True}
            result.result.ret = 1; return 200, result
        if "share-status" in lower or lower.endswith("/share"):
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            key = f"{notice_id}:{index}"
            if key not in state.setdefault("sharedNotices", []):
                state["sharedNotices"].append(key)
            self._save(profile, state)
            if "status" in lower:
                result = self._message("ApiPlayerNoticeShareStatus.result")
                if result is None:
                    return 200, {"notices": [{"noticeId": notice_id, "shareStatus": 1, "index": index}], "sandbox": True}
                item = result.notices.add(); item.notice_id = notice_id; item.share_status = 1; item.index = index
                return 200, result
            result = self._message("ApiPlayerNoticeShare.result")
            if result is None:
                return 200, {"result": {"ret": 1}, "sandbox": True}
            result.result.ret = 1; return 200, result
        if "reward" in lower or "bind" in lower:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            key = f"{notice_id}:{index}"
            if key in state.setdefault("noticeRewards", []):
                return 409, {"error": "notice_reward_already_claimed"}
            state["noticeRewards"].append(key); self._save(profile, state)
            response_name = "ApiBindNoticeReward" if "bind" in lower else "ApiPlayerNoticeReward"
            result = self._message(response_name + ".result")
            if result is None:
                return 200, {"result": {"ret": 1}, "sandbox": True}
            result.result.ret = 1; return 200, result
        if method not in {"GET", "HEAD"}:
            return 405, {"error": "method_not_allowed", "message": "GET required"}
        if "reward" in lower and "summary" in lower:
            result = self._message("ApiNoticeRewardSummary.result")
            return (200, result) if result is not None else (200, {"rewards": [], "sandbox": True})
        # Notice sessions are intentionally empty: the local activity page is
        # the authoritative content source and no stale remote announcement
        # is fabricated for an offline client.
        if "get-session" in lower or lower.endswith("/notice") or lower.endswith("/notice-session"):
            return 200, {}
        if "server-update-info" in lower:
            return 200, {"timeInfo": {}}
        return 200, []

    def _collections_notepad(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower(); payload = _json(body)
        if "role-notepad" in lower or "notepad" in lower:
            actor_id = _int(payload.get("roleId", payload.get("actorId", payload.get("id", 1001))), 1001)
            entry = state.setdefault("notepad", {}).setdefault(str(actor_id), {"roleId": actor_id, "favour": 0, "favourLevel": 1, "unlockTime": self._now(), "presentState": 0, "readTag": 0, "events": []})
            if method in {"POST", "PATCH", "PUT"}:
                entry["readTag"] = _int(payload.get("readTag", payload.get("read_tag", entry.get("readTag", 0))))
                if "text" in payload:
                    entry["text"] = str(payload.get("text", ""))[:2000]
                self._save(profile, state)
            result = self._message("ApiRoleNotePad.result")
            if result is None:
                return 200, {"roleNotePad": dict(entry), "sandbox": True}
            info = result.role_notepad; info.role_id = actor_id; info.favour = _int(entry.get("favour")); info.favour_level = _int(entry.get("favourLevel"), 1); info.unlock_time = _int(entry.get("unlockTime")); info.present_state = _int(entry.get("presentState")); info.read_tag = _int(entry.get("readTag"))
            return 200, result
        if "signboard" in lower:
            # The entering layer owns the original bootstrap GET and returns
            # the compact JSON shape used by the city binding.  Mutations are
            # handled here so they persist into later bootstrap responses.
            if method == "GET":
                return None
            return self._signboard(method, body, profile, state)
        if "collection" in lower or "collections" in lower or "novel-cover" in lower:
            collections = state.setdefault("collections", {"actors": [], "equips": [], "novels": []})
            if method == "POST":
                category = str(payload.get("category", payload.get("type", ""))).lower()
                if "actor" in lower or category in {"actor", "actors"}:
                    category = "actors"
                    item_id = _int(payload.get("id", payload.get("actorId", 0)))
                    value = {"id": item_id, "addTime": self._now()}
                elif "equip" in lower or category in {"equip", "equips"}:
                    category = "equips"
                    item_id = _int(payload.get("id", payload.get("equipId", 0)))
                    value = {"equipId": item_id}
                else:
                    category = "novels"
                    item_id = _int(payload.get("id", payload.get("novelId", payload.get("coverId", 0))))
                    value = {"novelId": item_id, "curCover": _int(payload.get("coverId", 0)), "curRewardNum": 0, "canGetReward": False}
                if item_id <= 0:
                    return 400, {"error": "invalid_collection_id"}
                existing = collections.setdefault(category, [])
                if not any(_int(item.get("id", item.get("equipId", item.get("novelId", 0)))) == item_id for item in existing if isinstance(item, Mapping)):
                    existing.append(value)
                self._save(profile, state)
            if "actor" in lower:
                result = self._message("ApiCollectionsActor.result")
                if result is None:
                    return 200, {"actors": list(collections.setdefault("actors", [])), "sandbox": True}
                for item in collections.setdefault("actors", []):
                    row = result.actors.add(); row.id = _int(item.get("id")); row.add_time = _int(item.get("addTime"))
                return 200, result
            if "equip" in lower:
                result = self._message("ApiCollectionsEquip.result")
                if result is None:
                    return 200, {"equips": list(collections.setdefault("equips", [])), "sandbox": True}
                for item in collections.setdefault("equips", []): result.equips.add().equip_id = _int(item.get("equipId"))
                return 200, result
            if "novel" in lower or "cover" in lower:
                result = self._message("ApiCollectionsNovel.result")
                if result is None:
                    return 200, {"novels": list(collections.setdefault("novels", [])), "sandbox": True}
                for item in collections.setdefault("novels", []):
                    row = result.novels.add(); row.novel_id = _int(item.get("novelId")); row.cur_cover = _int(item.get("curCover")); row.cur_reward_num = _int(item.get("curRewardNum")); row.can_get_reward = bool(item.get("canGetReward"))
                return 200, result
        return None

    def _web_vote(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        lower = route.lower()
        if not any(token in lower for token in ("webvote", "web-vote", "voterole", "vote-role")):
            return None
        vote = state.setdefault("webVote", {})
        roles = vote.setdefault("roles", [])
        payload = _json(body)
        role_id = _int(payload.get("roleId", payload.get("role_id", 0)))
        if method == "POST":
            if _int(vote.get("ticketNum"), 0) <= 0:
                return 409, {"error": "vote_ticket_exhausted"}
            selected = next((item for item in roles if _int(item.get("roleId")) == role_id), None)
            if selected is None:
                return 404, {"error": "vote_role_not_found"}
            selected["voteCount"] = _int(selected.get("voteCount")) + 1
            vote["ticketNum"] = _int(vote.get("ticketNum")) - 1
            my_votes = vote.setdefault("myVotes", {}); key = str(role_id); my_votes[key] = _int(my_votes.get(key)) + 1
            self._save(profile, state)
            result = self._message("ApiWebVote.post")
            if result is None:
                return 200, {"result": True, "voteCount": _int(selected["voteCount"]), "voteTicketNum": _int(vote["ticketNum"]), "voteRoleInfo": {"roleId": role_id, "voteCount": _int(my_votes[key]), "roleName": str(selected.get("roleName", ""))}, "sandbox": True}
            result.result = True; result.vote_count = _int(selected["voteCount"]); result.vote_ticket_num = _int(vote["ticketNum"]); result.vote_role_info.role_id = role_id; result.vote_role_info.vote_count = _int(my_votes[key]); result.vote_role_info.role_name = str(selected.get("roleName", "")); return 200, result
        if "summary" in lower:
            result = self._message("ApiWebVoteSummary.get")
            if result is None:
                return 200, {"roleList": [dict(item) for item in roles], "sandbox": True}
            for selected in roles:
                row = result.role_list.add(); row.role_id = _int(selected.get("roleId")); row.role_name = str(selected.get("roleName", "")); row.image = str(selected.get("image", "")); row.vote_count = _int(selected.get("voteCount")); row.sort_id = _int(selected.get("sortId")); row.novel = str(selected.get("novel", "")); row.novel_id = _int(selected.get("novelId"))
            return 200, result
        result = self._message("ApiWebVote.get")
        if result is None:
            return 200, {"roleList": [dict(item) for item in roles], "voteCount": sum(_int(item.get("voteCount")) for item in roles), "voteBangNum": _int(vote.get("bangNum")), "voteTicketNum": _int(vote.get("ticketNum")), "sandbox": True}
        for selected in roles:
            row = result.role_list.add(); row.role_id = _int(selected.get("roleId")); row.role_name = str(selected.get("roleName", "")); row.image = str(selected.get("image", "")); row.vote_count = _int(selected.get("voteCount")); row.sort_id = _int(selected.get("sortId")); row.novel = str(selected.get("novel", "")); row.novel_id = _int(selected.get("novelId"))
        result.vote_count = sum(_int(item.get("voteCount")) for item in roles); result.vote_bang_num = _int(vote.get("bangNum")); result.vote_ticket_num = _int(vote.get("ticketNum")); result.exchange_vote_bang_num = _int(vote.get("bangNum")); result.exchange_vote_ticket_num = _int(vote.get("ticketNum")); return 200, result

    def _mini_games(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        """Persistent local seams for puzzle, postcard, claw-crane and share."""
        lower = route.lower(); payload = _json(body)
        if "jigsaw" in lower:
            game = state.setdefault("jigsaw", {"cells": [], "received": False})
            if method == "GET":
                return 200, {"lightenCell": list(game.get("cells", [])), "receivePrize": bool(game.get("received")), "isFirstEnter": not bool(game.get("cells")), "sandbox": True}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            if "receive" in lower:
                if game.get("received"): return 409, {"error": "jigsaw_prize_already_claimed"}
                ok, changes, error = self.game.economy._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": 100}])
                if not ok: return 409, {"error": error or "resource_update_failed"}
                game["received"] = True; self._save(profile, state); return 200, {"resChange": changes, "sandbox": True}
            cell_id = _int(payload.get("cellId", payload.get("cell_id", payload.get("id", 0))))
            if cell_id <= 0: return 400, {"error": "invalid_cell_id"}
            if cell_id not in game.setdefault("cells", []): game["cells"].append(cell_id); game["cells"].sort(); self._save(profile, state)
            return 200, {"cellId": cell_id, "resChange": [], "sandbox": True}
        if "postcard" in lower:
            game = state.setdefault("postcard", {"cells": [], "received": False})
            if method == "GET": return 200, {"isFirstEnter": not bool(game.get("cells")), "postcardInfo": list(game.get("cells", [])), "prizeInfo": {"received": bool(game.get("received"))}, "sandbox": True}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            if "receive" in lower:
                if game.get("received"): return 409, {"error": "postcard_prize_already_claimed"}
                ok, changes, error = self.game.economy._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": 120}])
                if not ok: return 409, {"error": error or "resource_update_failed"}
                game["received"] = True; self._save(profile, state); return 200, {"resChange": changes, "sandbox": True}
            cell_id = _int(payload.get("cellId", payload.get("cell_id", payload.get("id", 0))))
            if cell_id <= 0: return 400, {"error": "invalid_cell_id"}
            if cell_id not in game.setdefault("cells", []): game["cells"].append(cell_id); game["cells"].sort(); self._save(profile, state)
            return 200, {"cellId": cell_id, "resChange": [], "sandbox": True}
        if "clawcrane" in lower or "claw-crane" in lower:
            game = state.setdefault("clawCrane", {"draws": 0, "prizes": [], "bingo": []})
            if method == "GET": return 200, {"draws": _int(game.get("draws")), "prizes": list(game.get("prizes", [])), "bingo": list(game.get("bingo", [])), "sandbox": True}
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            if "verify" in lower: return 200, {"verifyCount": {}, "verifyTime": {}, "sandbox": True}
            if "bingo" in lower:
                item_id = _int(payload.get("id", payload.get("prizeId", 1)), 1)
                if item_id not in game.setdefault("bingo", []): game["bingo"].append(item_id); self._save(profile, state)
                return 200, {"id": item_id, "resChange": [], "sandbox": True}
            game["draws"] = _int(game.get("draws")) + max(1, _int(payload.get("count", 1), 1)); prize = {"id": game["draws"], "type": 7, "count": 20}
            game.setdefault("prizes", []).append(prize); self._save(profile, state); return 200, {"prize": prize, "draws": game["draws"], "sandbox": True}
        if lower.startswith("/fci/share"):
            if method != "POST": return 405, {"error": "method_not_allowed", "message": "POST required"}
            share = state.setdefault("share", {"weeklyRewarded": False, "actorRewardGot": 0})
            if share.get("weeklyRewarded"): return 200, {"weeklyRewarded": True, "actorRewardGot": _int(share.get("actorRewardGot")), "resChange": [], "sandbox": True}
            ok, changes, error = self.game.economy._change_resources(profile, [{"type": 7, "id": 0, "param": 0, "count": 50}])
            if not ok: return 409, {"error": error or "resource_update_failed"}
            share["weeklyRewarded"] = True; share["actorRewardGot"] = _int(payload.get("actorUid", payload.get("actorId", 0))); self._save(profile, state)
            return 200, {"weeklyRewarded": True, "actorRewardGot": share["actorRewardGot"], "resChange": changes, "sandbox": True}
        return None

    def handle_http(self, method: str, path: str, body: Body, profile: Mapping[str, Any]) -> Optional[Response]:
        with self._lock:
            route = _route(path); method = method.upper(); state = self._state(profile)
            lower = route.lower()
            if lower in {"/fci/baseinfo", "/fci/baseinfo/"} and method == "GET": return 200, self._base_info(profile, state)
            if lower in {"/fci/socialpicture", "/fci/socialpicture/"}: return self._social_picture(method, body, profile, state)
            if lower in {"/fci/home-back-ground", "/fci/home-back-ground/", "/fci/homebackground", "/fci/homebackground/"}: return self._home_background(method, body, profile, state)
            result = self._notices(method, route, body, profile, state)
            if result is not None: return result
            result = self._collections_notepad(method, route, body, profile, state)
            if result is not None: return result
            result = self._mini_games(method, route, body, profile, state)
            if result is not None: return result
            result = self._web_vote(method, route, body, profile, state)
            if result is not None: return result
            return None


__all__ = ["LocalProfileFeatures"]

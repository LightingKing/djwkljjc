# M2.6 Protobuf 描述符审计

`tools/audit_descriptors.py` 对 `data/descriptor_set.pb` 和 `contracts/api.yaml` 做可重复比对。它只报告恢复结果，不根据字段名猜测缺失消息，因此不会把兼容 JSON 当作官方 protobuf 定义。

恢复导出中有少数文件的 `syntax` 元数据被序列化成非法字节。审计会把这一个元数据字段规范化为 `proto3`，并在 `repairedFiles` 中记录原始十六进制值；消息、嵌套消息、字段号和字段类型都不会被改写。无法安全加入描述符池的文件仍会留在 `unresolvedFiles`，不会被伪造。

运行：

```powershell
python tools/audit_descriptors.py `
  --descriptor-set data/descriptor_set.pb `
  --contracts contracts/api.yaml `
  --output data/descriptor-audit.json
```

审计结果中的 `resolvedNames` 是服务端可以从描述符池构造的消息；`missingNames` 是契约表引用但无法构造的消息；`declaredButUnresolved` 表示消息名在输入描述符里存在，但被其它缺失或损坏依赖阻塞。`skippedFiles` 会列出仍无法安全加入的文件，`repairedFiles` 列出仅修复语法元数据的文件。枚举引用单独放在 `contractEnumTypes`，不会被误报为消息。

当前结果为 23/23 个契约消息类型和 1/1 个枚举类型可解析，`ApiServerUpdateInfo.result.TimeInfoEntry` 已从恢复的 `playeraction.proto` 嵌套 map 描述中解析出来。该结论只代表描述符结构可用，不代表对应服务端业务已经完整实现；接口行为仍以契约 smoke 和本地路由测试为准。

同一份报告还保留全量描述符资产清单：当前集合包含 79 个 `FileDescriptorProto`，共 1,748 个顶层/嵌套消息、131 个 enum 和 222 条依赖边。每个文件记录包名、依赖、消息/enum 数量、规范化状态和序列化 SHA-256，便于后续替换单个损坏输入时发现漂移。7 个文件仅做了 `syntax` 元数据规范化，`aq.proto` 与 `redpoint.proto` 仍因依赖缺口无法加入池；这些状态不会被折算成“完整恢复”。

这个工具不修改 APK、不访问远程服务，也不会把缺失字段写回描述符。补齐某个类型前，应先增加独立的 wireformat 编解码测试和来源记录。

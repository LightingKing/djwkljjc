# Development environment

The development emulator and host-only scripts live here. The existing
`DJWK_LJJC_API30` AVD is retained for compatibility; ROADMAP M0.4 adds the
isolated `LJJC_Offline_API28` AVD for no-audio/client stability testing.

Generated emulator snapshots, APKs, and logs must stay outside versioned
source directories.

Create and start the isolated Android 9 emulator:

```powershell
.\dev\create-api28-avd.ps1
.\dev\start-api28-avd.ps1 -WaitForBoot
```

The create step can be retried after an interrupted SDK download. The start
step uses `-no-audio`, port `5562`, and never resets or deletes
`DJWK_LJJC_API30` / `emulator-5560`.

After installing a local test APK, run five non-destructive cold starts:

```powershell
.\dev\cold-start-check.ps1 -Serial emulator-5562 -PackageName com.tencent.tmgp.fcicv
```

The check uses only `am force-stop` and `monkey`; it does not clear app data or
uninstall packages. A JSON report is written beside the script by default.

For a patched APK, run the artifact checker before a cold start. It validates
the package metadata and signature, then (when requested) compares the APK
SHA-256 with the installed package before launching it:

```powershell
python .\dev\verify-client-artifact.py `
  --apk .\client-patch\output\target24\ljjc-offline-target24-2.0.4-universal.apk `
  --output .\dev\target24-cold-start-api28.json `
  --expected-sha256 8e63b130cb925adb2c690f64b6a2802d4c4e223f1bf9db843ca4635bf6d2639d `
  --expected-package com.tencent.tmgp.fcicv `
  --expected-target-sdk 24 `
  --sdk-root 'C:\Users\Administrator\AppData\Local\Android\Sdk' `
  --serial emulator-5562 --cold-start-runs 5
```

The checker refuses to install or replace a package. If the installed digest
does not match the artifact, the report marks cold start as skipped so logs
from a different local signature cannot be attributed to this build.

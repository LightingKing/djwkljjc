from __future__ import annotations

import json
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

from accounts import LocalAccounts
from game import LocalGame
try:
    from tests.test_dungeon import DungeonTests
except ModuleNotFoundError:  # unittest discover adds tests/ directly to sys.path
    from test_dungeon import DungeonTests


class ExpandedDungeonTests(unittest.TestCase):
    def _setup(self):
        temp = tempfile.TemporaryDirectory()
        root = Path(temp.name)
        accounts = LocalAccounts(root / "accounts")
        game = LocalGame(root / "game", accounts)
        account = DungeonTests._guest_account(accounts)
        with closing(accounts._connect()) as connection:
            token = connection.execute(
                "SELECT access_token FROM accounts WHERE account_id = ?",
                (account["accountId"],),
            ).fetchone()[0]
        return temp, game, "Token " + token

    def test_configured_later_chapter_stage_is_playable(self):
        temp, game, auth = self._setup()
        try:
            request = game._types["ApiDungeon"]()
            request.dungeon_id = 9  # ChapterInfo chapter 2, first stage.
            status, entered = game.handle_http(
                "POST", "/fci/dungeon/", request.SerializeToString(), "application/wireformat", auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(entered["baseInfo"]["dungeonId"], 9)
            self.assertEqual(entered["baseInfo"]["dungeonType"], 2)
            active = game._types["FightActiveData"]()
            active.dungeonType = 2
            active.stageID = 9
            active.gameRound = 2
            active.winTeam = 1
            self.assertEqual(
                game.handle_http(
                    "PATCH", f"/fci/dungeon/{entered['dungeonUid']}/active/",
                    active.SerializeToString(), "application/wireformat", auth,
                ),
                (200, {}),
            )
            status, result = game.handle_http(
                "POST", f"/fci/dungeon/{entered['dungeonUid']}/balance",
                json.dumps({"stars": 2, "targetsDone": [1, 3]}).encode(),
                "application/json", auth,
            )
            self.assertEqual(status, 200)
            self.assertEqual(result["dungeonId"], 9)
            self.assertEqual(result["stars"], 2)
            self.assertEqual(result["balanceInfo"]["targetsDone"], [1, 3])
            self.assertEqual(result["balanceInfo"]["difficulty"], "normal")
        finally:
            temp.cleanup()

    def test_hard_mode_persists_and_full_chapter_graph_is_typed(self):
        temp, game, auth = self._setup()
        try:
            status, entered = game.handle_http(
                "POST", "/fci/dungeon/", json.dumps({"dungeonId": 10, "difficulty": "hard"}).encode(),
                "application/json", auth,
            )
            self.assertEqual(status, 200)
            self.assertTrue(entered["baseInfo"]["isChallengeMode"])
            self.assertEqual(entered["baseInfo"]["difficulty"], "hard")
            status, chapter = game.handle_http("GET", "/fci/dungeon/chapter/2", b"", "application/wireformat", auth)
            self.assertEqual(status, 200)
            self.assertEqual(chapter.record_chapter.chapter_id, 2)
            self.assertIn(9, chapter.record_dungeons)
        finally:
            temp.cleanup()


if __name__ == "__main__":
    unittest.main()

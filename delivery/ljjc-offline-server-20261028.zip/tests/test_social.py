from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest

from accounts import LocalAccounts
from game import LocalGame


class LocalSocialTests(unittest.TestCase):
    @staticmethod
    def guest(accounts: LocalAccounts):
        first = accounts.handle("POST", "/AccountSession/", b"", "application/wireformat")
        token = "AccountToken " + first[1]["accountToken"]
        entry = accounts.handle("POST", "/EntryReg/", b'{"entryType":"guest"}', "application/json", token)[1]["entry"]["entry"]
        accounts.handle("POST", "/Account/", b'{"entryType":"guest"}', "application/json", token)
        second = accounts.handle("POST", "/AccountSession/", b"", "application/wireformat")
        auth = accounts.handle("POST", "/Auth/", b"\x0a" + bytes((len(entry),)) + entry.encode() + b"\x12\x05guest", "application/wireformat", "AccountToken " + second[1]["accountToken"])
        return accounts.verify_access_token(auth[1]["tokenAccess"]), "Token " + auth[1]["tokenAccess"]

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.accounts = LocalAccounts(root / "accounts")
        self.game = LocalGame(root / "game", self.accounts)
        self.account, self.auth = self.guest(self.accounts)

    def tearDown(self):
        self.temp.cleanup()

    def call(self, method: str, path: str, payload: dict | None = None):
        body = json.dumps(payload).encode() if payload is not None else None
        return self.game.handle_http(method, path, body, "application/json", self.auth)

    def test_bots_friend_chat_and_assistant_state_persist(self):
        status, friends = self.call("GET", "/fci/friend/list")
        self.assertEqual(status, 200)
        self.assertGreaterEqual(len(friends["friends"]), 2)
        target = friends["friends"][0]["playerId"]
        status, applied = self.call("POST", "/fci/friend/apply", {"playerId": "local-bot-003"})
        self.assertEqual(status, 200); self.assertTrue(applied["isFriend"])
        status, sent = self.call("POST", "/fci/chat", {"text": "hello local"})
        self.assertEqual(status, 200); self.assertEqual(sent["message"]["text"], "hello local")
        status, chat = self.call("GET", "/fci/chat")
        self.assertEqual(status, 200); self.assertEqual(chat["messages"][-1]["text"], "hello local")
        status, assistants = self.call("GET", "/fci/dungeon-assistants")
        self.assertEqual(status, 200); self.assertTrue(assistants["assistants"])
        restarted = LocalGame(Path(self.temp.name) / "game", self.accounts)
        status, chat_again = restarted.handle_http("GET", "/fci/chat", authorization=self.auth)
        self.assertEqual(status, 200); self.assertEqual(chat_again["messages"][-1]["text"], "hello local")

    def test_async_pvp_and_ranking_are_deterministic_and_persistent(self):
        status, match = self.call("POST", "/fci/asyncpvp/match", {})
        self.assertEqual(status, 200)
        opponent = match["match"]["opponent"]["playerId"]
        status, result = self.call("POST", "/fci/asyncpvp/settle", {"win": True})
        self.assertEqual(status, 200); self.assertEqual(result["result"]["opponent"], opponent)
        status, ranking = self.call("GET", "/fci/leaderboard")
        self.assertEqual(status, 200)
        self.assertEqual(ranking["self"]["score"], 1025)
        self.assertEqual(ranking["self"]["rank"], min(row["rank"] for row in ranking["ranking"] if row["isSelf"]))


if __name__ == "__main__":
    unittest.main()

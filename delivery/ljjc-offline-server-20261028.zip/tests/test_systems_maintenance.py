from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from accounts import LocalAccounts
from game import LocalGame


class LocalSystemsMaintenanceTests(unittest.TestCase):
    @staticmethod
    def _guest(accounts: LocalAccounts):
        first = accounts.handle("POST", "/AccountSession/", b"", "application/wireformat")
        token = "AccountToken " + first[1]["accountToken"]
        entry = accounts.handle("POST", "/EntryReg/", b'{"entryType":"guest"}', "application/json", token)[1]["entry"]["entry"]
        accounts.handle("POST", "/Account/", b'{"entryType":"guest"}', "application/json", token)
        second = accounts.handle("POST", "/AccountSession/", b"", "application/wireformat")
        second_token = "AccountToken " + second[1]["accountToken"]
        body = b"\x0a" + bytes((len(entry),)) + entry.encode() + b"\x12\x05guest"
        auth = accounts.handle("POST", "/Auth/", body, "application/wireformat", second_token)
        return accounts.verify_access_token(auth[1]["tokenAccess"]), "Token " + auth[1]["tokenAccess"]

    @staticmethod
    def _call(game: LocalGame, token: str, method: str, path: str, payload=None):
        body = None if payload is None else json.dumps(payload).encode()
        return game.handle_http(method, path, body, "application/json", token)

    def test_actor_and_equipment_costs_locks_and_persist(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, token = self._guest(accounts)
            profile_before = game._profile(account)
            gold_before = next(x["count"] for x in profile_before["resources"] if x["type"] == 7)

            status, level_result = self._call(game, token, "POST", "/fci/actor/1001/levelup/", {"levels": 1})
            self.assertEqual(status, 200)
            self.assertEqual(level_result.DESCRIPTOR.full_name, "ApiActorLevelUp.post")
            profile_after = game._profile(account)
            gold_after = next(x["count"] for x in profile_after["resources"] if x["type"] == 7)
            self.assertEqual(gold_before - gold_after, 100)

            status, _ = self._call(game, token, "POST", "/fci/actor/1001/setactorlock/", {"isLock": True})
            self.assertEqual(status, 200)
            status, _ = self._call(game, token, "POST", "/fci/actor/1001/skill/learn/", {"skillId": 1001001})
            self.assertEqual(status, 200)
            status, _ = self._call(game, token, "POST", "/fci/actor/1001/starlevelup/", {})
            self.assertEqual(status, 200)

            status, _ = self._call(game, token, "POST", "/fci/equip/20001/enhance/", {})
            self.assertEqual(status, 200)
            status, _ = self._call(game, token, "POST", "/fci/equip/20001/setequiplock/", {"isLock": True})
            self.assertEqual(status, 200)
            status, _ = self._call(game, token, "POST", "/fci/equip/20001/decompose/", {})
            self.assertEqual(status, 409)

            restarted = LocalGame(root / "game", accounts)
            status, actor = self._call(restarted, token, "GET", "/fci/actor/1001/")
            self.assertEqual(status, 200)
            self.assertEqual(actor.result.level, 2)
            self.assertTrue(actor.result.is_lock)
            self.assertTrue(any(skill.id == 1001001 for skill in actor.result.skills))

    def test_items_resources_and_cultivation_are_atomic_and_persistent(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            _account, token = self._guest(accounts)

            self.assertEqual(self._call(game, token, "POST", "/fci/item/", {"id": 55, "count": 3})[0], 200)
            self.assertEqual(self._call(game, token, "POST", "/fci/item/use/", {"id": 55, "count": 2})[0], 200)
            self.assertEqual(self._call(game, token, "POST", "/fci/item/sell/", {"id": 55, "count": 1})[0], 200)
            status, items = self._call(game, token, "GET", "/fci/playeritem/")
            self.assertEqual(status, 200)
            self.assertEqual(items["items"], [])

            # Three low tier resources are consumed and one higher tier unit
            # is granted in the same economy update.
            status, result = self._call(game, token, "POST", "/fci/resource/compose/", {"type": 6, "id": 0, "count": 1})
            self.assertEqual(status, 200)
            self.assertEqual(result.DESCRIPTOR.full_name, "ApiResourceCompose.result")

            status, cultivation = self._call(game, token, "POST", "/fci/actorcultivation/", {"actorId": 1001, "progress": 3})
            self.assertEqual(status, 200)
            self.assertEqual(cultivation.result.progress, 3)

            restarted = LocalGame(root / "game", accounts)
            status, cultivation = self._call(restarted, token, "GET", "/fci/actorcultivation/", {"actorId": 1001})
            self.assertEqual(status, 200)
            self.assertEqual(cultivation["progress"], 3)

    def test_insufficient_level_up_does_not_change_actor(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, token = self._guest(accounts)
            profile = game._profile(account)
            # Spend the starter gold through the same economy seam used by
            # the operation under test, leaving an exact zero balance.
            starter_gold = next(x["count"] for x in profile["resources"] if x["type"] == 7)
            ok, _changes, _error = game.economy._change_resources(
                profile, [{"type": 7, "id": 0, "param": 0, "count": -starter_gold}]
            )
            self.assertTrue(ok)
            status, payload = self._call(game, token, "POST", "/fci/actor/1001/levelup/", {"levels": 1})
            self.assertEqual(status, 409)
            status, actor = self._call(game, token, "GET", "/fci/actor/1001/")
            self.assertEqual(status, 200)
            self.assertEqual(actor.result.level, 1)

    def test_actor_like_is_persistent_and_idempotent(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            _account, token = self._guest(accounts)

            status, first = self._call(game, token, "GET", "/fci/actor/1001/actor-like/")
            self.assertEqual(status, 200)
            self.assertEqual(first.DESCRIPTOR.full_name, "ApiActorLike.get")
            self.assertEqual((first.like_num, first.is_like), (0, False))

            status, liked = self._call(game, token, "POST", "/fci/actor/1001/actor-like/", {})
            self.assertEqual(status, 200)
            self.assertEqual(liked.DESCRIPTOR.full_name, "ApiActorLike.post")
            self.assertEqual((liked.like_num, liked.is_like), (1, True))
            # Retries from the client are safe and do not double count.
            status, repeated = self._call(game, token, "POST", "/fci/actor/1001/actor-like/", {})
            self.assertEqual(status, 200)
            self.assertEqual((repeated.like_num, repeated.is_like), (1, True))

            restarted = LocalGame(root / "game", accounts)
            status, persisted = self._call(restarted, token, "GET", "/fci/actor/1001/actor-like/")
            self.assertEqual(status, 200)
            self.assertEqual((persisted.like_num, persisted.is_like), (1, True))
            status, unliked = self._call(restarted, token, "DELETE", "/fci/actor/1001/actor-like/")
            self.assertEqual(status, 200)
            self.assertEqual((unliked.like_num, unliked.is_like), (0, False))

    def test_actor_inheritance_copies_progress_and_moves_equipment(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            _account, token = self._guest(accounts)

            # Seed meaningful source progress and one equipped item.
            status, _ = self._call(game, token, "POST", "/fci/actor/1001/levelup/", {"levels": 1})
            self.assertEqual(status, 200)
            status, _ = self._call(game, token, "POST", "/fci/equip/20001/equipon/", {"actorUid": 1001})
            self.assertEqual(status, 200)

            status, inherited = self._call(
                game, token, "POST", "/fci/ActorInheriting/",
                {"targetActorUid": 1002},
            )
            self.assertEqual(status, 200)
            self.assertEqual(inherited.DESCRIPTOR.full_name, "ApiActorInheriting.post")
            self.assertTrue(inherited.res_change)

            status, target = self._call(game, token, "GET", "/fci/actor/1002/")
            self.assertEqual(status, 200)
            self.assertEqual(target.result.level, 2)
            status, equipment = self._call(game, token, "GET", "/fci/equip/20001/")
            self.assertEqual(status, 200)
            self.assertEqual(equipment.result.actor_uid, 1002)

            restarted = LocalGame(root / "game", accounts)
            status, target_after_restart = self._call(restarted, token, "GET", "/fci/actor/1002/")
            self.assertEqual(status, 200)
            self.assertEqual(target_after_restart.result.level, 2)


if __name__ == "__main__":
    unittest.main()

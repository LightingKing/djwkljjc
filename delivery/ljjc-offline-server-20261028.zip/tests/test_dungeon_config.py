from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from dungeon import DUNGEON_CONFIG, NORMAL_DUNGEON_IDS, STORY_DUNGEON_IDS
from server.core.content import load_dungeon_config


class DungeonConfigTests(unittest.TestCase):
    def test_checked_in_tables_drive_verified_local_ids(self):
        self.assertEqual(NORMAL_DUNGEON_IDS, tuple(range(1, 9)))
        self.assertTrue({2011, 2012, 2013}.issubset(STORY_DUNGEON_IDS))
        self.assertIn(81, DUNGEON_CONFIG.all_normal_ids)
        self.assertFalse(DUNGEON_CONFIG.chapter_complete)
        self.assertFalse(DUNGEON_CONFIG.reward_complete)
        self.assertEqual(DUNGEON_CONFIG.reward_row(2012)["preDungeonId"], 2011)

    def test_missing_tables_use_explicit_compatibility_fallback(self):
        with tempfile.TemporaryDirectory() as raw:
            config = load_dungeon_config(Path(raw))
            self.assertEqual(config.supported_normal_ids, tuple(range(1, 9)))
            self.assertEqual(config.story_ids, (2011, 2012, 2013))
            self.assertTrue(config.fallback_used)
            self.assertEqual(config.all_normal_ids, ())


if __name__ == "__main__":
    unittest.main()

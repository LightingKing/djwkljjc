"""Local-only shop and payment seams for the retired LJJC client.

The original server is unavailable, so this module deliberately implements a
small, deterministic *local sandbox* rather than pretending to verify an
Apple/Google/Midas receipt.  Shop purchases spend the profile's local
resources.  A recharge is only credited after a one-time token returned by
``purchasetouch`` is supplied to ``purchasedelevery``; arbitrary receipt text
never grants paid currency.

State that belongs to the economy is kept in a separate SQLite file so older
``game.sqlite3`` profiles remain readable and migrations stay reversible.
"""

from __future__ import annotations

import json
import re
import secrets
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Tuple
from urllib.parse import urlsplit

from google.protobuf import message_factory

try:
    from .storage.compat import (
        configure_legacy_connection,
        ensure_unified_store,
        resolve_unified_store_path,
        shared_store_lock,
    )
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from storage.compat import (
        configure_legacy_connection,
        ensure_unified_store,
        resolve_unified_store_path,
        shared_store_lock,
    )


Body = bytes | bytearray | str | None
Response = Tuple[int, Any]


def _route(path: str) -> str:
    value = urlsplit(path or "").path or "/"
    if value != "/":
        value = value.rstrip("/") + "/"
    return value


def _body_object(body: Body) -> Mapping[str, Any]:
    if body is None:
        return {}
    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    if not raw:
        return {}
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, Mapping) else {}


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _protobuf_request(game: Any, body: Body, type_name: str) -> Any | None:
    """Decode a native wireformat request when the JSON seam is absent."""

    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body or b"")
    if not raw:
        return None
    try:
        message_type = game._pool.FindMessageTypeByName(type_name)
        message = message_factory.GetMessageClass(message_type)()
        message.ParseFromString(raw)
        return message
    except Exception:
        return None


class LocalEconomy:
    """Persistent local shop and explicitly sandboxed payment handler."""

    # Product IDs are intentionally local and finite.  The optional aliases
    # make the seam convenient for a local UI without accepting arbitrary
    # numeric suffixes as free currency.
    _PRODUCTS: Dict[str, Dict[str, Any]] = {
        "local.sandbox.60": {"price": 6.0, "count": 60},
        "local.sandbox.300": {"price": 30.0, "count": 300},
        "local.sandbox.980": {"price": 98.0, "count": 980},
        "local.sandbox.1980": {"price": 198.0, "count": 1980},
        "local.sandbox.3280": {"price": 328.0, "count": 3280},
        "local.sandbox.6480": {"price": 648.0, "count": 6480},
        "local_60": {"price": 6.0, "count": 60},
        "local_300": {"price": 30.0, "count": 300},
        "local_980": {"price": 98.0, "count": 980},
        "local_1980": {"price": 198.0, "count": 1980},
        "local_3280": {"price": 328.0, "count": 3280},
        "local_6480": {"price": 648.0, "count": 6480},
    }

    # ``Mall`` is a separate cash/gift shop from the player ``Shop``.  The
    # retired service no longer supplies its catalog, so keep a small explicit
    # local catalog.  These IDs are also useful for clients whose static data
    # still points at the original low numbered mall entries.
    _MALL_PRODUCTS: Dict[int, Dict[str, Any]] = {
        1: {"cost": {"type": 7, "id": 0, "count": 1000, "param": 0}, "good": {"type": 11, "id": 20001, "count": 1, "param": 0}, "limit": 5},
        2: {"cost": {"type": 7, "id": 0, "count": 2500, "param": 0}, "good": {"type": 11, "id": 20002, "count": 1, "param": 0}, "limit": 3},
        3: {"cost": {"type": 7, "id": 0, "count": 5000, "param": 0}, "good": {"type": 6, "id": 0, "count": 10, "param": 0}, "limit": 2},
        10001: {"cost": {"type": 7, "id": 0, "count": 1000, "param": 0}, "good": {"type": 11, "id": 20001, "count": 1, "param": 0}, "limit": 5},
        10002: {"cost": {"type": 7, "id": 0, "count": 2500, "param": 0}, "good": {"type": 11, "id": 20002, "count": 1, "param": 0}, "limit": 3},
        10003: {"cost": {"type": 7, "id": 0, "count": 5000, "param": 0}, "good": {"type": 6, "id": 0, "count": 10, "param": 0}, "limit": 2},
    }

    # Recharge model IDs observed in the retired client.  They intentionally
    # map to local sandbox denominations; no platform receipt or real money
    # provider is involved.  Gift-box IDs are kept separate from the normal
    # product IDs so the client can render both shop sections.
    _RECHARGE_OFFERS: Dict[int, Dict[str, Any]] = {
        11: {"productId": "local.sandbox.60", "count": 60, "price": 0.0},
        51: {"productId": "local.sandbox.300", "count": 300, "price": 0.0},
        52: {"productId": "local.sandbox.980", "count": 980, "price": 0.0},
        100: {"productId": "local.sandbox.1980", "count": 1980, "price": 0.0},
        101: {"productId": "local.sandbox.3280", "count": 3280, "price": 0.0},
        102: {"productId": "local.sandbox.6480", "count": 6480, "price": 0.0},
        4005: {"productId": "local.sandbox.300", "count": 300, "price": 0.0, "giftBox": True},
        4006: {"productId": "local.sandbox.980", "count": 980, "price": 0.0, "giftBox": True},
        4007: {"productId": "local.sandbox.1980", "count": 1980, "price": 0.0, "giftBox": True},
    }

    def __init__(
        self,
        state_dir: str | Path,
        game: Any,
        *,
        clock: Optional[Callable[[], int]] = None,
        unified_store_path: str | Path | None = None,
    ) -> None:
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.unified_store_path = resolve_unified_store_path(self.state_dir, unified_store_path)
        if self.unified_store_path is not None:
            ensure_unified_store(self.unified_store_path)
            self.db_path = self.unified_store_path
        else:
            self.db_path = self.state_dir / "economy.sqlite3"
        self.game = game
        self._clock = clock or (lambda: int(time.time()))
        # A shop/payment state file may be opened by more than one local game
        # object (for example during a development reload).  Share the lock by
        # canonical SQLite path so read/modify/write mutations remain atomic.
        self._lock = shared_store_lock(self.db_path)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(str(self.db_path), timeout=10)
        connection.row_factory = sqlite3.Row
        configure_legacy_connection(connection)
        return connection

    def _initialize(self) -> None:
        with self._lock, closing(self._connect()) as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS economy_profiles (
                    account_id INTEGER PRIMARY KEY,
                    shop_json TEXT NOT NULL,
                    pending_json TEXT NOT NULL,
                    purchases_json TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )

    def _now(self) -> int:
        return int(self._clock())

    def _daily_key(self, value: int | None = None) -> str:
        """Return the server's configured daily bucket for resettable rewards.

        ``server.py`` injects a 06:00 local bucket on ``LocalGame``.  Direct
        unit callers that construct the game without a server clock retain the
        historical UTC-midnight fallback.
        """
        source = getattr(self.game, "daily_key", None)
        if callable(source):
            return str(source(self._now() if value is None else value))
        return str((self._now() if value is None else int(value)) // 86400)

    @staticmethod
    def _account_id(account: Mapping[str, Any]) -> int:
        value = account.get("accountId", account.get("account_id"))
        if value is None:
            raise ValueError("authenticated account id is required")
        return int(value)

    def _account_for_game(self, account: Mapping[str, Any]) -> Mapping[str, Any]:
        if "accountId" in account:
            return account
        return {"accountId": self._account_id(account)}

    def _default_shop(self) -> Dict[str, Any]:
        now = self._now()
        # These are schema-shaped local test goods.  They use ordinary gold
        # and item resources so the existing client can render and purchase
        # them without a server-side catalog.
        goods = [
            {
                "position": 0,
                "shopGoodId": 10001,
                "good": {"type": 11, "id": 20001, "count": 1, "param": 0},
                "cost": [{"type": 7, "id": 0, "count": 1000, "param": 0}],
                "buyCountRecord": 0,
                "buyLimit": 5,
                "sold": False,
                "canRefresh": False,
                "guildLevelLimit": 0,
            },
            {
                "position": 1,
                "shopGoodId": 10002,
                "good": {"type": 11, "id": 20002, "count": 1, "param": 0},
                "cost": [{"type": 7, "id": 0, "count": 2500, "param": 0}],
                "buyCountRecord": 0,
                "buyLimit": 3,
                "sold": False,
                "canRefresh": False,
                "guildLevelLimit": 0,
            },
            {
                "position": 2,
                "shopGoodId": 10003,
                "good": {"type": 6, "id": 0, "count": 10, "param": 0},
                "cost": [{"type": 7, "id": 0, "count": 5000, "param": 0}],
                "buyCountRecord": 0,
                "buyLimit": 2,
                "sold": False,
                "canRefresh": False,
                "guildLevelLimit": 0,
            },
        ]
        return {
            "shopId": 1,
            "baseInfo": {
                "shopId": 1,
                "playerLevel": 1,
                "refreshDayOfMonth": 0,
                "refreshDayOfWeek": 0,
                "refreshTimeInDay": "06:00:00",
                "refreshLimitNotify": 0,
                "refreshLimit": 0,
                "refreshFree": 0,
                "maxPosition": len(goods),
                "shufflePosition": False,
                "displayCost": [],
                "show": True,
                "activity": False,
                "guild": False,
                "clientShow": True,
                "version": 1,
            },
            "newShop": True,
            "refreshCount": 0,
            "nextRefreshTime": now + 86400,
            "nextFreeRefreshTime": now + 86400,
            "nextRefreshCost": {"type": 7, "id": 0, "count": 10000, "param": 0},
            "startTime": now,
            "endTime": 0,
            "goods": goods,
        }

    def _state(self, account: Mapping[str, Any]) -> Dict[str, Any]:
        account_id = self._account_id(account)
        with self._lock, closing(self._connect()) as connection, connection:
            row = connection.execute(
                "SELECT * FROM economy_profiles WHERE account_id = ?", (account_id,)
            ).fetchone()
            if row is None:
                state = {
                    "shop": [self._default_shop()],
                    "pending": {},
                    "purchases": {},
                }
                connection.execute(
                    "INSERT INTO economy_profiles(account_id, shop_json, pending_json, purchases_json, updated_at) VALUES(?,?,?,?,?)",
                    (
                        account_id,
                        json.dumps(state["shop"], ensure_ascii=False, separators=(",", ":")),
                        "{}",
                        "{}",
                        self._now(),
                    ),
                )
                return state
            try:
                shops = json.loads(row["shop_json"] or "[]")
            except (TypeError, ValueError):
                shops = []
            try:
                pending = json.loads(row["pending_json"] or "{}")
            except (TypeError, ValueError):
                pending = {}
            try:
                purchases = json.loads(row["purchases_json"] or "{}")
            except (TypeError, ValueError):
                purchases = {}
            if not isinstance(shops, list) or not shops:
                shops = [self._default_shop()]
            if not isinstance(pending, dict):
                pending = {}
            if not isinstance(purchases, dict):
                purchases = {}
            return {"shop": shops, "pending": pending, "purchases": purchases}

    def _save_state(self, account: Mapping[str, Any], state: Mapping[str, Any]) -> None:
        with self._lock, closing(self._connect()) as connection, connection:
            connection.execute(
                "UPDATE economy_profiles SET shop_json = ?, pending_json = ?, purchases_json = ?, updated_at = ? WHERE account_id = ?",
                (
                    json.dumps(state.get("shop", []), ensure_ascii=False, separators=(",", ":")),
                    json.dumps(state.get("pending", {}), ensure_ascii=False, separators=(",", ":")),
                    json.dumps(state.get("purchases", {}), ensure_ascii=False, separators=(",", ":")),
                    self._now(),
                    self._account_id(account),
                ),
            )

    def _resources(self, profile: Mapping[str, Any]) -> list[dict[str, int]]:
        result: list[dict[str, int]] = []
        raw = profile.get("resources", [])
        if not isinstance(raw, list):
            return result
        for item in raw:
            if not isinstance(item, Mapping):
                continue
            result.append({
                "type": _int(item.get("type")),
                "id": _int(item.get("id")),
                "count": _int(item.get("count")),
                "param": _int(item.get("param")),
            })
        return result

    def _message(self, full_name: str):
        return message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName(full_name))()

    def _resource_message(self, value: Mapping[str, Any], *, delta: Optional[int] = None):
        result = self._message("STResource")
        result.type = _int(value.get("type"))
        result.id = _int(value.get("id"))
        result.count = _int(value.get("count"))
        result.param = _int(value.get("param"))
        if delta is not None:
            result.count_delta = int(delta)
        return result

    def _resource_dynamic_messages(self, changes: list[Mapping[str, Any]]):
        result = []
        for value in changes:
            dynamic = self._message("STResourceDynamic")
            dynamic.base_res.CopyFrom(
                self._resource_message(value, delta=_int(value.get("countDelta")))
            )
            result.append(dynamic)
        return result

    def _shop_good_message(self, value: Mapping[str, Any]):
        result = self._message("DBPlayerShop.Refreshed.Info.Single")
        result.position = _int(value.get("position"))
        result.shopGoodId = _int(value.get("shopGoodId"))
        good = value.get("good")
        if isinstance(good, Mapping):
            result.good.CopyFrom(self._resource_message(good))
        for cost in value.get("cost", []):
            if isinstance(cost, Mapping):
                result.cost.add().CopyFrom(self._resource_message(cost))
        result.buy_count_record = _int(value.get("buyCountRecord"))
        result.buy_limit = _int(value.get("buyLimit"))
        result.sold = bool(value.get("sold", False))
        result.can_refresh = bool(value.get("canRefresh", False))
        result.guildLevelLimit = _int(value.get("guildLevelLimit"))
        return result

    def _shop_result_message(self, shop: Mapping[str, Any]):
        result = self._message("ApiShop.result")
        base = shop.get("baseInfo", {})
        if isinstance(base, Mapping):
            result.base_info.shopId = _int(base.get("shopId", shop.get("shopId")))
            result.base_info.player_level = _int(base.get("playerLevel", 1))
            result.base_info.refreshDayOfMonth = _int(base.get("refreshDayOfMonth"))
            result.base_info.refreshDayOfWeek = _int(base.get("refreshDayOfWeek"))
            result.base_info.refreshTimeInDay = str(base.get("refreshTimeInDay", "06:00:00"))
            result.base_info.refreshLimitNotify = _int(base.get("refreshLimitNotify"))
            result.base_info.refreshLimit = _int(base.get("refreshLimit"))
            result.base_info.refreshFree = _int(base.get("refreshFree"))
            result.base_info.maxPosition = _int(base.get("maxPosition"))
            result.base_info.shufflePosition = bool(base.get("shufflePosition", False))
            result.base_info.show = bool(base.get("show", True))
            result.base_info.activity = bool(base.get("activity", False))
            result.base_info.guild = bool(base.get("guild", False))
            result.base_info.client_show = bool(base.get("clientShow", True))
            result.base_info.version = _int(base.get("version", 1))
            for cost in base.get("displayCost", []):
                if isinstance(cost, Mapping):
                    result.base_info.display_cost.add().CopyFrom(self._resource_message(cost))
        result.new_shop = bool(shop.get("newShop", True))
        result.refresh_count = _int(shop.get("refreshCount"))
        result.next_refresh_time = _int(shop.get("nextRefreshTime"))
        result.next_free_refresh_time = _int(shop.get("nextFreeRefreshTime"))
        cost = shop.get("nextRefreshCost")
        if isinstance(cost, Mapping):
            result.next_refresh_cost.CopyFrom(self._resource_message(cost))
        result.start_time = _int(shop.get("startTime"))
        result.end_time = _int(shop.get("endTime"))
        return result

    def _change_resources(self, profile: Mapping[str, Any], changes: list[Mapping[str, Any]]) -> tuple[bool, list[dict[str, int]], str | None]:
        resources = self._resources(profile)
        index = {(item["type"], item["id"], item["param"]): i for i, item in enumerate(resources)}
        deltas: list[dict[str, int]] = []
        for raw in changes:
            rtype, rid, param, count = _int(raw.get("type")), _int(raw.get("id")), _int(raw.get("param")), _int(raw.get("count"))
            if count < 0:
                key = (rtype, rid, param)
                current = resources[index[key]]["count"] if key in index else 0
                if current < -count:
                    return False, [], "insufficient_resource"
        for raw in changes:
            rtype, rid, param, count = _int(raw.get("type")), _int(raw.get("id")), _int(raw.get("param")), _int(raw.get("count"))
            key = (rtype, rid, param)
            if key not in index:
                index[key] = len(resources)
                resources.append({"type": rtype, "id": rid, "count": 0, "param": param})
            resources[index[key]]["count"] += count
            deltas.append({"type": rtype, "id": rid, "count": resources[index[key]]["count"], "param": param, "countDelta": count})
        # Empty balances are kept at zero so the client can continue to bind
        # the resource key; negative values are never persisted.
        for item in resources:
            if item["count"] < 0:
                item["count"] = 0
        account_id = int(profile["account_id"])
        with self.game._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                "UPDATE game_profiles SET resources_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(resources, separators=(",", ":")), self._now(), account_id),
            )
        return True, deltas, None

    def _shop_payload(self, shops: list[Mapping[str, Any]], *, goods: bool = False) -> Any:
        if goods:
            return [item for shop in shops for item in shop.get("goods", [])]
        return [
            {key: value for key, value in shop.items() if key != "goods"}
            for shop in shops
        ]

    def _find_shop(self, state: Mapping[str, Any], shop_id: int) -> Optional[Dict[str, Any]]:
        for shop in state.get("shop", []):
            if isinstance(shop, dict) and _int(shop.get("shopId")) == shop_id:
                return shop
        return None

    def _find_good(self, shop: Mapping[str, Any], good_id: int, position: int | None) -> Optional[Dict[str, Any]]:
        for item in shop.get("goods", []):
            if not isinstance(item, dict):
                continue
            if good_id and _int(item.get("shopGoodId")) == good_id:
                return item
            if position is not None and _int(item.get("position")) == position:
                return item
        return None

    @staticmethod
    def _mall_record_key(mall_id: int) -> str:
        return f"mall:{int(mall_id)}"

    def _mall_buy_count(self, state: Mapping[str, Any], mall_id: int) -> int:
        value = state.get("purchases", {}).get(self._mall_record_key(mall_id), {})
        return _int(value.get("buyCount", value.get("buy_count", 0))) if isinstance(value, Mapping) else 0

    def _mall_info_message(self, account: Mapping[str, Any], state: Mapping[str, Any]):
        result = self._message("ApiMallInfo.result")
        player_id = str(self.game._profile(self._account_for_game(account)).get("player_id", ""))
        result.mall_record.player_id = player_id
        result.purchase_record.player_id = player_id
        for mall_id in self._MALL_PRODUCTS:
            count = self._mall_buy_count(state, mall_id)
            if not count:
                continue
            summary = result.mall_record.summary[int(mall_id)]
            summary.buy_count = count
            summary.last_buy_start_time = _int(
                state.get("purchases", {}).get(self._mall_record_key(mall_id), {}).get("lastBuyStartTime", 0)
            )
        return result

    def _mall_trade(self, account: Mapping[str, Any], body: Body, state: Dict[str, Any]) -> Response:
        request = _body_object(body)
        message = _protobuf_request(self.game, body, "ApiMallTrade")
        mall_id = _int(request.get("id", getattr(message, "id", 0) if message is not None else 0))
        product = self._MALL_PRODUCTS.get(mall_id)
        if product is None:
            return 404, {"error": "mall_good_not_found"}
        bought = self._mall_buy_count(state, mall_id)
        limit = _int(product.get("limit"))
        if limit and bought >= limit:
            return 409, {"error": "mall_good_limit_reached"}
        profile = self.game._profile(self._account_for_game(account))
        cost = dict(product["cost"])
        good = dict(product["good"])
        ok, changes, error = self._change_resources(
            profile,
            [{**cost, "count": -abs(_int(cost.get("count")))}, good],
        )
        if not ok:
            return 409, {"error": error or "insufficient_resource"}
        now = self._now()
        state["purchases"][self._mall_record_key(mall_id)] = {
            "buyCount": bought + 1,
            "lastBuyStartTime": now,
        }
        self._save_state(account, state)
        result = self._message("ApiMallTrade.result")
        result.buy_count = bought + 1
        for dynamic in self._resource_dynamic_messages(changes):
            result.res_change.add().CopyFrom(dynamic)
        return 200, result

    @staticmethod
    def _request_value(body: Body, *keys: str, default: Any = None) -> Any:
        request = _body_object(body)
        for key in keys:
            if key in request:
                return request[key]
        return default

    def _recharge_offer(self, value: Any) -> Optional[Dict[str, Any]]:
        try:
            numeric = int(value)
        except (TypeError, ValueError):
            numeric = None
        if numeric is not None and numeric in self._RECHARGE_OFFERS:
            return {"rechargeId": numeric, **self._RECHARGE_OFFERS[numeric]}
        if isinstance(value, str):
            for recharge_id, offer in self._RECHARGE_OFFERS.items():
                if value == offer.get("productId"):
                    return {"rechargeId": recharge_id, **offer}
        return None

    def _recharge_state(self, state: Mapping[str, Any]) -> Dict[str, Any]:
        raw = state.get("purchases", {}).get("__recharge__", {})
        if not isinstance(raw, Mapping):
            raw = {}
        result = dict(raw)
        result.setdefault("totalCount", 0)
        result.setdefault("claims", {})
        result.setdefault("monthCards", {})
        result.setdefault("permitLevels", {})
        result.setdefault("giftRewards", [])
        result.setdefault("firstReward", False)
        result.setdefault("activeCodes", [])
        return result

    def _save_recharge_state(self, account: Mapping[str, Any], state: Dict[str, Any], recharge: Mapping[str, Any]) -> None:
        state.setdefault("purchases", {})["__recharge__"] = dict(recharge)
        self._save_state(account, state)

    def _grant_paid_currency(self, account: Mapping[str, Any], count: int) -> tuple[bool, list[dict[str, int]], str | None]:
        profile = self.game._profile(self._account_for_game(account))
        return self._change_resources(profile, [{"type": 5, "id": 0, "param": 0, "count": int(count)}])

    def _recharge_info(self, account: Mapping[str, Any], state: Dict[str, Any], recharge_type: Any = None) -> Response:
        info = self._recharge_state(state)
        fixed = []
        gifts = []
        for recharge_id, offer in self._RECHARGE_OFFERS.items():
            row = {
                "id": recharge_id,
                "rechargeId": recharge_id,
                "productId": offer["productId"],
                "price": float(offer.get("price", 0.0)),
                "count": int(offer["count"]),
                "showInShop": True,
                "sandbox": True,
            }
            (gifts if offer.get("giftBox") else fixed).append(row)
        return 200, {
            "ok": True,
            "result": True,
            "code": 0,
            "sandbox": True,
            "rechargeType": _int(recharge_type),
            "fixedRechargeInfo": fixed,
            "giftBoxRechargeInfo": gifts,
            "firstRechargeInfo": {"reward": [{"type": 5, "id": 0, "count": 60, "param": 0}], "rewardGot": bool(info.get("firstReward"))},
            "totalRechargeCnt": _int(info.get("totalCount")),
            "monthCardInfo": info.get("monthCards", {}),
            "permitInfo": info.get("permitLevels", {}),
        }

    def _recharge_claim(self, account: Mapping[str, Any], state: Dict[str, Any], body: Body, kind: str, *, one_time: bool = False) -> Response:
        value = self._request_value(body, "rechargeId", "recharge_id", "id", "giftboxId", "gift_box_id", "giftId", "gift_id")
        offer = self._recharge_offer(value)
        if offer is None:
            return 404, {"error": "unknown_local_recharge", "message": "use a known local sandbox recharge id"}
        info = self._recharge_state(state)
        claims = dict(info.get("claims", {}))
        key = f"{kind}:{offer['rechargeId']}"
        if one_time and claims.get(key):
            return 409, {"error": "recharge_reward_already_claimed"}
        ok, changes, error = self._grant_paid_currency(account, int(offer["count"]))
        if not ok:
            return 409, {"error": error or "resource_update_failed"}
        claims[key] = _int(claims.get(key)) + 1
        info["claims"] = claims
        info["totalCount"] = _int(info.get("totalCount")) + int(offer["count"])
        self._save_recharge_state(account, state, info)
        return 200, {
            "ok": True,
            "result": True,
            "code": 0,
            "sandbox": True,
            "rechargeId": offer["rechargeId"],
            "rewardTbl": changes,
            "giftBoxRechargeInfo": [],
        }

    def _recharge_before_buy(self, body: Body) -> Response:
        value = self._request_value(body, "rechargeId", "recharge_id", "id")
        offer = self._recharge_offer(value)
        if offer is None:
            return 404, {"error": "unknown_local_recharge"}
        return 200, {"ok": True, "result": True, "code": 0, "sandbox": True, "rechargeId": offer["rechargeId"], "price": 0.0, "attachParams": {"rechargeId": offer["rechargeId"], "productId": offer["productId"]}}

    def _recharge_month_card(self, account: Mapping[str, Any], state: Dict[str, Any], body: Body) -> Response:
        month_id = _int(self._request_value(body, "monthCardCfgId", "month_card_cfg_id", "id", default=1), 1)
        info = self._recharge_state(state)
        cards = dict(info.get("monthCards", {}))
        today = self._daily_key()
        key = str(month_id)
        record = dict(cards.get(key, {}))
        if record.get("lastDay") == today:
            return 409, {"error": "month_card_reward_already_claimed", "monthCardCfgId": month_id}
        ok, changes, error = self._grant_paid_currency(account, 30)
        if not ok:
            return 409, {"error": error or "resource_update_failed"}
        record.update({"monthCardCfgId": month_id, "lastDay": today, "rewardCount": _int(record.get("rewardCount")) + 1})
        cards[key] = record; info["monthCards"] = cards
        self._save_recharge_state(account, state, info)
        return 200, {"ok": True, "result": True, "code": 0, "sandbox": True, "monthCardCfgId": month_id, "rewardTbl": changes}

    def _recharge_permit(self, account: Mapping[str, Any], state: Dict[str, Any], body: Body, action: str) -> Response:
        permit_id = _int(self._request_value(body, "permitId", "permit_id", "id", default=1), 1)
        level = _int(self._request_value(body, "level", "permitLevel", "permit_level", default=1), 1)
        info = self._recharge_state(state); permits = dict(info.get("permitLevels", {})); key = str(permit_id)
        current = _int(permits.get(key, 0))
        if action == "buy":
            if level < 1 or level > 100:
                return 400, {"error": "invalid_permit_level"}
            current = max(current, level)
            permits[key] = current
            info["permitLevels"] = permits
            self._save_recharge_state(account, state, info)
            return 200, {"ok": True, "result": True, "code": 0, "sandbox": True, "permitId": permit_id, "level": current}
        claim_key = f"{key}:{level}:{action}"
        claims = dict(info.get("claims", {}))
        if current < level:
            return 409, {"error": "permit_level_locked"}
        if claims.get(claim_key):
            return 409, {"error": "permit_reward_already_claimed"}
        ok, changes, error = self._grant_paid_currency(account, 50)
        if not ok:
            return 409, {"error": error or "resource_update_failed"}
        claims[claim_key] = 1; info["claims"] = claims
        self._save_recharge_state(account, state, info)
        return 200, {"ok": True, "result": True, "code": 0, "sandbox": True, "permitId": permit_id, "level": level, "rewardTbl": changes}

    def _recharge_active_code(self, account: Mapping[str, Any], state: Dict[str, Any], body: Body) -> Response:
        code = str(self._request_value(body, "code", "activeCode", "active_code", default="")).strip().upper()
        if not code.startswith("LOCAL-"):
            return 402, {"error": "active_code_verification_required"}
        info = self._recharge_state(state); used = set(str(x) for x in info.get("activeCodes", []))
        if code in used:
            return 409, {"error": "active_code_already_used"}
        ok, changes, error = self._grant_paid_currency(account, 100)
        if not ok:
            return 409, {"error": error or "resource_update_failed"}
        used.add(code); info["activeCodes"] = sorted(used); self._save_recharge_state(account, state, info)
        return 200, {"ok": True, "result": True, "code": 0, "sandbox": True, "rewardTbl": changes}

    def _purchase_product(self, product_id: str) -> Optional[Dict[str, Any]]:
        product = self._PRODUCTS.get(product_id)
        if product is None and product_id:
            # The static client catalog is not present in the retired server
            # snapshot.  Accept only a finite set of familiar denomination
            # suffixes and still require the one-time sandbox token below;
            # this does not turn arbitrary IDs into arbitrary currency.
            match = re.search(r"(?:^|[^0-9])(60|300|980|1980|3280|6480)(?:$|[^0-9])", product_id)
            if match:
                count = int(match.group(1))
                product = {"price": count / 10.0, "count": count}
        if product is None:
            return None
        return {"productId": product_id, **product}

    def _purchase_touch(self, account: Mapping[str, Any], body: Body) -> Response:
        request = _body_object(body)
        message = _protobuf_request(self.game, body, "ApiPurchaseTouchProduct")
        product_id = str(
            request.get(
                "productId",
                request.get(
                    "product_id",
                    getattr(message, "product_id", "") if message is not None else "",
                ),
            )
        )
        product = self._purchase_product(product_id)
        if product is None:
            return 400, {"error": "unknown_local_product", "message": "use a local.sandbox product id"}
        count = _int(
            request.get(
                "count", getattr(message, "count", 1) if message is not None else 1
            ),
            1,
        )
        if count < 1 or count > 10:
            return 400, {"error": "invalid_purchase_count"}
        state = self._state(account)
        token = "local-sandbox:" + secrets.token_urlsafe(24)
        state["pending"][token] = {
            "productId": product_id,
            "count": count,
            "createdAt": self._now(),
            "isGuest": bool(request.get("isGuest", request.get("is_guest", False))),
        }
        self._save_state(account, state)
        result = self._message("ApiPurchaseTouchProduct.result")
        result.trade_data = token
        result.is_sandbox = True
        return 200, result

    def _purchase_delivery(self, account: Mapping[str, Any], body: Body) -> Response:
        request = _body_object(body)
        message = _protobuf_request(self.game, body, "ApiPurchaseDelevery")
        token = str(
            request.get(
                "tradeData",
                request.get(
                    "trade_data",
                    getattr(message, "trade_data", "") if message is not None else "",
                ),
            )
        )
        if not token:
            # Native SDK payloads may put the local token in the receipt field.
            token = str(
                request.get(
                    "transactionReceipt",
                    request.get(
                        "transaction_receipt",
                        getattr(message, "transaction_receipt", "")
                        if message is not None
                        else "",
                    ),
                )
            )
        if not token:
            # Some local IAP adapters preserve the server trade token under an
            # order/transaction key while adding the platform receipt beside
            # it.  Only a value carrying our explicit prefix is accepted.
            for key in ("transactionId", "transaction_id", "orderId", "order_id", "purchaseToken", "purchase_token"):
                candidate = str(request.get(key, ""))
                if candidate.startswith("local-sandbox:"):
                    token = candidate
                    break
        state = self._state(account)
        pending = state["pending"].pop(token, None)
        if not isinstance(pending, Mapping) or not token.startswith("local-sandbox:"):
            return 402, {"error": "payment_verification_required", "message": "only a server-issued local sandbox token is accepted"}
        product = self._purchase_product(str(pending.get("productId", "")))
        if product is None:
            return 409, {"error": "pending_product_unavailable"}
        quantity = _int(pending.get("count"), 1)
        profile = self.game._profile(self._account_for_game(account))
        ok, changes, error = self._change_resources(
            profile,
            [{"type": 5, "id": 0, "param": 0, "count": _int(product["count"]) * quantity}],
        )
        if not ok:
            return 409, {"error": error or "resource_update_failed"}
        transaction_id = token.removeprefix("local-sandbox:")
        state["purchases"][transaction_id] = {
            "productId": product["productId"],
            "count": quantity,
            "currency": "LOCAL_SANDBOX",
            "resourceChanges": changes,
            "completedAt": self._now(),
        }
        self._save_state(account, state)
        result = self._message("ApiPurchaseDelevery.result")
        result.transaction_id = transaction_id
        result.google_purchase_token = ""
        # Native protobuf deliveries carry channel in the parsed request; the
        # JSON seam uses the camel-case field.  Preserve either value in the
        # typed response so the client can finish its local IAP callback.
        result.channel = _int(
            request.get(
                "channel",
                getattr(message, "channel", 0) if message is not None else 0,
            )
        )
        return 200, result

    def _handle_http_unlocked(self, method: str, path: str, body: Body, profile: Mapping[str, Any]) -> Optional[Response]:
        route = _route(path)
        method = method.upper()
        if route == "/fci/purchasetouch/":
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            return self._purchase_touch(profile.get("account", profile), body)
        if route == "/fci/purchasedelevery/":
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            return self._purchase_delivery(profile.get("account", profile), body)
        if route in {"/fci/Shop/", "/fci/Shop"}:
            account = profile.get("account", profile)
            state = self._state(account)
            if method == "GET":
                return 200, self._shop_result_message(state["shop"][0])
            return 405, {"error": "method_not_allowed", "message": "GET required"}
        if route.startswith("/fci/Shop/"):
            parts = [part for part in route.split("/") if part]
            if len(parts) >= 4 and parts[1].lower() == "shop" and parts[2].isdigit() and parts[3].lower() == "goods":
                account = profile.get("account", profile)
                state = self._state(account)
                shop = self._find_shop(state, int(parts[2]))
                if shop is None:
                    return 404, {"error": "shop_not_found"}
                if method != "GET":
                    return 405, {"error": "method_not_allowed", "message": "GET required"}
                result = self._message("ApiShopGoods.get")
                for value in shop.get("goods", []):
                    if isinstance(value, Mapping):
                        result.get.add().CopyFrom(self._shop_good_message(value))
                return 200, result
            if len(parts) == 3 and parts[1].lower() == "shop" and parts[2].isdigit():
                account = profile.get("account", profile)
                state = self._state(account)
                shop = self._find_shop(state, int(parts[2]))
                if shop is None:
                    return 404, {"error": "shop_not_found"}
                if method != "GET":
                    return 405, {"error": "method_not_allowed", "message": "GET required"}
                return 200, self._shop_result_message(shop)
        if route in {"/fci/ShopTrade/", "/fci/ShopTrade"}:
            account = profile.get("account", profile)
            state = self._state(account)
            if method == "GET":
                return 200, []
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = _body_object(body)
            message = _protobuf_request(self.game, body, "ApiShopTrade")
            shop_id = _int(
                request.get(
                    "shopId",
                    request.get(
                        "shop_id",
                        getattr(message, "shop_id", 1) if message is not None else 1,
                    ),
                ),
                1,
            )
            info = getattr(message, "info", None) if message is not None else None
            message_good_id = getattr(info, "shopGoodId", 0) if info is not None else 0
            good_id = _int(
                request.get(
                    "shopGoodId",
                    request.get("goodId", request.get("good_id", message_good_id)),
                )
            )
            position = request.get(
                "index",
                request.get(
                    "position",
                    getattr(message, "index", None) if message is not None else None,
                ),
            )
            position_i = _int(position) if position is not None else None
            shop = self._find_shop(state, shop_id)
            if shop is None:
                return 404, {"error": "shop_not_found"}
            good = self._find_good(shop, good_id, position_i)
            if good is None:
                return 404, {"error": "shop_good_not_found"}
            limit = _int(good.get("buyLimit"), 0)
            bought = _int(good.get("buyCountRecord"), 0)
            if limit and bought >= limit:
                return 409, {"error": "shop_good_limit_reached"}
            costs = good.get("cost")
            if not isinstance(costs, list) or not costs:
                return 409, {"error": "shop_good_missing_cost"}
            profile_record = self.game._profile(account)
            # A completed trade consumes each cost and grants the purchased
            # resource in the same transaction.  Keeping both deltas in one
            # update prevents the item from being lost between reconnects.
            resource_changes = [{**cost, "count": -abs(_int(cost.get("count")))} for cost in costs]
            good_value = good.get("good")
            if isinstance(good_value, Mapping) and _int(good_value.get("count")) > 0:
                resource_changes.append(dict(good_value))
            ok, changes, error = self._change_resources(profile_record, resource_changes)
            if not ok:
                return 409, {"error": error or "insufficient_resource"}
            good["buyCountRecord"] = bought + 1
            self._save_state(account, state)
            good_copy = dict(good)
            good_copy["cost"] = [dict(x) for x in costs]
            result = self._message("ApiShopTrade.result")
            result.buy_count = int(good["buyCountRecord"])
            result.info.CopyFrom(self._shop_good_message(good_copy))
            for dynamic in self._resource_dynamic_messages(changes):
                result.res_change.add().CopyFrom(dynamic)
            return 200, result
        if route in {"/fci/mall-info/", "/fci/mall-info"}:
            account = profile.get("account", profile)
            state = self._state(account)
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            return 200, self._mall_info_message(account, state)
        if route in {"/fci/mall-trade/", "/fci/mall-trade"}:
            account = profile.get("account", profile)
            state = self._state(account)
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            return self._mall_trade(account, body, state)
        # Recharge model compatibility routes.  These are deliberately JSON
        # sandbox endpoints because the original RPC descriptors are not part
        # of the extracted REST descriptor set.  The websocket layer also
        # returns an explicit unsupported fallback for the corresponding
        # ``base.cs_*`` calls; only these local routes grant test currency.
        if route in {"/fci/recharge/", "/fci/recharge/info/", "/fci/recharge/info"}:
            account = profile.get("account", profile); state = self._state(account)
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            return self._recharge_info(account, state, self._request_value(body, "rechargeType", "recharge_type"))
        if route in {"/fci/recharge/before-buy-check/", "/fci/recharge/before-buy-check"}:
            return self._recharge_before_buy(body) if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/free/", "/fci/recharge/free"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_claim(account, state, body, "free") if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/voucher/", "/fci/recharge/voucher"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_claim(account, state, body, "voucher", one_time=True) if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/gift-box/", "/fci/recharge/gift-box"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_claim(account, state, body, "gift-box") if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/first-reward/", "/fci/recharge/first-reward"}:
            account = profile.get("account", profile); state = self._state(account); info = self._recharge_state(state)
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            if info.get("firstReward"):
                return 409, {"error": "first_recharge_reward_already_claimed"}
            ok, changes, error = self._grant_paid_currency(account, 60)
            if not ok:
                return 409, {"error": error or "resource_update_failed"}
            info["firstReward"] = True; self._save_recharge_state(account, state, info)
            return 200, {"ok": True, "result": True, "code": 0, "sandbox": True, "rewardTbl": changes}
        if route in {"/fci/recharge/gift-reward/", "/fci/recharge/gift-reward"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_claim(account, state, body, "gift-reward", one_time=True) if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/month-card/reward/", "/fci/recharge/month-card/reward"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_month_card(account, state, body) if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/permit/buy-level/", "/fci/recharge/permit/buy-level"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_permit(account, state, body, "buy") if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/permit/task-reward/", "/fci/recharge/permit/task-reward"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_permit(account, state, body, "task") if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/permit/level-reward/", "/fci/recharge/permit/level-reward"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_permit(account, state, body, "level") if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        if route in {"/fci/recharge/platform-active-code/", "/fci/recharge/platform-active-code"}:
            account = profile.get("account", profile); state = self._state(account)
            return self._recharge_active_code(account, state, body) if method == "POST" else (405, {"error": "method_not_allowed", "message": "POST required"})
        return None


    def handle_http(self, method: str, path: str, body: Body, profile: Mapping[str, Any]) -> Optional[Response]:
        """Serialize economy mutations per process/account store.

        The legacy handlers read state, mutate the game profile, and persist
        purchase markers across several helper calls.  Holding the module lock
        over the whole dispatch makes duplicate claims and purchases atomic for
        concurrent local HTTP requests.
        """
        with self._lock:
            return self._handle_http_unlocked(method, path, body, profile)



__all__ = ["LocalEconomy"]

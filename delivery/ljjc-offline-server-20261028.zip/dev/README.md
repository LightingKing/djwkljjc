# Development environment

The development emulator and host-only scripts live here. The existing
`DJWK_LJJC_API30` AVD is retained for compatibility; ROADMAP M0.4 adds the
isolated `LJJC_Offline_API28` AVD for no-audio/client stability testing.

Generated emulator snapshots, APKs, and logs must stay outside versioned
source directories.

Create and start the isolated Android 9 emulator:

```powershell
.\dev\create-api28-avd.ps1
.\dev\start-api28-avd.ps1 -WaitForBoot
```

The create step can be retried after an interrupted SDK download. The start
step uses `-no-audio`, port `5562`, and never resets or deletes
`DJWK_LJJC_API30` / `emulator-5560`.

After installing a local test APK, run five non-destructive cold starts:

```powershell
.\dev\cold-start-check.ps1 -Serial emulator-5562 -PackageName com.tencent.tmgp.fcicv
```

The check uses only `am force-stop` and `monkey`; it does not clear app data or
uninstall packages. A JSON report is written beside the script by default.

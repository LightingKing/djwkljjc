# M2.6 Protobuf 描述符审计

`tools/audit_descriptors.py` 对 `data/descriptor_set.pb` 和 `contracts/api.yaml` 做可重复比对。它只报告恢复结果，不根据字段名猜测缺失消息，因此不会把兼容 JSON 当成官方 protobuf 定义。

运行：

```powershell
python tools/audit_descriptors.py `
  --descriptor-set data/descriptor_set.pb `
  --contracts contracts/api.yaml `
  --output data/descriptor-audit.json
```

审计结果中的 `resolvedNames` 是服务端可以从描述符池构造的消息；`missingNames` 是契约表引用但无法构造的消息；`declaredButUnresolved` 表示消息名在输入描述符里存在，但被其它缺失或损坏依赖阻塞。`skippedFiles` 会列出输入描述符中语法字段损坏而被安全跳过的文件。枚举引用单独放在 `contractEnumTypes`，不会被误报为消息。当前结果重点是 `ApiServerUpdateInfo.result.TimeInfoEntry`，它来自被跳过的 `playeraction.proto`，后续需要从完整描述符、IL2CPP 消息类或旧流量逐字段核对。

这个工具不修改 APK、不访问远程服务，也不会把缺失字段写回描述符。补齐某个类型前，应先增加独立的 wireformat 编解码测试和来源记录。


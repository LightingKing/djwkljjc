"""Configuration-driven local dungeon state machine.

The checked-in APK exports contain normal chapter rows beyond the first
chapter, even though they are incomplete.  Every configured row is exposed as
a local sandbox stage and uses the same terminal ``FightActiveData`` protocol
as the verified 2012/2013 flow.  No remote or retired service is contacted.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path
from typing import Any, Mapping, Optional, Tuple
from urllib.parse import urlsplit

from google.protobuf import json_format

from server.core.content import DungeonConfig, load_dungeon_config


Response = Tuple[int, Any]
TUTORIAL_DUNGEON_ID = 2011
FIRST_STORY_BATTLE_ID = 2012
SECOND_STORY_BATTLE_ID = 2013
DUNGEON_CONFIG: DungeonConfig = load_dungeon_config()
# The IDs used by the local chapter screen come from ChapterInfo.json and the
# story rows in DungeonReward.json.  The first chapter is intentionally the
# verified local view while the export metadata says more rows were observed.
STORY_BATTLE_IDS = {FIRST_STORY_BATTLE_ID, SECOND_STORY_BATTLE_ID}
STORY_DUNGEON_IDS = set(DUNGEON_CONFIG.story_ids) or {TUTORIAL_DUNGEON_ID, *STORY_BATTLE_IDS}
# Additional non-fight story transitions observed in DungeonReward.  These
# optional scene IDs are playable locally but remain outside the main story
# completion gate because their historical placement is incomplete.
NONFIGHT_STORY_IDS = {
    int(row.get("dungeonId"))
    for row in DUNGEON_CONFIG.reward_rows
    if row.get("notFight") and row.get("dungeonId") is not None
}
NORMAL_DUNGEON_IDS = DUNGEON_CONFIG.supported_normal_ids
NORMAL_DUNGEON_ID_SET = set(NORMAL_DUNGEON_IDS)
# ``supported_normal_ids`` intentionally remains the first, resource-verified
# chapter for callers that use it as a compatibility marker.  Gameplay uses
# every normal stage present in the local ChapterInfo export, including
# challenge IDs (5102/5903/etc.).
ALL_NORMAL_DUNGEON_IDS = DUNGEON_CONFIG.all_normal_ids or NORMAL_DUNGEON_IDS
ALL_NORMAL_DUNGEON_ID_SET = set(ALL_NORMAL_DUNGEON_IDS)
PLAYABLE_DUNGEON_IDS = STORY_DUNGEON_IDS | NONFIGHT_STORY_IDS | ALL_NORMAL_DUNGEON_ID_SET
DUNGEON_TYPE_STORY = 1
DUNGEON_TYPE_NORMAL = 2
STORY_CHAPTER_ID = 1001
# These are deliberately small, local-only rewards.  The original service is
# unavailable, so the values are not presented as a reconstruction of its
# economy; they merely make the local tutorial progress visible and persistent.
TUTORIAL_EXP_REWARD = 10
FIRST_STORY_BATTLE_EXP_REWARD = 100
SECOND_STORY_BATTLE_EXP_REWARD = 100
# A deliberately small local-only reward for chapter 1 normal stages.  It is
# enough to make the result screen and persistent profile visibly progress,
# while avoiding a claim that this reproduces the retired economy.
NORMAL_DUNGEON_EXP_REWARD = 20
PLAYER_EXP_PER_LEVEL = 1000

# The retired service's special-dungeon tables are not available in the
# checkout.  These IDs and rewards are therefore deliberately local sandbox
# fixtures (see data/server-only/special-dungeons.yaml).  Keeping them in a
# separate range prevents an incomplete capture from being mistaken for a
# recovered official stage.
SPECIAL_DUNGEONS: dict[str, dict[str, Any]] = {
    "gold": {
        "id": 900001,
        "mode": "gold",
        "activity_id": "gold",
        "dungeon_type": 3,
        "energy_cost": 1,
        "reward": [{"type": 7, "id": 0, "param": 0, "count": 5000}],
        "label": "金币本",
    },
    "tower": {
        "id": 900101,
        "mode": "tower",
        "activity_id": "tower",
        "dungeon_type": 4,
        "energy_cost": 0,
        "reward": [{"type": 7, "id": 0, "param": 0, "count": 1000}],
        "label": "爬塔",
    },
    "maze": {
        "id": 900201,
        "mode": "maze",
        "activity_id": "maze",
        "dungeon_type": 5,
        "energy_cost": 1,
        "reward": [
            {"type": 7, "id": 0, "param": 0, "count": 1000},
            {"type": 11, "id": 910001, "param": 0, "count": 1},
        ],
        "label": "迷宫",
    },
    "tournament": {
        "id": 900301,
        "mode": "tournament",
        "activity_id": "tournament",
        "dungeon_type": 6,
        "energy_cost": 0,
        "reward": [
            {"type": 7, "id": 0, "param": 0, "count": 1500},
            {"type": 11, "id": 920001, "param": 0, "count": 1},
        ],
        "label": "锦标赛 PvE",
    },
}
SPECIAL_ID_TO_MODE = {int(item["id"]): mode for mode, item in SPECIAL_DUNGEONS.items()}
SPECIAL_MODE_ALIASES = {
    "gold": "gold", "golddungeon": "gold", "gold_dungeon": "gold", "金币": "gold", "金币本": "gold",
    "tower": "tower", "towerdungeon": "tower", "爬塔": "tower",
    "maze": "maze", "mazedungeon": "maze", "迷宫": "maze",
    "tournament": "tournament", "tournamentpve": "tournament", "锦标赛": "tournament",
}


def _normal_chapter_rows() -> tuple[Mapping[str, Any], ...]:
    """Return reviewed normal chapter rows in display order.

    ChapterInfo is an observed export, so rows may be incomplete.  The local
    server still exposes every row that is actually present; an empty export
    falls back to chapter one rather than inventing additional official rows.
    """

    rows = [
        row for row in DUNGEON_CONFIG.chapter_rows
        if int(row.get("type", 0) or 0) == 2 and row.get("dungeonId")
    ]
    return tuple(sorted(rows, key=lambda row: int(row.get("chapterIndex", row.get("chapterId", 0)) or 0)))


def _chapter_ids(row: Mapping[str, Any]) -> tuple[int, ...]:
    values: list[int] = []
    for raw in row.get("dungeonId", []) or []:
        try:
            values.append(int(raw))
        except (TypeError, ValueError):
            continue
    return tuple(dict.fromkeys(values))


def _is_challenge_stage(dungeon_id: int) -> bool:
    """Return whether the captured ID is in the challenge stage range.

    The extracted ChapterInfo rows do not contain a separate difficulty field.
    IDs in the 5xxx range are the only challenge markers present in the local
    evidence, so this helper keeps that inference explicit and reviewable.
    """

    try:
        return int(dungeon_id) >= 5000
    except (TypeError, ValueError):
        return False


def _chapter_row_for_dungeon(dungeon_id: int) -> Mapping[str, Any] | None:
    target = int(dungeon_id)
    for row in _normal_chapter_rows():
        if target in _chapter_ids(row):
            return row
    return None


def _chapter_row_by_id(chapter_id: int) -> Mapping[str, Any] | None:
    target = int(chapter_id)
    for row in _normal_chapter_rows():
        try:
            if int(row.get("chapterId", row.get("chapterIndex", 0)) or 0) == target:
                return row
            if int(row.get("storyChapterId", 0) or 0) == target:
                return row
        except (TypeError, ValueError):
            continue
    return None


def _dungeon_record(
    dungeon_id: int,
    *,
    unlocked: bool = True,
    finished: bool = False,
    stars: int = 0,
    targets_done: Optional[list[int]] = None,
    difficulty: str = "normal",
) -> dict[str, Any]:
    """Return the descriptor-shaped local record for an unlocked dungeon.

    The IDs are grounded in the captured ``ChapterInfo``/``DungeonReward``
    samples: 2011 is the non-fight story tutorial and 2012/2013 are its
    following story entries.  This is local progression state, not a claim
    about an original account's server record.
    """

    return {
        "dungeonId": int(dungeon_id),
        "unlocked": bool(unlocked),
        "finished": bool(finished and unlocked),
        "new": bool(unlocked and not finished),
        # Only fields present in DbDungeonRecords.DungeonRecord are emitted
        # here: this object is parsed by the client's typed protobuf path.
        # Star/difficulty metadata remains in the local SQLite row and is
        # reflected in chapter summary totals and balance JSON.
        "targetsDone": list(targets_done or []),
        "unlockEndTime": 0,
        "randomPosition": 0,
        "unlockTime": 0,
        "multiPower": 0,
        "doneTimes": 0,
        "buyNum": 0,
        "lastBuyTime": 0,
        "loseNum": 0,
    }


def _chapter_record(
    chapter_id: int,
    *,
    finished: bool = False,
    total_star: int = 0,
    unlocked: bool = True,
    star_reward_got: Optional[list[int]] = None,
) -> dict[str, Any]:
    return {
        "chapterId": int(chapter_id),
        "unlocked": bool(unlocked),
        "finished": bool(finished),
        "new": bool(unlocked and not finished),
        "starRewardGot": list(star_reward_got or []),
        "totalStar": max(0, int(total_star)),
        "unlockTime": 0,
    }


def _route(path: str) -> str:
    value = urlsplit(path or "").path or "/"
    if value != "/":
        value = value.rstrip("/") + "/"
    return value


def _body_object(body: bytes | bytearray | str | None) -> Mapping[str, Any]:
    if body is None:
        return {}
    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    if not raw:
        return {}
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, Mapping) else {}


class LocalDungeons:
    """Persistent local dungeon records attached to a :class:`LocalGame`."""

    def __init__(self, game: Any, clock: Optional[callable] = None) -> None:
        self.game = game
        self.db_path = Path(game.db_path)
        self._clock = clock or (lambda: int(time.time()))
        self._lock = threading.RLock()
        self._initialize()
        self._migrate_legacy_exp()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(str(self.db_path), timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self._lock, closing(self._connect()) as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS local_dungeons (
                    dungeon_uid INTEGER PRIMARY KEY,
                    account_id INTEGER NOT NULL,
                    player_id TEXT NOT NULL,
                    dungeon_id INTEGER NOT NULL,
                    dungeon_type INTEGER NOT NULL,
                    actor_uids_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    closed_at INTEGER,
                    balance_json TEXT
                )
                """
            )
            columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(local_dungeons)")
            }
            if "active_data" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN active_data BLOB")
            if "active_updated_at" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN active_updated_at INTEGER")
            if "balance_json" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN balance_json TEXT")
            # Special local modes reuse the same idempotent dungeon state
            # machine.  The columns are nullable so historical story rows
            # remain byte-for-byte compatible with the older schema.
            if "mode" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN mode TEXT NOT NULL DEFAULT 'story'")
            if "activity_id" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN activity_id TEXT")
            if "floor" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN floor INTEGER")
            if "node" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN node INTEGER")
            if "terminal_outcome" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN terminal_outcome INTEGER")
            if "difficulty" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN difficulty TEXT NOT NULL DEFAULT 'normal'")
            if "stars" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN stars INTEGER NOT NULL DEFAULT 0")
            if "targets_json" not in columns:
                connection.execute("ALTER TABLE local_dungeons ADD COLUMN targets_json TEXT NOT NULL DEFAULT '[]'")
            # Chapter first-clear/star/chest claims are kept separately from
            # battle rows.  The unique key makes a repeated HTTP request
            # idempotent across service restarts.
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS local_dungeon_claims (
                    account_id INTEGER NOT NULL,
                    chapter_id INTEGER NOT NULL,
                    claim_key TEXT NOT NULL,
                    claimed_at INTEGER NOT NULL,
                    payload_json TEXT NOT NULL,
                    PRIMARY KEY (account_id, chapter_id, claim_key)
                )
                """
            )

    def _new_uid(self, connection: sqlite3.Connection) -> int:
        current = connection.execute("SELECT MAX(dungeon_uid) FROM local_dungeons").fetchone()[0]
        # Keep UIDs deterministic and clearly local, while avoiding a time-only
        # collision if multiple test clients enter simultaneously.
        return max(int(current or 1000000000) + 1, int(self._clock() * 1000))

    @staticmethod
    def _actor_dict(actor_id: int, uid: int) -> dict[str, Any]:
        # Actor 1001/Role 1 and the model resource names are observed in the
        # config-samples capture. Attribute values are explicitly local-test
        # values; skills/talents remain empty until their tables are exported.
        return {
            "id": int(actor_id),
            "uid": int(uid),
            "curExp": 0,
            "level": 1,
            "star": 1,
            "quality": 1,
            "bodyEquips": {},
            "skills": [
                {"id": skill_id, "level": 1, "isRead": False}
                for skill_id in (1001001, 1001002, 1001003, 1001004, 1001005, 1001006)
            ],
            "attrs": [
                {"type": 1, "value": 1000, "isRatio": False},
                {"type": 3, "value": 100, "isRatio": False},
                {"type": 5, "value": 50, "isRatio": False},
                {"type": 6, "value": 50, "isRatio": False},
                {"type": 13, "value": 0, "isRatio": False},
                {"type": 14, "value": 150, "isRatio": False},
                {"type": 25, "value": 100, "isRatio": False},
            ],
            "equipAttrs": [],
            "specialAttrIds": [],
            "isNew": True,
            "isNewCard": True,
            "talentInfo": [],
            "isLock": False,
            "groupTag": {},
            "lastCalcAttrTime": 0,
            "talentResetPos": 0,
            "talentResetInfo": [],
            "countDelta": 0,
            "actorSkin": 0,
            "defaultIndex": max(0, int(uid) - 1),
            "isNormal": True,
        }

    def _profile_actor_ids(self, profile: Mapping[str, Any]) -> list[int]:
        actor_ids = profile.get("actor_ids")
        if isinstance(actor_ids, list) and actor_ids:
            return [int(value) for value in actor_ids]
        actor_id = profile.get("actor_id")
        return [int(actor_id)] if actor_id is not None else []

    def _base_info(
        self,
        profile: Mapping[str, Any],
        dungeon_id: int,
        actor_ids: list[int],
        actor_uids: list[int],
        *,
        dungeon_type: int = DUNGEON_TYPE_STORY,
        create_time: Optional[int] = None,
        activity_id: str | int = 0,
        floor: int = 0,
        node: int = 0,
        difficulty: str = "normal",
    ) -> dict[str, Any]:
        actors = [self._actor_dict(actor_id, uid) for actor_id, uid in zip(actor_ids, actor_uids)]
        return {
            "dungeonId": int(dungeon_id),
            "actorUid": actor_uids,
            "createTime": int(self._clock()) if create_time is None else int(create_time),
            "quitTime": 0,
            "activityType": int(dungeon_type) if int(dungeon_type) >= 3 else 0,
            "activityId": activity_id,
            "towerFloor": int(floor),
            "floor": int(floor),
            "mazeNode": int(node),
            "actorId": actor_ids,
            "auraPlayerId": "",
            "auraActorId": 0,
            "auraStranger": False,
            "auraActorQuality": 0,
            "dungeonType": int(dungeon_type),
            "actors": actors,
            "eventKey": "",
            "medalId": 0,
            "reduceInfo": [],
            "isChallengeMode": str(difficulty).lower() in {"hard", "challenge", "difficult"},
            "difficulty": str(difficulty or "normal"),
            "fightBuffs": [],
            "npcCnt": 0,
        }

    @staticmethod
    def _special_mode(value: Any) -> Optional[str]:
        """Normalize a local special-mode name supplied by a JSON client."""

        if value is None:
            return None
        key = str(value).strip().lower()
        return SPECIAL_MODE_ALIASES.get(key)

    def _special_spec(
        self,
        dungeon_id: int,
        request: Mapping[str, Any] | None = None,
    ) -> tuple[str, dict[str, Any], int, int] | None:
        """Resolve a local special run to ``(mode, spec, floor, node)``.

        Tower floors use a contiguous local range (900101 onward) and maze /
        tournament accept a small ``floor``/``stage`` parameter.  This is a
        compatibility seam for the local UI; it does not infer hidden
        official IDs from the incomplete APK exports.
        """

        request = request or {}
        mode = self._special_mode(request.get("mode", request.get("activity", request.get("activityType"))))
        try:
            did = int(dungeon_id)
        except (TypeError, ValueError):
            return None
        if mode is None:
            mode = SPECIAL_ID_TO_MODE.get(did)
            if mode is None:
                if 900101 <= did <= 900110:
                    mode = "tower"
                elif 900201 <= did <= 900210:
                    mode = "maze"
                elif 900301 <= did <= 900310:
                    mode = "tournament"
        floor_value = request.get("floor", request.get("towerFloor", request.get("stage", 1)))
        node_value = request.get("node", request.get("mazeNode", 1))
        try:
            floor = max(1, int(floor_value or 1))
            node = max(1, int(node_value or 1))
        except (TypeError, ValueError):
            return None
        if mode == "tower":
            # A supplied id wins; otherwise derive it from the requested
            # floor.  Ten local floors are enough for the minimal UI flow.
            if did != int(SPECIAL_DUNGEONS["tower"]["id"]):
                floor = did - int(SPECIAL_DUNGEONS["tower"]["id"]) + 1
            floor = max(1, min(10, floor))
            if did == SPECIAL_DUNGEONS["tower"]["id"] and floor != 1:
                did = int(SPECIAL_DUNGEONS["tower"]["id"]) + floor - 1
            if did < 900101 or did > 900110:
                return None
            spec = dict(SPECIAL_DUNGEONS["tower"])
            spec["id"] = did
            spec["reward"] = [{"type": 7, "id": 0, "param": 0, "count": 1000 * floor}]
        elif mode in {"maze", "tournament"}:
            spec = dict(SPECIAL_DUNGEONS[mode])
            if did != int(spec["id"]):
                # Accept the common stage/floor convention used by local
                # callers while keeping the exposed IDs deterministic.
                if did < int(spec["id"]) or did > int(spec["id"]) + 9:
                    return None
                floor = did - int(spec["id"]) + 1
                spec["id"] = did
            elif mode in {"maze", "tournament"} and did != int(spec["id"]):
                floor = did - int(spec["id"]) + 1
            if mode == "tournament":
                spec["reward"] = [{"type": 7, "id": 0, "param": 0, "count": 1500 * floor}, {"type": 11, "id": 920001, "param": 0, "count": 1}]
        elif mode == "gold":
            if did != int(SPECIAL_DUNGEONS["gold"]["id"]):
                return None
            spec = dict(SPECIAL_DUNGEONS["gold"])
        else:
            return None
        return mode, spec, floor, node

    def _resource_changes(
        self,
        profile: Mapping[str, Any],
        changes: list[Mapping[str, Any]],
    ) -> tuple[bool, list[dict[str, int]], str | None]:
        """Atomically apply local resource deltas to ``game_profiles``."""

        resources = [dict(item) for item in profile.get("resources", []) if isinstance(item, Mapping)]
        index = {
            (int(item.get("type", 0)), int(item.get("id", 0)), int(item.get("param", 0))): i
            for i, item in enumerate(resources)
        }
        normalized: list[tuple[int, int, int, int]] = []
        for raw in changes:
            try:
                normalized.append((int(raw.get("type", 0)), int(raw.get("id", 0)), int(raw.get("param", 0)), int(raw.get("count", 0))))
            except (TypeError, ValueError):
                return False, [], "invalid_resource_change"
        for rtype, rid, param, delta in normalized:
            if delta >= 0:
                continue
            key = (rtype, rid, param)
            current = int(resources[index[key]].get("count", 0)) if key in index else 0
            if current < -delta:
                return False, [], "insufficient_resource"
        deltas: list[dict[str, int]] = []
        for rtype, rid, param, delta in normalized:
            key = (rtype, rid, param)
            if key not in index:
                index[key] = len(resources)
                resources.append({"type": rtype, "id": rid, "param": param, "count": 0})
            item = resources[index[key]]
            item["count"] = max(0, int(item.get("count", 0)) + delta)
            deltas.append({"type": rtype, "id": rid, "param": param, "count": int(item["count"]), "countDelta": delta})
        with self._lock, closing(self._connect()) as connection, connection:
            updated = connection.execute(
                "UPDATE game_profiles SET resources_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(resources, separators=(",", ":")), int(self._clock()), int(profile["account_id"])),
            )
            if updated.rowcount != 1:
                return False, [], "profile_not_found"
        if isinstance(profile, dict):
            profile["resources"] = resources
        return True, deltas, None

    def _special_progress(self, profile: Mapping[str, Any], mode: str) -> int:
        with self._lock, closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT COALESCE(MAX(floor), 0) FROM local_dungeons WHERE account_id = ? AND mode = ? AND status = 'balanced'",
                (int(profile["account_id"]), mode),
            ).fetchone()
        return int(row[0] or 0) if row else 0

    def _enter_special(
        self,
        profile: Mapping[str, Any],
        mode: str,
        spec: Mapping[str, Any],
        floor: int,
        node: int,
    ) -> Response:
        actor_ids = self._profile_actor_ids(profile)
        if not actor_ids:
            return 409, {"error": "profile_has_no_actors"}
        dungeon_id = int(spec["id"])
        with self._lock, closing(self._connect()) as connection, connection:
            existing = connection.execute(
                "SELECT dungeon_uid, actor_uids_json, created_at, floor, node FROM local_dungeons WHERE account_id = ? AND dungeon_id = ? AND status = 'active' LIMIT 1",
                (int(profile["account_id"]), dungeon_id),
            ).fetchone()
            if existing is not None:
                actor_uids = [int(value) for value in json.loads(existing["actor_uids_json"] or "[]")]
                return 200, {
                    "dungeonUid": int(existing["dungeon_uid"]),
                    "baseInfo": self._base_info(profile, dungeon_id, actor_ids, actor_uids, dungeon_type=int(spec["dungeon_type"]), create_time=int(existing["created_at"]), activity_id=str(spec["activity_id"]), floor=int(existing["floor"] or floor), node=int(existing["node"] or node)),
                    "resChange": [], "mode": mode, "floor": int(existing["floor"] or floor), "node": int(existing["node"] or node), "sandbox": True,
                }
            if mode == "tower" and floor > self._special_progress(profile, mode) + 1:
                return 409, {"error": "tower_floor_locked", "floor": floor, "unlockedFloor": self._special_progress(profile, mode) + 1}
            cost = int(spec.get("energy_cost", 0) or 0)
            if cost:
                ok, resource_change, error = self._resource_changes(profile, [{"type": 6, "id": 0, "param": 0, "count": -cost}])
                if not ok:
                    return 409, {"error": error or "insufficient_energy", "energyCost": cost}
            actor_uids = list(range(1, len(actor_ids) + 1))
            dungeon_uid = self._new_uid(connection)
            connection.execute(
                "INSERT INTO local_dungeons (dungeon_uid, account_id, player_id, dungeon_id, dungeon_type, actor_uids_json, status, created_at, closed_at, mode, activity_id, floor, node) VALUES (?, ?, ?, ?, ?, ?, 'active', ?, NULL, ?, ?, ?, ?)",
                (dungeon_uid, int(profile["account_id"]), str(profile["player_id"]), dungeon_id, int(spec["dungeon_type"]), json.dumps(actor_uids, separators=(",", ":")), int(self._clock()), mode, str(spec["activity_id"]), floor, node),
            )
        return 200, {
            "dungeonUid": dungeon_uid,
            "baseInfo": self._base_info(profile, dungeon_id, actor_ids, actor_uids, dungeon_type=int(spec["dungeon_type"]), activity_id=str(spec["activity_id"]), floor=floor, node=node),
            "resChange": resource_change if cost else [], "mode": mode, "floor": floor, "node": node, "energyCost": cost, "sandbox": True,
        }

    def _special_info(self, profile: Mapping[str, Any], mode: str) -> Response:
        spec = SPECIAL_DUNGEONS[mode]
        progress = self._special_progress(profile, mode)
        with self._lock, closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT dungeon_uid, dungeon_id, status, floor, node, created_at, closed_at FROM local_dungeons WHERE account_id = ? AND mode = ? ORDER BY dungeon_uid DESC LIMIT 20",
                (int(profile["account_id"]), mode),
            ).fetchall()
        return 200, {
            "mode": mode,
            "activityId": str(spec["activity_id"]),
            "sandbox": True,
            "energyCost": int(spec.get("energy_cost", 0) or 0),
            "currentFloor": progress,
            "unlockedFloor": progress + 1,
            "maxFloor": 10 if mode in {"tower", "maze", "tournament"} else 1,
            "runs": [
                {"dungeonUid": int(row["dungeon_uid"]), "dungeonId": int(row["dungeon_id"]), "status": row["status"], "floor": int(row["floor"] or 1), "node": int(row["node"] or 1), "createTime": int(row["created_at"]), "quitTime": int(row["closed_at"] or 0)}
                for row in rows
            ],
        }

    def _finished_ids_and_difficulties(
        self,
        profile: Optional[Mapping[str, Any]],
        finished_dungeon_ids: Optional[set[int]] = None,
        finished_dungeon_difficulties: Optional[Mapping[int, str]] = None,
    ) -> tuple[set[int], dict[int, set[str]]]:
        """Read terminal progress while retaining normal/challenge isolation."""

        finished = {int(value) for value in (finished_dungeon_ids or set())}
        by_difficulty: dict[int, set[str]] = {}
        if finished_dungeon_difficulties:
            for dungeon_id, difficulty in finished_dungeon_difficulties.items():
                did = int(dungeon_id)
                finished.add(did)
                by_difficulty.setdefault(did, set()).add(str(difficulty or "normal"))
        if profile is None or profile.get("account_id") is None:
            return finished, by_difficulty
        with self._lock, closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT dungeon_id, status, difficulty FROM local_dungeons WHERE account_id = ?",
                (int(profile["account_id"]),),
            ).fetchall()
        for row in rows:
            did = int(row["dungeon_id"])
            if row["status"] != "balanced" or did not in PLAYABLE_DUNGEON_IDS:
                continue
            difficulty = str(row["difficulty"] or "normal")
            finished.add(did)
            by_difficulty.setdefault(did, set()).add(difficulty)
        return finished, by_difficulty

    def _chapter_unlock_state(
        self,
        profile: Optional[Mapping[str, Any]],
        finished_dungeon_ids: Optional[set[int]] = None,
    ) -> dict[int, bool]:
        """Compute chapter gates from captured ``preChapterId``/``keyDungeonId``.

        The normal entry endpoint remains permissive for compatibility with
        the old local test seam.  The state shown to the client and the
        opt-in strict entry path use this evidence-backed graph.
        """

        finished, _ = self._finished_ids_and_difficulties(profile, finished_dungeon_ids)
        state: dict[int, bool] = {}
        rows = _normal_chapter_rows()
        for row in rows:
            chapter_id = int(row.get("chapterId", row.get("chapterIndex", 0)) or 0)
            pre_id = int(row.get("preChapterId", 0) or 0)
            if pre_id <= 0:
                state[chapter_id] = True
                continue
            predecessor = _chapter_row_by_id(pre_id)
            required = tuple(int(value) for value in (predecessor or {}).get("keyDungeonId", []) or [])
            state[chapter_id] = bool(required) and set(required).issubset(finished)
        return state

    def _claimed_keys(self, profile: Mapping[str, Any], chapter_id: int) -> list[str]:
        with self._lock, closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT claim_key FROM local_dungeon_claims WHERE account_id = ? AND chapter_id = ? ORDER BY claim_key",
                (int(profile["account_id"]), int(chapter_id)),
            ).fetchall()
        return [str(row["claim_key"]) for row in rows]

    def _chapter_finished(
        self,
        profile: Mapping[str, Any],
        row: Mapping[str, Any],
        finished_dungeon_ids: Optional[set[int]] = None,
    ) -> bool:
        finished, _ = self._finished_ids_and_difficulties(profile, finished_dungeon_ids)
        ids = _chapter_ids(row)
        return bool(ids) and set(ids).issubset(finished)

    def _chapter_stars(self, profile: Mapping[str, Any], row: Mapping[str, Any]) -> int:
        ids = set(_chapter_ids(row))
        if not ids:
            return 0
        with self._lock, closing(self._connect()) as connection:
            records = connection.execute(
                "SELECT dungeon_id, MAX(stars) AS stars FROM local_dungeons WHERE account_id = ? AND status = 'balanced' GROUP BY dungeon_id",
                (int(profile["account_id"]),),
            ).fetchall()
        return sum(int(record["stars"] or 0) for record in records if int(record["dungeon_id"]) in ids)

    def _claim_chapter_reward(
        self,
        profile: Mapping[str, Any],
        chapter_id: int,
        body: bytes | bytearray | str | None,
        *,
        read_only: bool = False,
    ) -> Response:
        row = _chapter_row_by_id(chapter_id)
        if row is None:
            return 404, {"error": "chapter_not_found", "chapterId": int(chapter_id)}
        canonical_id = int(row.get("chapterId", row.get("chapterIndex", chapter_id)) or chapter_id)
        claimed = self._claimed_keys(profile, canonical_id)
        request = _body_object(body)
        raw_kind = request.get("kind", request.get("rewardType", request.get("type", "first_clear")))
        kind = str(raw_kind or "first_clear").strip().lower().replace("-", "_")
        aliases = {"first": "first_clear", "firstclear": "first_clear", "clear": "first_clear", "star": "star", "chest": "chest"}
        kind = aliases.get(kind, kind)
        if kind not in {"first_clear", "star", "chest"}:
            return 400, {"error": "invalid_reward_type", "allowed": ["first_clear", "star", "chest"]}
        threshold = 0
        if kind == "star":
            try:
                threshold = max(1, min(3, int(request.get("threshold", request.get("stars", 1)))))
            except (TypeError, ValueError):
                threshold = 1
            claim_key = f"star:{threshold}"
        else:
            claim_key = kind
        if read_only:
            return 200, {
                "sandbox": True,
                "chapterId": canonical_id,
                "requestedChapterId": int(chapter_id),
                "rewardType": kind,
                "threshold": threshold,
                "claimed": claim_key in claimed,
                "claimedKeys": claimed,
                "eligible": self._chapter_finished(profile, row) and (kind != "star" or self._chapter_stars(profile, row) >= threshold),
                "totalStar": self._chapter_stars(profile, row),
            }
        if claim_key in claimed:
            with self._lock, closing(self._connect()) as connection:
                cached = connection.execute(
                    "SELECT payload_json FROM local_dungeon_claims WHERE account_id = ? AND chapter_id = ? AND claim_key = ?",
                    (int(profile["account_id"]), canonical_id, claim_key),
                ).fetchone()
            try:
                payload = json.loads(cached["payload_json"]) if cached else None
            except (TypeError, ValueError, json.JSONDecodeError):
                payload = None
            if isinstance(payload, dict):
                payload["alreadyClaimed"] = True
                return 200, payload
            return 200, {"sandbox": True, "chapterId": canonical_id, "rewardType": kind, "alreadyClaimed": True, "resChange": []}
        total_stars = self._chapter_stars(profile, row)
        if not self._chapter_finished(profile, row):
            return 409, {"error": "chapter_not_finished", "chapterId": canonical_id, "sandbox": True}
        if kind == "star" and total_stars < threshold:
            return 409, {"error": "star_reward_locked", "chapterId": canonical_id, "threshold": threshold, "totalStar": total_stars, "sandbox": True}
        # No chapter reward table was recovered.  These are deliberately small
        # local-only values, kept in the response as sandbox metadata.
        count = 1000 if kind == "first_clear" else (500 * threshold if kind == "star" else 2000)
        ok, changes, error = self._resource_changes(profile, [{"type": 7, "id": 0, "param": 0, "count": count}])
        if not ok:
            return 409, {"error": error or "resource_update_failed", "sandbox": True}
        payload = {
            "sandbox": True,
            "provenance": "local-sandbox-no-official-chapter-reward-table",
            "chapterId": canonical_id,
            "requestedChapterId": int(chapter_id),
            "rewardType": kind,
            "threshold": threshold,
            "claimed": True,
            "alreadyClaimed": False,
            "totalStar": total_stars,
            "resChange": changes,
            "rewards": changes,
        }
        with self._lock, closing(self._connect()) as connection, connection:
            connection.execute(
                "INSERT INTO local_dungeon_claims (account_id, chapter_id, claim_key, claimed_at, payload_json) VALUES (?, ?, ?, ?, ?)",
                (int(profile["account_id"]), canonical_id, claim_key, int(self._clock()), json.dumps(payload, separators=(",", ":"))),
            )
        return 200, payload

    def chapter_snapshot(
        self,
        profile: Optional[Mapping[str, Any]] = None,
        finished_dungeon_ids: Optional[set[int]] = None,
        *,
        compact: bool = True,
        finished_dungeon_difficulties: Optional[Mapping[int, str]] = None,
    ) -> dict[str, Any]:
        """Return chapter and dungeon progress from local configured rows.

        The normal chapter export currently contains six rows (with an
        observed-count marker showing that the retired table had more).  All
        rows that are present are playable locally.  ``compact=True`` keeps
        the legacy two-record response used by the early tutorial balance
        screen; the normal chapter endpoint and login bootstrap use the full
        graph.
        """

        story_dungeon_ids = tuple(sorted(STORY_DUNGEON_IDS))
        chapter_rows = _normal_chapter_rows()
        if not chapter_rows:
            chapter_rows = ({"chapterId": 1, "chapterIndex": 1, "dungeonId": list(NORMAL_DUNGEON_IDS), "storyChapterId": 1001},)
        normal_dungeon_ids = tuple(dict.fromkeys(
            dungeon_id for row in chapter_rows for dungeon_id in _chapter_ids(row)
        ))
        dungeon_ids = story_dungeon_ids + normal_dungeon_ids
        finished_dungeon_ids, _finished_by_difficulty = self._finished_ids_and_difficulties(
            profile, finished_dungeon_ids, finished_dungeon_difficulties
        )
        unlock_state = self._chapter_unlock_state(profile, finished_dungeon_ids)
        # Preserve the best terminal stars and target conditions in the
        # chapter record.  Old rows have the migration defaults and therefore
        # remain valid.
        dungeon_meta: dict[int, tuple[int, list[int], str]] = {}
        if profile is not None and profile.get("account_id") is not None:
            with self._lock, closing(self._connect()) as connection:
                rows = connection.execute(
                    "SELECT dungeon_id, stars, targets_json, difficulty FROM local_dungeons WHERE account_id = ? AND status = 'balanced'",
                    (int(profile["account_id"]),),
                ).fetchall()
            for row in rows:
                try:
                    targets = json.loads(row["targets_json"] or "[]")
                    if not isinstance(targets, list):
                        targets = []
                except (TypeError, ValueError, json.JSONDecodeError):
                    targets = []
                current = dungeon_meta.get(int(row["dungeon_id"]))
                candidate = (int(row["stars"] or 0), [int(x) for x in targets if str(x).isdigit()], str(row["difficulty"] or "normal"))
                if current is None or candidate[0] > current[0]:
                    dungeon_meta[int(row["dungeon_id"])] = candidate
        dungeon_records = {}
        for dungeon_id in dungeon_ids:
            stars, targets, difficulty = dungeon_meta.get(dungeon_id, (0, [], "normal"))
            chapter_row = _chapter_row_for_dungeon(dungeon_id)
            chapter_id_for_dungeon = int(chapter_row.get("chapterId", chapter_row.get("chapterIndex", 0)) or 0) if chapter_row else 0
            unlocked = True if chapter_id_for_dungeon == 0 else bool(unlock_state.get(chapter_id_for_dungeon, False))
            record = _dungeon_record(
                dungeon_id,
                unlocked=unlocked,
                finished=dungeon_id in finished_dungeon_ids,
                stars=stars,
                targets_done=targets,
                difficulty=difficulty,
            )
            # Star/difficulty are retained in the local result record, but
            # the captured chapter protobuf does not define those fields.
            # Strip them before this map is converted with json_format so a
            # persisted result cannot break the chapter response on restart.
            for field in ("star", "stars", "difficulty"):
                record.pop(field, None)
            if dungeon_id in finished_dungeon_ids and unlocked:
                record["new"] = False
            dungeon_records[str(dungeon_id)] = record
        story_finished = set(story_dungeon_ids).issubset(finished_dungeon_ids)
        normal_finished = set(normal_dungeon_ids).issubset(finished_dungeon_ids)
        chapter_records: dict[str, dict[str, Any]] = {}
        chapter_summary: list[dict[str, Any]] = []
        for row in chapter_rows:
            chapter_id = int(row.get("chapterId", row.get("chapterIndex", 0)) or 0)
            ids = _chapter_ids(row)
            done = bool(ids) and set(ids).issubset(finished_dungeon_ids)
            total_star = sum(dungeon_meta.get(did, (0, [], "normal"))[0] for did in ids)
            unlocked = bool(unlock_state.get(chapter_id, True)) if not compact else True
            claimed_keys = self._claimed_keys(profile, chapter_id) if profile is not None else []
            star_claims = [
                int(key.split(":", 1)[1])
                for key in claimed_keys
                if key.startswith("star:") and key.split(":", 1)[1].isdigit()
            ]
            chapter_records[str(chapter_id)] = _chapter_record(
                chapter_id,
                finished=done,
                total_star=total_star,
                unlocked=unlocked,
                star_reward_got=star_claims,
            )
            story_alias = row.get("storyChapterId")
            if story_alias:
                alias_id = int(story_alias)
                chapter_records[str(alias_id)] = _chapter_record(
                    alias_id,
                    finished=done,
                    total_star=total_star,
                    unlocked=unlocked,
                    star_reward_got=star_claims,
                )
            chapter_summary.append({"id": chapter_id, "done": done, "ids": ids})
        # The story tutorial has its own alias and is kept beside normal
        # chapter 1 for the observed tutorial flow.
        if "1" not in chapter_records:
            chapter_records["1"] = _chapter_record(1, finished=normal_finished, total_star=sum(dungeon_records[str(did)].get("stars", 0) for did in _chapter_ids(chapter_rows[0])))
        if str(STORY_CHAPTER_ID) not in chapter_records:
            chapter_records[str(STORY_CHAPTER_ID)] = _chapter_record(STORY_CHAPTER_ID, finished=story_finished)
        else:
            chapter_records[str(STORY_CHAPTER_ID)]["finished"] = story_finished
            chapter_records[str(STORY_CHAPTER_ID)]["new"] = not story_finished
        if compact:
            keep = {"1", str(STORY_CHAPTER_ID)}
            chapter_records = {key: value for key, value in chapter_records.items() if key in keep}
        remaining_new_dungeons = [
            dungeon_id for dungeon_id in dungeon_ids if dungeon_id not in finished_dungeon_ids
        ]
        normal_chapter_ids = [int(row.get("chapterId", row.get("chapterIndex", 0)) or 0) for row in chapter_rows]
        normal_alias_ids = [int(row["storyChapterId"]) for row in chapter_rows if row.get("storyChapterId")]
        finished_normal_chapters = [cid for cid in normal_chapter_ids if chapter_records.get(str(cid), {}).get("finished")]
        finished_aliases = [cid for cid in normal_alias_ids if chapter_records.get(str(cid), {}).get("finished")]
        all_unlocked = [
            cid for cid in normal_chapter_ids if chapter_records.get(str(cid), {}).get("unlocked")
        ] + [
            cid for cid in normal_alias_ids if chapter_records.get(str(cid), {}).get("unlocked")
        ]
        if compact:
            all_unlocked = [1, STORY_CHAPTER_ID]
        summary = {
            "currentChapterId": STORY_CHAPTER_ID,
            "unlockedChapterId": all_unlocked,
            "finishedChapterId": (finished_normal_chapters + finished_aliases) if not compact else ([1] if normal_finished else []) + ([STORY_CHAPTER_ID] if story_finished else []),
            "newChapterId": [cid for cid in all_unlocked if cid not in set(finished_normal_chapters + finished_aliases)] if not compact else [STORY_CHAPTER_ID],
            "newDungeonId": remaining_new_dungeons,
            "totalStar": sum(item[0] for item in dungeon_meta.values()),
            "totalNormalStar": sum(item[0] for did, item in dungeon_meta.items() if int(did) in ALL_NORMAL_DUNGEON_ID_SET),
            "totalChallengeStar": sum(
                item[0]
                for did, item in dungeon_meta.items()
                if _is_challenge_stage(int(did))
            ),
            "unlockedStoryDungeonsCnt": len(story_dungeon_ids),
            "finishedStoryDungeonsCnt": sum(
                dungeon_id in finished_dungeon_ids for dungeon_id in story_dungeon_ids
            ),
            "unlockedNormalDungeonsCnt": len(normal_dungeon_ids),
            "finishedNormalDungeonsCnt": sum(
                dungeon_id in finished_dungeon_ids for dungeon_id in normal_dungeon_ids
            ),
            "unlockedTrainingDungeonsCnt": 0,
            "finishedTrainingDungeonsCnt": 0,
            "unlockedChallengeDungeonsCnt": sum(1 for did in normal_dungeon_ids if _is_challenge_stage(did)),
            "finishedChallengeDungeonsCnt": sum(
                did in finished_dungeon_ids
                for did in normal_dungeon_ids
                if _is_challenge_stage(did)
            ),
        }
        return {
            "record": {
                "playerId": "",
                "chapterRecord": chapter_records,
                "dungeonRecord": dungeon_records,
                "unlockAllChapter": 0,
            },
            "summary": summary,
        }

    def chapter_detail(self, profile: Mapping[str, Any], chapter_id: int) -> dict[str, Any]:
        """Return the typed ``ApiChapterInfo.get`` payload for one chapter.

        The login ``result`` response contains the complete map, but the
        client also reads ``fci/dungeon/chapter/<id>`` directly while binding
        chapter red points.  A missing detail object is logged as ``... is
        nil`` and causes the UI to retry indefinitely.  The captured export
        only identifies chapters 1 and 1001, so an unknown id receives the
        same local record shape with the requested id; it remains a local
        compatibility response and does not claim a recovered server row.
        """

        snapshot = self.chapter_snapshot(profile, compact=False)
        record_chapter = snapshot["record"]["chapterRecord"].get(str(int(chapter_id)))
        if record_chapter is None:
            record_chapter = _chapter_record(int(chapter_id))
        return {
            "recordChapter": record_chapter,
            "recordDungeons": dict(snapshot["record"]["dungeonRecord"]),
        }

    def _enter(self, profile: Mapping[str, Any], body: bytes | bytearray | str | None) -> Response:
        request = _body_object(body)
        raw_dungeon_id = request.get("dungeonId", request.get("dungeon_id"))
        if raw_dungeon_id is None and body is not None:
            # Common_DungeonUtil sends normal chapter entries as a raw
            # ``ApiDungeon`` protobuf, while story entries use the observed
            # JSON ``{dungeonId: ...}`` seam.  Parse the wireformat only after
            # the JSON path has been ruled out so malformed bytes never turn
            # into a surprising successful story entry.
            message_type = getattr(self.game, "_types", {}).get("ApiDungeon")
            if message_type is not None:
                try:
                    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
                    message = message_type()
                    message.ParseFromString(raw)
                    raw_dungeon_id = int(getattr(message, "dungeon_id", 0))
                    if bool(getattr(message, "is_challenge_mode", False)):
                        # Preserve the wire request's challenge flag for the
                        # local baseInfo/difficulty marker.
                        request = dict(request)
                        request["difficulty"] = "hard"
                except Exception:
                    raw_dungeon_id = None
        if raw_dungeon_id is None:
            requested_mode = self._special_mode(request.get("mode", request.get("activity", request.get("activityType"))))
            if requested_mode is not None:
                raw_dungeon_id = SPECIAL_DUNGEONS[requested_mode]["id"]
            else:
                raw_dungeon_id = TUTORIAL_DUNGEON_ID
        try:
            dungeon_id = int(raw_dungeon_id)
        except (TypeError, ValueError):
            return 400, {"error": "invalid_dungeon_id"}
        special = self._special_spec(dungeon_id, request)
        if special is not None:
            mode, spec, floor, node = special
            return self._enter_special(profile, mode, spec, floor, node)
        if dungeon_id not in PLAYABLE_DUNGEON_IDS:
            return 501, {"error": "dungeon_not_implemented", "dungeonId": dungeon_id}
        difficulty_value = request.get("difficulty", request.get("modeDifficulty", None))
        if difficulty_value is None and _is_challenge_stage(dungeon_id):
            difficulty_value = "challenge"
        if request.get("enforceUnlock", request.get("strictUnlock", False)):
            chapter_row = _chapter_row_for_dungeon(dungeon_id)
            if chapter_row is not None:
                chapter_id = int(chapter_row.get("chapterId", chapter_row.get("chapterIndex", 0)) or 0)
                if not self._chapter_unlock_state(profile).get(chapter_id, True):
                    return 409, {
                        "error": "chapter_locked",
                        "chapterId": chapter_id,
                        "dungeonId": dungeon_id,
                        "message": "finish the previous chapter key dungeon first",
                    }
        if isinstance(difficulty_value, bool):
            difficulty = "hard" if difficulty_value else "normal"
        else:
            difficulty = str(difficulty_value or "normal").strip().lower()
        if difficulty in {"2", "1", "hardmode", "difficult"}:
            difficulty = "hard"
        elif difficulty not in {"normal", "hard", "challenge"}:
            difficulty = "normal"
        dungeon_type = (
            DUNGEON_TYPE_NORMAL
            if dungeon_id in ALL_NORMAL_DUNGEON_ID_SET
            else DUNGEON_TYPE_STORY
        )
        actor_ids = self._profile_actor_ids(profile)
        if not actor_ids:
            return 409, {"error": "profile_has_no_actors", "message": "local profile actor bootstrap is empty"}
        actor_uids = list(range(1, len(actor_ids) + 1))
        with self._lock, closing(self._connect()) as connection, connection:
            existing = connection.execute(
                "SELECT dungeon_uid, dungeon_id, actor_uids_json, created_at, difficulty FROM local_dungeons WHERE account_id = ? AND dungeon_id = ? AND difficulty = ? AND status = 'active' LIMIT 1",
                (int(profile["account_id"]), dungeon_id, difficulty),
            ).fetchone()
            if existing is not None:
                # POST /fci/dungeon/ is retried by the client after a
                # disconnect.  Replaying the existing active instance is
                # idempotent and preserves its UID/creation time instead of
                # creating a second battle or forcing the client to recover
                # an otherwise valid local fight.
                stored_actor_uids = json.loads(existing["actor_uids_json"] or "[]")
                return 200, {
                    "dungeonUid": int(existing["dungeon_uid"]),
                    "baseInfo": self._base_info(
                        profile,
                        int(existing["dungeon_id"]),
                        actor_ids,
                        [int(value) for value in stored_actor_uids],
                        dungeon_type=dungeon_type,
                        create_time=int(existing["created_at"]),
                        difficulty=str(existing["difficulty"] or difficulty),
                    ),
                    "resChange": [],
                }
            dungeon_uid = self._new_uid(connection)
            connection.execute(
                """
                INSERT INTO local_dungeons
                (dungeon_uid, account_id, player_id, dungeon_id, dungeon_type,
                 actor_uids_json, status, created_at, closed_at, difficulty)
                VALUES (?, ?, ?, ?, ?, ?, 'active', ?, NULL, ?)
                """,
                (
                    dungeon_uid,
                    int(profile["account_id"]),
                    str(profile["player_id"]),
                    dungeon_id,
                    dungeon_type,
                    json.dumps(actor_uids, separators=(",", ":")),
                    int(self._clock()),
                    difficulty,
                ),
            )
        return 200, {
            "dungeonUid": dungeon_uid,
            "baseInfo": self._base_info(
                profile, dungeon_id, actor_ids, actor_uids, dungeon_type=dungeon_type,
                difficulty=difficulty,
            ),
            "resChange": [],
        }

    def _close(self, profile: Mapping[str, Any], dungeon_uid: int) -> Response:
        with self._lock, closing(self._connect()) as connection, connection:
            row = connection.execute(
                "SELECT account_id, status FROM local_dungeons WHERE dungeon_uid = ?",
                (dungeon_uid,),
            ).fetchone()
            if row is None or int(row["account_id"]) != int(profile["account_id"]):
                return 404, {"error": "dungeon_not_found"}
            if row["status"] == "active":
                connection.execute(
                    "UPDATE local_dungeons SET status = 'closed', closed_at = ? WHERE dungeon_uid = ?",
                    (int(self._clock()), dungeon_uid),
                )
            elif row["status"] not in {"closed", "balanced", "failed"}:
                return 409, {"error": "dungeon_not_active"}
            # Closing a terminal/previously closed record is idempotent.  It
            # never reopens the UID or clears its persisted active state.
        return 200, {}

    @staticmethod
    def _player_level_exp(profile: Mapping[str, Any]) -> tuple[int, int]:
        level = max(1, int(profile.get("level", 1)))
        exp = 0
        for resource in profile.get("resources", []):
            if isinstance(resource, Mapping) and int(resource.get("type", 0)) == 1:
                exp = int(resource.get("count", 0))
                break
        return level, max(0, exp)

    @staticmethod
    def _apply_exp_delta(
        profile: Mapping[str, Any], exp_delta: int
    ) -> tuple[int, int, int, int]:
        """Apply a local EXP delta to an in-memory profile value."""

        level_before, exp_before = LocalDungeons._player_level_exp(profile)
        delta = max(0, int(exp_delta))
        if delta == 0:
            return level_before, exp_before, level_before, exp_before
        resources = [
            dict(item)
            for item in profile.get("resources", [])
            if isinstance(item, Mapping)
        ]
        exp_resource = None
        for resource in resources:
            try:
                if int(resource.get("type", 0)) == 1:
                    exp_resource = resource
                    break
            except (TypeError, ValueError):
                continue
        if exp_resource is None:
            exp_resource = {"type": 1, "id": 0, "count": exp_before, "param": 0}
            resources.append(exp_resource)
        exp_after = exp_before + delta
        exp_resource["type"] = 1
        exp_resource.setdefault("id", 0)
        exp_resource.setdefault("param", 0)
        exp_resource["count"] = exp_after
        # A level-1 profile's first 1,000 EXP is the first level threshold.
        level_after = max(level_before, 1 + (exp_after // PLAYER_EXP_PER_LEVEL))
        if isinstance(profile, dict):
            profile["level"] = level_after
            profile["resources"] = resources
        return level_before, exp_before, level_after, exp_after

    def _grant_exp(self, profile: Mapping[str, Any], exp_delta: int) -> tuple[int, int, int, int]:
        """Persist a local tutorial EXP reward and return before/after values.

        Player EXP is resource type ``1`` in the extracted descriptor.  Keep
        the existing resource order and fields intact, adding/updating only
        that resource.  The level rule is intentionally a local seam: 1,000
        cumulative EXP advances one level and carries the remainder forward.
        """

        level_before, exp_before, level_after, exp_after = self._apply_exp_delta(
            profile, exp_delta
        )
        if exp_after == exp_before:
            return level_before, exp_before, level_after, exp_after
        resources = profile["resources"]
        with self._lock, closing(self._connect()) as connection, connection:
            connection.execute(
                "UPDATE game_profiles SET level = ?, resources_json = ?, updated_at = ? WHERE account_id = ?",
                (
                    level_after,
                    json.dumps(resources, separators=(",", ":")),
                    int(self._clock()),
                    int(profile["account_id"]),
                ),
            )
        return level_before, exp_before, level_after, exp_after

    @staticmethod
    def _legacy_exp_reward(dungeon_id: int) -> int:
        if int(dungeon_id) == TUTORIAL_DUNGEON_ID:
            return TUTORIAL_EXP_REWARD
        if int(dungeon_id) == FIRST_STORY_BATTLE_ID:
            return FIRST_STORY_BATTLE_EXP_REWARD
        return 0

    @staticmethod
    def _story_battle_exp_reward(dungeon_id: int) -> int:
        return {
            FIRST_STORY_BATTLE_ID: FIRST_STORY_BATTLE_EXP_REWARD,
            SECOND_STORY_BATTLE_ID: SECOND_STORY_BATTLE_EXP_REWARD,
        }.get(int(dungeon_id), 0)

    @staticmethod
    def _configured_player_exp(dungeon_id: int) -> int | None:
        """Read an explicit player EXP field when a recovered row has one.

        The checked-in DungeonReward sample exposes actor EXP and display drops,
        but no unambiguous player EXP field.  Those values are deliberately not
        guessed from actor EXP; callers use the reviewed local fallback below.
        """
        row = DUNGEON_CONFIG.reward_row(dungeon_id)
        if not row:
            return None
        for key in ("expPlayer", "playerExp", "exp_player"):
            try:
                value = int(row.get(key, 0) or 0)
            except (TypeError, ValueError):
                continue
            if value > 0:
                return value
        return None

    @staticmethod
    def _battle_exp_reward(dungeon_id: int) -> int:
        """Return configured player EXP or a documented local fallback."""

        configured = LocalDungeons._configured_player_exp(dungeon_id)
        if configured is not None:
            return configured
        story_reward = LocalDungeons._story_battle_exp_reward(dungeon_id)
        if story_reward:
            return story_reward
        if int(dungeon_id) in ALL_NORMAL_DUNGEON_ID_SET:
            return NORMAL_DUNGEON_EXP_REWARD
        return 0

    def _migrate_legacy_exp(self) -> None:
        """Upgrade old zero-delta tutorial balances once, transactionally.

        Early local-server builds persisted a schema-shaped EXP record with a
        zero delta.  The cache itself is the idempotency marker: after this
        method changes ``countDelta`` to the explicit local reward, later
        starts skip that row.  Profile and cache writes share one SQLite
        transaction, so a partial migration cannot leave the two disagreeing.
        """

        with self._lock, closing(self._connect()) as connection, connection:
            rows = connection.execute(
                """
                SELECT dungeon_uid, account_id, dungeon_id, balance_json
                FROM local_dungeons
                WHERE status = 'balanced'
                  AND dungeon_id IN (?, ?)
                  AND balance_json IS NOT NULL
                ORDER BY dungeon_uid
                """,
                (TUTORIAL_DUNGEON_ID, FIRST_STORY_BATTLE_ID),
            ).fetchall()
            candidates: list[tuple[sqlite3.Row, dict[str, Any], dict[str, Any]]] = []
            for row in rows:
                try:
                    payload = json.loads(row["balance_json"])
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
                if not isinstance(payload, dict):
                    continue
                balance = payload.get("balanceInfo")
                changes = balance.get("resChange") if isinstance(balance, Mapping) else None
                if not isinstance(changes, list):
                    continue
                target = None
                for change in changes:
                    if not isinstance(change, Mapping):
                        continue
                    base_res = change.get("baseRes")
                    if not isinstance(base_res, Mapping):
                        continue
                    try:
                        is_player_exp = int(base_res.get("type", 0)) == 1
                        is_zero_delta = int(base_res.get("countDelta", 0)) == 0
                    except (TypeError, ValueError):
                        continue
                    if is_player_exp and is_zero_delta:
                        target = change
                        break
                if target is not None and self._legacy_exp_reward(row["dungeon_id"]) > 0:
                    candidates.append((row, payload, target))
            if not candidates:
                return

            by_account: dict[int, list[tuple[sqlite3.Row, dict[str, Any], dict[str, Any]]]] = {}
            for item in candidates:
                by_account.setdefault(int(item[0]["account_id"]), []).append(item)

            cache_updates: list[tuple[str, int, int]] = []
            now = int(self._clock())
            for account_id, account_rows in by_account.items():
                profile_row = connection.execute(
                    "SELECT level, resources_json FROM game_profiles WHERE account_id = ?",
                    (account_id,),
                ).fetchone()
                if profile_row is None:
                    continue
                try:
                    resources = json.loads(profile_row["resources_json"] or "[]")
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
                # Leave empty profiles for LocalGame._migrate_profiles; that
                # later step may still need to install the reviewed starter
                # resources before a subsequent service start can migrate a
                # legacy balance.
                if not isinstance(resources, list) or not resources:
                    continue
                profile: dict[str, Any] = {
                    "account_id": account_id,
                    "level": int(profile_row["level"]),
                    "resources": resources,
                }
                changed = False
                for row, payload, target in account_rows:
                    reward = self._legacy_exp_reward(row["dungeon_id"])
                    level_before, exp_before, level_after, exp_after = self._apply_exp_delta(
                        profile, reward
                    )
                    base_res = target["baseRes"]
                    base_res["count"] = exp_after
                    base_res["countDelta"] = reward
                    balance = payload.get("balanceInfo")
                    if isinstance(balance, dict):
                        balance["playerLevelBeforeBalance"] = level_before
                        balance["playerLevel"] = level_after
                        balance["resChange"] = payload["balanceInfo"].get("resChange", [])
                        payload["resChange"] = json.loads(
                            json.dumps(balance["resChange"], separators=(",", ":"))
                        )
                    cache_updates.append(
                        (
                            json.dumps(payload, separators=(",", ":")),
                            int(row["dungeon_uid"]),
                            account_id,
                        )
                    )
                    changed = True
                if changed:
                    connection.execute(
                        "UPDATE game_profiles SET level = ?, resources_json = ?, updated_at = ? WHERE account_id = ?",
                        (
                            int(profile["level"]),
                            json.dumps(profile["resources"], separators=(",", ":")),
                            now,
                            account_id,
                        ),
                    )
            for balance_json, dungeon_uid, account_id in cache_updates:
                connection.execute(
                    "UPDATE local_dungeons SET balance_json = ? WHERE dungeon_uid = ? AND account_id = ? AND status = 'balanced'",
                    (balance_json, dungeon_uid, account_id),
                )

    def _balance_info(
        self,
        profile: Mapping[str, Any],
        *,
        won: bool,
        balance_time: int,
        first_finish: bool,
        exp_delta: int = 0,
        level_before: Optional[int] = None,
        exp_before: Optional[int] = None,
        stars: int = 0,
        targets_done: Optional[list[int]] = None,
        difficulty: str = "normal",
    ) -> dict[str, Any]:
        """Return every field read by DungeonBalance Lua.

        The response includes a player EXP resource record.  For the local
        tutorial seam ``exp_delta`` is a small explicit test reward; callers
        pass the profile after persistence so the count and level match the
        next login bootstrap.
        """

        level, exp = self._player_level_exp(profile)
        if level_before is None:
            level_before = level
        if exp_before is None:
            exp_before = max(0, exp - max(0, int(exp_delta)))
        resource_change = {
            "baseRes": {
                "type": 1,
                "id": 0,
                "count": exp,
                "param": 0,
                "countDelta": int(exp_delta),
            }
        }
        return {
            "balanced": True,
            "balanceTime": int(balance_time),
            "targetsDone": list(targets_done or []),
            "resChange": [resource_change],
            "expChange": [],
            "favourChange": [],
            "playerLevel": level,
            "playerLevelBeforeBalance": int(level_before),
            "win": bool(won),
            "firstFinish": bool(first_finish),
            "profits": [],
            "loseNum": 0,
            "expReturn": [],
            # These keys are consumed by the local JSON UI.  The typed
            # chapter protobuf intentionally omits them because the captured
            # descriptor has no star field on DungeonRecord.
            "stars": max(0, min(3, int(stars))),
            "star": max(0, min(3, int(stars))),
            "difficulty": str(difficulty or "normal"),
        }

    @staticmethod
    def _result_metrics(
        body: bytes | bytearray | str | Mapping[str, Any] | None,
        *,
        won: bool,
        dungeon_id: int | None = None,
    ) -> tuple[int, list[int]]:
        """Normalize optional local result metadata without trusting it for win.

        The terminal outcome always comes from FightActiveData.winTeam.  JSON
        callers may additionally report up to three completed star targets;
        absent metadata gets three stars for a deterministic local win and no
        stars for a loss.
        """

        value = body if isinstance(body, Mapping) else _body_object(body)
        raw_stars = value.get("stars", value.get("star", value.get("starCount")))
        try:
            stars = max(0, min(3, int(raw_stars))) if raw_stars is not None else (3 if won else 0)
        except (TypeError, ValueError):
            stars = 3 if won else 0
        raw_targets = value.get("targetsDone", value.get("targets", []))
        if isinstance(raw_targets, (str, int)):
            raw_targets = [raw_targets]
        targets: list[int] = []
        if isinstance(raw_targets, list):
            for item in raw_targets:
                try:
                    item_id = int(item.get("id")) if isinstance(item, Mapping) else int(item)
                except (TypeError, ValueError):
                    continue
                # The only recovered target schema uses IDs 1..3.  Unknown
                # target IDs are ignored instead of becoming invented stars.
                if 1 <= item_id <= 3 and item_id not in targets:
                    targets.append(item_id)
        if raw_stars is None and targets:
            stars = min(3, len(targets))
        if not won:
            stars = 0
        return stars, targets

    def _chapter_info_list(self, snapshot: Mapping[str, Any]) -> list[dict[str, Any]]:
        return [
            {
                "recordChapter": record,
                "recordDungeons": dict(snapshot["record"]["dungeonRecord"]),
            }
            for record in snapshot["record"]["chapterRecord"].values()
        ]

    def _terminal_balance_fallback(
        self,
        profile: Mapping[str, Any],
        row: sqlite3.Row,
    ) -> Optional[Response]:
        """Reconstruct a deterministic response for pre-cache terminal rows."""

        if row["status"] not in {"balanced", "failed"}:
            return None
        won = row["status"] == "balanced"
        if int(row["dungeon_id"]) in (STORY_BATTLE_IDS | ALL_NORMAL_DUNGEON_ID_SET) and row["active_data"]:
            active = self._decode_active_bytes(bytes(row["active_data"]))
            won = bool(active is not None and int(active.winTeam) == 1)
        snapshot = self.chapter_snapshot(
            profile,
            finished_dungeon_ids={int(row["dungeon_id"])} if won else set(),
            compact=True,
        )
        balance_info = self._balance_info(
            profile,
            won=won,
            balance_time=int(row["closed_at"] or self._clock()),
            first_finish=False,
        )
        payload = {
            "chapterSummaryInfo": snapshot["summary"],
            "chapterInfo": self._chapter_info_list(snapshot),
            "balanceInfo": balance_info,
            "resChange": list(balance_info["resChange"]),
        }
        return 200, payload

    def _balance(
        self,
        profile: Mapping[str, Any],
        dungeon_uid: int,
        body: bytes | bytearray | str | Mapping[str, Any] | None = None,
    ) -> Response:
        with self._lock, closing(self._connect()) as connection, connection:
            row = connection.execute(
                "SELECT dungeon_id, status, active_data, balance_json, closed_at, mode, activity_id, floor, node, difficulty, stars, targets_json FROM local_dungeons WHERE dungeon_uid = ? AND account_id = ?",
                (dungeon_uid, int(profile["account_id"])),
            ).fetchone()
        if row is None:
            return 404, {"error": "dungeon_not_found"}
        if row["status"] != "active":
            if row["balance_json"]:
                try:
                    cached = json.loads(row["balance_json"])
                except (TypeError, ValueError):
                    cached = None
                if isinstance(cached, dict):
                    return 200, cached
            fallback = self._terminal_balance_fallback(profile, row)
            if fallback is not None:
                return fallback
            return 409, {"error": "dungeon_not_active", "status": row["status"]}
        if row["mode"] and row["mode"] != "story":
            # Special modes use the same terminal FightActiveData seam when
            # the client has a battle result.  A JSON ``{"win": true}``
            # body is also accepted by local tools for simple deterministic
            # smoke tests; it never affects story stages.
            active = self._decode_active_bytes(bytes(row["active_data"])) if row["active_data"] else None
            won = bool(active is not None and int(active.winTeam) == 1)
            if not row["active_data"]:
                won = True
            if active is not None and int(active.winTeam) == 0:
                return 409, {"error": "battle_not_finished"}
            balance_time = int(self._clock())
            request = _body_object(body)
            # This call is intentionally kept body-free because _balance's
            # public seam historically receives only the uid.  A missing
            # active payload means an explicit local auto-win.
            mode = str(row["mode"])
            spec = SPECIAL_DUNGEONS.get(mode, SPECIAL_DUNGEONS["gold"])
            floor = int(row["floor"] or 1)
            node = int(row["node"] or 1)
            rewards = [dict(item) for item in spec.get("reward", [])]
            if mode == "tower":
                for item in rewards:
                    if int(item.get("type", 0)) == 7:
                        item["count"] = 1000 * floor
            if not won:
                rewards = []
            ok, reward_changes, error = self._resource_changes(profile, rewards)
            if not ok:
                return 409, {"error": error or "resource_update_failed"}
            payload = {
                "balanced": True,
                "balanceTime": balance_time,
                "win": won,
                "firstFinish": won and self._special_progress(profile, mode) < floor,
                "mode": mode,
                "activityId": row["activity_id"] or mode,
                "floor": floor,
                "node": node,
                "sandbox": True,
                "profits": reward_changes,
                "resChange": reward_changes,
                "balanceInfo": {
                    "balanced": True, "win": won, "firstFinish": won and self._special_progress(profile, mode) < floor,
                    "balanceTime": balance_time, "profits": reward_changes, "resChange": reward_changes,
                },
            }
            with self._lock, closing(self._connect()) as connection, connection:
                updated = connection.execute(
                    "UPDATE local_dungeons SET status = ?, closed_at = ?, terminal_outcome = ?, balance_json = ? WHERE dungeon_uid = ? AND account_id = ? AND status = 'active'",
                    ("balanced" if won else "failed", balance_time, 1 if won else 2, json.dumps(payload, separators=(",", ":")), dungeon_uid, int(profile["account_id"])),
                )
                if updated.rowcount != 1:
                    return 409, {"error": "dungeon_not_active"}
            return 200, payload
        if int(row["dungeon_id"]) in (STORY_BATTLE_IDS | ALL_NORMAL_DUNGEON_ID_SET):
            active_data = row["active_data"]
            if not active_data:
                return 409, {
                    "error": "battle_not_finished",
                    "message": "FightActiveData PATCH is required before balance",
                }
            active = self._decode_active_bytes(bytes(active_data))
            if active is None:
                return 409, {"error": "invalid_fight_active_data"}
            # FightActiveData.winTeam is the client's actual terminal outcome.
            # A zero value means the fight is still in progress; do not infer a
            # win from a request count or from the configured monster row.
            win_team = int(active.winTeam)
            if win_team == 0:
                return 409, {"error": "battle_not_finished"}
            won = win_team == 1
            stars, targets_done = self._result_metrics(body, won=won, dungeon_id=int(row["dungeon_id"]))
            difficulty = str(row["difficulty"] or "normal")
            balance_time = int(self._clock())
            with self._lock, closing(self._connect()) as connection:
                previous_finish = connection.execute(
                    "SELECT 1 FROM local_dungeons WHERE account_id = ? AND dungeon_id = ? AND difficulty = ? AND status = 'balanced' LIMIT 1",
                    (int(profile["account_id"]), int(row["dungeon_id"]), str(row["difficulty"] or "normal")),
                ).fetchone() is not None
            exp_reward = self._battle_exp_reward(int(row["dungeon_id"]))
            if won:
                level_before, exp_before, _, _ = self._grant_exp(
                    profile, exp_reward
                )
                exp_delta = exp_reward
            else:
                level_before, exp_before = self._player_level_exp(profile)
                exp_delta = 0
            snapshot = self.chapter_snapshot(
                profile,
                finished_dungeon_ids={int(row["dungeon_id"])} if won else set(),
                compact=True,
                finished_dungeon_difficulties={int(row["dungeon_id"]): difficulty} if won else None,
            )
            balance_info = self._balance_info(
                profile,
                won=won,
                balance_time=balance_time,
                first_finish=won and not previous_finish,
                exp_delta=exp_delta,
                level_before=level_before,
                exp_before=exp_before,
                stars=stars,
                targets_done=targets_done,
                difficulty=difficulty,
            )
            payload = {
                "dungeonId": int(row["dungeon_id"]),
                "stars": stars,
                "star": stars,
                "difficulty": difficulty,
                "chapterSummaryInfo": snapshot["summary"],
                "chapterInfo": self._chapter_info_list(snapshot),
                "balanceInfo": balance_info,
                "resChange": list(balance_info["resChange"]),
            }
            with self._lock, closing(self._connect()) as connection, connection:
                updated = connection.execute(
                    "UPDATE local_dungeons SET status = ?, closed_at = ?, stars = ?, targets_json = ?, balance_json = ? WHERE dungeon_uid = ? AND account_id = ? AND status = 'active'",
                    (
                        "balanced" if won else "failed",
                        balance_time,
                        stars if won else 0,
                        json.dumps(targets_done, separators=(",", ":")),
                        json.dumps(payload, separators=(",", ":")),
                        dungeon_uid,
                        int(profile["account_id"]),
                    ),
                )
                if updated.rowcount != 1:
                    return 409, {"error": "dungeon_not_active"}
            return 200, payload
        if int(row["dungeon_id"]) not in NONFIGHT_STORY_IDS:
            return 501, {"error": "dungeon_balance_not_implemented"}
        # These rows are marked notFight in the captured config. Return the
        # response containers the Lua exit path reads without claiming a
        # fabricated combat result. The tutorial (2011) gets its reviewed
        # local EXP reward; later scene transitions complete with zero EXP.
        nonfight_reward = TUTORIAL_EXP_REWARD if int(row["dungeon_id"]) == TUTORIAL_DUNGEON_ID else 0
        balance_time = int(self._clock())
        with self._lock, closing(self._connect()) as connection:
            previous_finish = connection.execute(
                "SELECT 1 FROM local_dungeons WHERE account_id = ? AND dungeon_id = ? AND status = 'balanced' LIMIT 1",
                (int(profile["account_id"]), int(row["dungeon_id"])),
            ).fetchone() is not None
        if nonfight_reward:
            level_before, exp_before, _, _ = self._grant_exp(profile, nonfight_reward)
        else:
            level_before, exp_before = self._player_level_exp(profile)
        snapshot = self.chapter_snapshot(profile, finished_dungeon_ids={int(row["dungeon_id"])}, compact=True)
        balance_info = self._balance_info(
            profile,
            won=True,
            balance_time=balance_time,
            first_finish=not previous_finish,
            exp_delta=nonfight_reward,
            level_before=level_before,
            exp_before=exp_before,
        )
        payload = {
            "dungeonId": int(row["dungeon_id"]),
            "sandbox": True,
            "chapterSummaryInfo": snapshot["summary"],
            "chapterInfo": self._chapter_info_list(snapshot),
            "balanceInfo": balance_info,
            "resChange": list(balance_info["resChange"]),
        }
        with self._lock, closing(self._connect()) as connection, connection:
            updated = connection.execute(
                "UPDATE local_dungeons SET status = 'balanced', closed_at = ?, balance_json = ? WHERE dungeon_uid = ? AND account_id = ? AND status = 'active'",
                (
                    balance_time,
                    json.dumps(payload, separators=(",", ":")),
                    dungeon_uid,
                    int(profile["account_id"]),
                ),
            )
            if updated.rowcount != 1:
                return 409, {"error": "dungeon_not_active"}
        return 200, payload

    def _sweep(
        self,
        profile: Mapping[str, Any],
        dungeon_id: int,
        body: bytes | bytearray | str | None,
    ) -> Response:
        """Run a bounded local sweep after a difficulty-specific clear.

        No official sweep contract or drop table survived in the checked-in
        evidence.  The endpoint therefore grants only the reviewed local EXP
        fallback and advertises ``sandbox``/``provenance`` in every response.
        """

        request = _body_object(body)
        difficulty_value = request.get("difficulty", request.get("modeDifficulty", None))
        difficulty = str(difficulty_value or ("challenge" if _is_challenge_stage(dungeon_id) else "normal")).strip().lower()
        if difficulty in {"1", "2", "hardmode", "difficult"}:
            difficulty = "hard"
        if difficulty not in {"normal", "hard", "challenge"}:
            return 400, {"error": "invalid_difficulty", "allowed": ["normal", "hard", "challenge"]}
        try:
            count = max(1, min(10, int(request.get("count", request.get("times", 1)))))
        except (TypeError, ValueError):
            count = 1
        with self._lock, closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT MAX(stars) AS stars FROM local_dungeons WHERE account_id = ? AND dungeon_id = ? AND difficulty = ? AND status = 'balanced'",
                (int(profile["account_id"]), int(dungeon_id), difficulty),
            ).fetchone()
        if row is None or row["stars"] is None:
            return 409, {
                "error": "sweep_locked",
                "message": "clear this dungeon at the requested difficulty first",
                "dungeonId": int(dungeon_id),
                "difficulty": difficulty,
                "sandbox": True,
            }
        exp_delta = self._battle_exp_reward(int(dungeon_id)) * count
        if exp_delta:
            level_before, exp_before, _, _ = self._grant_exp(profile, exp_delta)
        else:
            level_before, exp_before = self._player_level_exp(profile)
        level_after, exp_after = self._player_level_exp(profile)
        changes = []
        if exp_delta:
            changes = [{"type": 1, "id": 0, "param": 0, "count": exp_after, "countDelta": exp_delta}]
        return 200, {
            "sandbox": True,
            "provenance": "local-sandbox-no-official-sweep-table",
            "dungeonId": int(dungeon_id),
            "difficulty": difficulty,
            "count": count,
            "stars": int(row["stars"] or 0),
            "firstFinish": False,
            "resChange": changes,
            "rewards": changes,
            "balanceInfo": {
                "balanced": True,
                "win": True,
                "sweep": True,
                "count": count,
                "playerLevel": level_after,
                "playerLevelBeforeBalance": level_before,
                "resChange": changes,
                "expBefore": exp_before,
                "expAfter": exp_after,
            },
        }

    def _decode_active_bytes(self, raw: bytes):
        """Decode a canonical FightActiveData protobuf payload."""

        message_type = getattr(self.game, "_types", {}).get("FightActiveData")
        if message_type is None:
            return None
        message = message_type()
        try:
            message.ParseFromString(raw)
        except (TypeError, ValueError):
            return None
        return message

    def _parse_active(self, body: bytes | bytearray | str | Mapping[str, Any] | None):
        """Accept the observed JSON test seam or raw FightActiveData bytes."""

        message_type = getattr(self.game, "_types", {}).get("FightActiveData")
        if message_type is None:
            return None
        message = message_type()
        if isinstance(body, Mapping):
            try:
                json_format.ParseDict(dict(body), message)
            except (TypeError, ValueError):
                return None
            return message
        if isinstance(body, str):
            try:
                body = body.encode("utf-8")
            except UnicodeEncodeError:
                return None
        if body is None:
            return None
        raw = bytes(body)
        if not raw:
            return None
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            value = None
        if isinstance(value, Mapping):
            try:
                json_format.ParseDict(dict(value), message)
            except (TypeError, ValueError):
                return None
            return message
        return self._decode_active_bytes(raw)

    def _active(self, profile: Mapping[str, Any], dungeon_uid: int, body: bytes | bytearray | str | None) -> Response:
        with self._lock, closing(self._connect()) as connection, connection:
            row = connection.execute(
                "SELECT dungeon_id, status, mode FROM local_dungeons WHERE dungeon_uid = ? AND account_id = ?",
                (dungeon_uid, int(profile["account_id"])),
            ).fetchone()
            if row is None:
                return 404, {"error": "dungeon_not_found"}
            if row["mode"] == "story" and int(row["dungeon_id"]) not in (STORY_BATTLE_IDS | NONFIGHT_STORY_IDS | ALL_NORMAL_DUNGEON_ID_SET):
                return 501, {"error": "dungeon_active_not_implemented"}
            if row["status"] != "active":
                return 409, {"error": "dungeon_not_active"}
            message = self._parse_active(body)
            if message is None:
                return 400, {"error": "invalid_fight_active_data"}
            encoded = message.SerializeToString()
            connection.execute(
                "UPDATE local_dungeons SET active_data = ?, active_updated_at = ? WHERE dungeon_uid = ? AND account_id = ?",
                (encoded, int(self._clock()), dungeon_uid, int(profile["account_id"])),
            )
        # The client ignores the body of the active PATCH callback.  An empty
        # object acknowledges persistence without claiming a battle result.
        return 200, {}

    def handle_http(
        self,
        method: str,
        path: str,
        body: bytes | bytearray | str | None,
        profile: Mapping[str, Any],
    ) -> Optional[Response]:
        route = _route(path)
        method = method.upper()
        # The original client uses feature-specific GoldDungeon*/Tower*/Maze*
        # and Tournament* resources.  Their retired descriptors are not
        # available, so expose a small JSON compatibility seam alongside the
        # canonical /fci/dungeon/ state machine.  All mutations still use the
        # same authenticated profile and persisted rows.
        special_route_mode: Optional[str] = None
        special_route_prefix: Optional[str] = None
        for prefix, mode in (
            ("/fci/gold-dungeon", "gold"), ("/fci/golddungeon", "gold"),
            ("/fci/tower", "tower"), ("/fci/maze", "maze"),
            ("/fci/tournament", "tournament"),
        ):
            if route.lower().startswith(prefix + "/") or route.lower() == prefix + "/":
                special_route_mode = mode
                special_route_prefix = prefix
                break
        if special_route_mode is not None:
            suffix = route[len(special_route_prefix or "") :].strip("/").lower()
            if suffix.endswith("/balance"):
                uid_text = suffix[: -len("/balance")].strip("/")
                if uid_text.isdigit():
                    return self._balance(profile, int(uid_text), body)
            if suffix.endswith("/active"):
                uid_text = suffix[: -len("/active")].strip("/")
                if uid_text.isdigit():
                    return self._active(profile, int(uid_text), body) if method == "PATCH" else (405, {"error": "method_not_allowed"})
            if suffix.isdigit() and method == "GET":
                # Reuse the canonical run-record response by dispatching via
                # the normal dungeon resource path.
                return self.handle_http("GET", f"/fci/dungeon/{suffix}", body, profile)
            if suffix in {"", "info", "status", "list"} and method == "GET":
                return self._special_info(profile, special_route_mode)
            if method == "POST" and suffix in {"", "enter", "start", "open"}:
                request = dict(_body_object(body))
                request.setdefault("mode", special_route_mode)
                return self._enter(profile, json.dumps(request, separators=(",", ":")))
            return 405, {"error": "method_not_allowed"}
        if route == "/fci/dungeon/":
            return self._enter(profile, body) if method == "POST" else (405, {"error": "method_not_allowed"})
        if route == "/fci/dungeon/chapter/":
            if method != "GET":
                return 405, {"error": "method_not_allowed"}
            # The login bootstrap keeps the historical compact graph, while
            # the explicit chapter resource exposes every locally configured
            # chapter for the full offline map.
            return 200, self.chapter_snapshot(profile, compact=False)
        chapter_prefix = "/fci/dungeon/chapter/"
        if route.startswith(chapter_prefix):
            chapter_suffix = route[len(chapter_prefix) :].strip("/")
            if chapter_suffix.lower() in {"full", "all"}:
                if method != "GET":
                    return 405, {"error": "method_not_allowed"}
                return 200, self.chapter_snapshot(profile, compact=False)
            chapter_parts = chapter_suffix.split("/") if chapter_suffix else []
            if not chapter_parts or not chapter_parts[0].isdigit():
                return None
            chapter_id = int(chapter_parts[0])
            if len(chapter_parts) > 1 and chapter_parts[1].lower() in {"reward", "rewards", "claim", "chest"}:
                if method not in {"GET", "POST"}:
                    return 405, {"error": "method_not_allowed"}
                claim_body = body
                if chapter_parts[1].lower() == "chest":
                    request = dict(_body_object(body))
                    request.setdefault("kind", "chest")
                    claim_body = json.dumps(request, separators=(",", ":"))
                return self._claim_chapter_reward(profile, chapter_id, claim_body, read_only=method == "GET")
            if method != "GET":
                return 405, {"error": "method_not_allowed"}
            return 200, self.chapter_detail(profile, chapter_id)
        prefix = "/fci/dungeon/"
        if not route.startswith(prefix):
            return None
        suffix = route[len(prefix) :].strip("/")
        if suffix.endswith("/sweep"):
            dungeon_text = suffix[: -len("/sweep")].strip("/")
            if not dungeon_text.isdigit():
                return None
            if method != "POST":
                return 405, {"error": "method_not_allowed"}
            return self._sweep(profile, int(dungeon_text), body)
        if suffix.endswith("/balance"):
            uid_text = suffix[: -len("/balance")].strip("/")
            if not uid_text.isdigit():
                return None
            return self._balance(profile, int(uid_text), body)
        if suffix.endswith("/active"):
            uid_text = suffix[: -len("/active")].strip("/")
            if not uid_text.isdigit():
                return None
            return self._active(profile, int(uid_text), body) if method == "PATCH" else (405, {"error": "method_not_allowed"})
        if not suffix.isdigit():
            return None
        dungeon_uid = int(suffix)
        if method == "DELETE":
            return self._close(profile, dungeon_uid)
        if method == "GET":
            with self._lock, closing(self._connect()) as connection:
                row = connection.execute(
                    "SELECT dungeon_id, actor_uids_json, status, created_at, closed_at, mode, activity_id, floor, node FROM local_dungeons WHERE dungeon_uid = ? AND account_id = ?",
                    (dungeon_uid, int(profile["account_id"])),
                ).fetchone()
            if row is None:
                return 404, {"error": "dungeon_not_found"}
            return 200, {
                "dungeonUid": dungeon_uid,
                "dungeonId": row["dungeon_id"],
                "actorUid": json.loads(row["actor_uids_json"]),
                "status": row["status"],
                "createTime": row["created_at"],
                "quitTime": row["closed_at"] or 0,
                "mode": row["mode"] or "story",
                "activityId": row["activity_id"] or 0,
                "floor": int(row["floor"] or 0),
                "node": int(row["node"] or 0),
            }
        return 405, {"error": "method_not_allowed"}


__all__ = [
    "LocalDungeons",
    "TUTORIAL_DUNGEON_ID",
    "SPECIAL_DUNGEONS",
    "NORMAL_DUNGEON_IDS",
    "ALL_NORMAL_DUNGEON_IDS",
    "NONFIGHT_STORY_IDS",
    "PLAYABLE_DUNGEON_IDS",
]

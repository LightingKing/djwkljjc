# Client patch pipeline

This directory is the home for the deterministic APK patch pipeline described
by ROADMAP M1.2. The original APK is a read-only input; patched APKs and
keystores stay under ignored `work/`, `output/`, and `keystore/` directories.

Implemented stages are SHA-256 verification, apktool unpack, manifest-driven
file/text patches, rebuild, zipalign, signing, and signature verification.
Frida remains a development capture tool only and is not part of the normal
play path.

The source APK is always opened read-only. Start with a dry run:

```powershell
python .\client-patch\build.py `
  --input .\original.apk `
  --manifest .\client-patch\patches\empty-patch.example.json `
  --output-dir .\client-patch\output `
  --expected-sha256 <sha256> `
  --dry-run
```

The repository includes a real-digest empty manifest at
`client-patch/patches/ljjc-offline-2.0.4-dryrun.json`. A local build may use
the ignored `client-patch/work/tools/apktool.bat` and
`client-patch/keystore/ljjc-offline.jks` paths after the toolchain has been
created. The build report records the input and output digest and is the
reviewable proof that the source package was not overwritten.

The `ljjc-offline-sdkshim-2.0.4.json` manifest is an explicitly scoped
diagnostic patch for the MSDK initialization crash. It is not a production
offline client: the package still contains the original TPShell integrity
application, and the API28 launch remains blocked there. Do not treat the
shim as permission to remove or bypass that integrity layer.

For a real build, set the keystore password in an environment variable and
provide apktool, zipalign, apksigner, keystore, and alias paths. The pipeline
refuses missing tools, a digest mismatch, unsafe patch paths, or a missing
signing password; it never overwrites the input APK.

#!/usr/bin/env python3
"""Normalize captured runtime config responses into deterministic JSON tables."""

from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path
import re
from typing import Any


def _safe_name(name: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("._")
    return value or "unnamed"


def _iter_payloads(path: Path):
    text = path.read_text(encoding="utf-8")
    try:
        whole = json.loads(text)
    except json.JSONDecodeError:
        whole = None
    if isinstance(whole, dict):
        values = ((whole.get("payload") or {}).get("values") if isinstance(whole.get("payload"), dict) else None)
        if isinstance(values, list):
            for value in values:
                if isinstance(value, str):
                    try:
                        payload = json.loads(value)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(payload, dict):
                        yield 1, payload
            return
        yield 1, whole
        return
    for line_number, line in enumerate(text.splitlines(), 1):
        try:
            outer = json.loads(line)
        except json.JSONDecodeError:
            continue
        values = ((outer.get("payload") or {}).get("values") if isinstance(outer, dict) else None)
        if not isinstance(values, list):
            continue
        for value in values:
            if not isinstance(value, str):
                continue
            try:
                payload = json.loads(value)
            except json.JSONDecodeError:
                continue
            if isinstance(payload, dict):
                yield line_number, payload


def _iter_tables(node: object, name_hint: str | None = None):
    """Find table-shaped dictionaries in both live and offline exports."""
    if not isinstance(node, dict):
        return
    rows = node.get("rows")
    if name_hint and isinstance(rows, list):
        yield name_hint, node
    for key, value in node.items():
        if isinstance(value, dict):
            yield from _iter_tables(value, str(key))


def extract(inputs: list[Path]) -> dict[str, Any]:
    candidates: dict[str, list[dict[str, Any]]] = defaultdict(list)
    source_files: dict[str, set[str]] = defaultdict(set)
    for path in inputs:
        for _line_number, payload in _iter_payloads(path):
            for table_name, table in _iter_tables(payload):
                rows = table.get("rows")
                candidate = {
                    "table": table_name,
                    "count": int(table.get("count", len(rows)) or 0),
                    "rows": rows,
                    "error": table.get("error"),
                    "source": path.name,
                }
                candidates[table_name].append(candidate)
                source_files[table_name].add(path.name)

    tables: dict[str, dict[str, Any]] = {}
    for table_name in sorted(candidates):
        options = candidates[table_name]
        # Prefer the response with the most rows; retain all source names for
        # provenance and keep error-only observations visible in the index.
        selected = max(options, key=lambda item: (len(item["rows"]), item["count"], item["source"]))
        tables[table_name] = {
            "schemaVersion": 1,
            "table": table_name,
            "observedCount": int(selected["count"]),
            "rowCount": len(selected["rows"]),
            "sourceFiles": sorted(source_files[table_name]),
            "rows": selected["rows"],
        }
        if selected.get("error"):
            tables[table_name]["selectedError"] = selected["error"]
    return {
        "schemaVersion": 1,
        "sources": [str(path) for path in inputs],
        "tableCount": len(tables),
        "tables": {
            name: {
                "rowCount": table["rowCount"],
                "observedCount": table["observedCount"],
                "sourceFiles": table["sourceFiles"],
                **({"selectedError": table["selectedError"]} if "selectedError" in table else {}),
            }
            for name, table in tables.items()
        },
    }, tables


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("-o", "--output-dir", type=Path, required=True)
    args = parser.parse_args()
    inputs = [path.resolve() for path in args.inputs]
    missing = [path for path in inputs if not path.is_file()]
    if missing:
        raise SystemExit("missing input: " + ", ".join(map(str, missing)))
    index, tables = extract(inputs)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, table in tables.items():
        output = args.output_dir / f"{_safe_name(name)}.json"
        output.write_text(json.dumps(table, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {len(tables)} config tables to {args.output_dir}")


if __name__ == "__main__":
    main()

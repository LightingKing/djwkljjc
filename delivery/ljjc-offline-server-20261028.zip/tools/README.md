# Development tools

Scripts for APK inspection, Lua/fci extraction, descriptor analysis, and trace
replay live here. Tools should accept explicit input/output paths and must not
modify the original APK in place.

The M1.2 build entry point is `client-patch/build.py`. It is intentionally
kept under `client-patch/` because it owns the patch manifest and generated
APK layout; use `tools/verify-toolchain.ps1` before invoking a real build.

`contract_harness.py` is the M3.8 local contract smoke/replay runner. It
generates deterministic JSONL requests from `contracts/api.yaml`, dispatches
them through `server.core.routes.RouteRegistry`, and emits a machine-readable
report. It never makes network requests. See `contracts/README.md` for the
replay record format.

`audit_descriptors.py` is the M2.6 descriptor audit. It compares message and
enum references in the contract table with the recovered descriptor set and
records malformed/skipped descriptor files without fabricating fields.

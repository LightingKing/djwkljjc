"""Persistent local activity and sign-in compatibility surface.

This module implements a loopback-only test economy.  It accepts JSON and
descriptor-backed protobuf requests, stores claim state in SQLite, and returns
the real response message types used by the client.
"""

from __future__ import annotations

import json
import re
from contextlib import closing
from datetime import datetime, timezone
from typing import Any, Mapping, Optional
from urllib.parse import parse_qs, urlsplit

from google.protobuf import message_factory
from google.protobuf.message import Message


class LocalEvents:
    """Activity/sign-in state owned by a :class:`LocalGame` instance."""

    # Type 7 is the starter gold resource in local-defaults.json.  These are
    # explicit local test rewards; no real payment or remote service is used.
    SIGNIN_REWARD = {"type": 7, "id": 0, "count": 100, "param": 0}
    SIGNIN_GIFT_REWARD = {"type": 7, "id": 0, "count": 250, "param": 0}
    ACTIVITY_REWARD = {"type": 7, "id": 0, "count": 50, "param": 0}
    EVERYDAY_REWARD = {"type": 7, "id": 0, "count": 25, "param": 0}
    CONTINUOUS_REWARD = {"type": 7, "id": 0, "count": 80, "param": 0}

    def __init__(self, game: Any, *, clock=None) -> None:
        self.game = game
        self._lock = game._lock
        self._clock = clock or game._now
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS local_event_state (
                    account_id INTEGER PRIMARY KEY,
                    state_json TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )

    def _now(self) -> int:
        return int(self._clock())

    def _date(self) -> str:
        daily_key = getattr(self.game, "daily_key", None)
        if callable(daily_key):
            try:
                return str(daily_key(self._now()))
            except (TypeError, ValueError):
                pass
        return datetime.fromtimestamp(self._now(), timezone.utc).date().isoformat()

    def _state(self, profile: Mapping[str, Any]) -> dict[str, Any]:
        account_id = int(profile["account_id"])
        with self._lock, closing(self.game._connect()) as connection, connection:
            row = connection.execute(
                "SELECT state_json FROM local_event_state WHERE account_id = ?", (account_id,)
            ).fetchone()
            if row is None:
                state: dict[str, Any] = {
                    "signin_days": 0,
                    "signin_date": "",
                    "signin_gifts": [],
                    "activity_signins": {},
                    "everyday_signins": [],
                    "everyday_date": "",
                    "continuous_days": 0,
                    "continuous_date": "",
                    "continuous_rewards": [],
                    "activity_claims": [],
                    "activity_spin_count": 0,
                    "activity_explore_count": 0,
                    "activity_treasure_count": 0,
                    "activity_dispatch_count": 0,
                    "activity_rebate_claimed": False,
                    "gacha_count": 0,
                    "gacha_score": 0,
                    "gacha_shop_claims": [],
                    "deploy_missions": [],
                    "achievement_claims": [],
                    "gift_codes": [],
                    "condition_reward_got": False,
                    "subscribed": False,
                }
                # Another local game object may initialize the same account at
                # the same time.  INSERT OR IGNORE makes initialization
                # idempotent; reload the winning row below so the caller never
                # returns an uncommitted shadow state.
                connection.execute(
                    "INSERT OR IGNORE INTO local_event_state(account_id,state_json,updated_at) VALUES (?,?,?)",
                    (account_id, json.dumps(state, separators=(",", ":")), self._now()),
                )
                row = connection.execute(
                    "SELECT state_json FROM local_event_state WHERE account_id = ?", (account_id,)
                ).fetchone()
                if row is None:
                    return state
            try:
                state = json.loads(row["state_json"] or "{}")
            except (TypeError, ValueError):
                state = {}
            if not isinstance(state, dict):
                state = {}
            defaults = {
                "signin_days": 0,
                "signin_date": "",
                "signin_gifts": [],
                "activity_signins": {},
                "everyday_signins": [],
                "everyday_date": "",
                "continuous_days": 0,
                "continuous_date": "",
                "continuous_rewards": [],
                "activity_claims": [],
                "activity_spin_count": 0,
                "activity_explore_count": 0,
                "activity_treasure_count": 0,
                "activity_dispatch_count": 0,
                "activity_rebate_claimed": False,
                "gacha_count": 0,
                "gacha_score": 0,
                "gacha_shop_claims": [],
                "deploy_missions": [],
                "achievement_claims": [],
                "gift_codes": [],
                "condition_reward_got": False,
                "subscribed": False,
            }
            for key, value in defaults.items():
                state.setdefault(key, value)
            return state

    def _save(self, profile: Mapping[str, Any], state: Mapping[str, Any]) -> None:
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                "UPDATE local_event_state SET state_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(dict(state), separators=(",", ":")), self._now(), int(profile["account_id"])),
            )

    @staticmethod
    def _body_object(body: Any) -> dict[str, Any]:
        if body is None:
            return {}
        raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
        if not raw:
            return {}
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return dict(value) if isinstance(value, Mapping) else {}

    def _request(self, body: Any, type_name: str) -> Message | None:
        raw = body.encode("utf-8") if isinstance(body, str) else bytes(body or b"")
        if not raw:
            return None
        try:
            cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName(type_name))
            message = cls()
            message.ParseFromString(raw)
            return message
        except Exception:
            return None

    def _resource(self, value: Mapping[str, Any], *, delta: Optional[int] = None):
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("STResource"))
        result = cls()
        result.type = int(value.get("type", 0))
        result.id = int(value.get("id", 0))
        result.count = int(value.get("count", 0))
        result.param = int(value.get("param", 0))
        if delta is not None:
            result.count_delta = int(delta)
        return result

    def _dynamic(self, value: Mapping[str, Any], *, delta: int):
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("STResourceDynamic"))
        result = cls()
        result.base_res.CopyFrom(self._resource(value, delta=delta))
        return result

    def _grant(self, profile: Mapping[str, Any], reward: Mapping[str, Any]):
        # Callers may hold the login snapshot while several claims happen in
        # one session.  Read the latest row before applying each delta so a
        # second claim cannot overwrite the first one's reward.
        resources: list[dict[str, Any]] = []
        with self._lock, closing(self.game._connect()) as connection:
            row = connection.execute(
                "SELECT resources_json FROM game_profiles WHERE account_id = ?",
                (int(profile["account_id"]),),
            ).fetchone()
        if row is not None:
            try:
                current = json.loads(row["resources_json"] or "[]")
                if isinstance(current, list):
                    resources = [dict(x) for x in current if isinstance(x, Mapping)]
            except (TypeError, ValueError):
                resources = []
        if not resources:
            resources = [dict(x) for x in profile.get("resources", []) if isinstance(x, Mapping)]
        rtype, rid = int(reward.get("type", 0)), int(reward.get("id", 0))
        amount = int(reward.get("count", 0))
        target = next(
            (x for x in resources if int(x.get("type", 0)) == rtype and int(x.get("id", 0)) == rid),
            None,
        )
        if target is None:
            target = {"type": rtype, "id": rid, "count": 0, "param": int(reward.get("param", 0))}
            resources.append(target)
        target["count"] = int(target.get("count", 0)) + amount
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                "UPDATE game_profiles SET resources_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(resources, separators=(",", ":")), self._now(), int(profile["account_id"])),
            )
        return self._dynamic(reward, delta=amount)

    def _signin(self, method: str, body: Any, profile: Mapping[str, Any]):
        if method not in {"GET", "POST"}:
            return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
        state = self._state(profile)
        today = self._date()
        reward = None
        if method == "POST" and state.get("signin_date") != today:
            state["signin_days"] = max(0, int(state.get("signin_days", 0))) + 1
            state["signin_date"] = today
            reward = self._grant(profile, self.SIGNIN_REWARD)
            self._save(profile, state)
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiSignin.result"))
        result = cls()
        result.signed = bool(state.get("signin_date") == today)
        result.days = int(state.get("signin_days", 0))
        result.gift_got.extend(int(x) for x in state.get("signin_gifts", []))
        if reward is not None:
            result.res_change.add().CopyFrom(reward)
        return 200, result

    def _signin_gift(self, method: str, body: Any, profile: Mapping[str, Any]):
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        request = self._body_object(body)
        msg = self._request(body, "ApiSigninGift")
        day = int(request.get("days", request.get("day", 0)) or (getattr(msg, "days", 0) if msg else 0))
        state = self._state(profile)
        if day <= 0:
            day = int(state.get("signin_days", 0))
        gifts = {int(x) for x in state.get("signin_gifts", [])}
        reward = None
        if day > 0 and day <= int(state.get("signin_days", 0)) and day not in gifts:
            gifts.add(day)
            state["signin_gifts"] = sorted(gifts)
            reward = self._grant(profile, self.SIGNIN_GIFT_REWARD)
            self._save(profile, state)
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiSigninGift.result"))
        result = cls()
        if reward is not None:
            result.res_change.add().CopyFrom(reward)
        return 200, result

    def _activity_signin(self, method: str, path: str, profile: Mapping[str, Any]):
        parts = path.rstrip("/").split("/")
        activity_id = int(parts[-1]) if parts and parts[-1].isdigit() else 1
        state = self._state(profile)
        records = dict(state.get("activity_signins", {}))
        record = dict(records.get(str(activity_id), {"day": 0, "date": ""}))
        today = self._date()
        reward = None
        if method == "POST" and record.get("date") != today:
            record["day"] = int(record.get("day", 0)) + 1
            record["date"] = today
            records[str(activity_id)] = record
            reward = self._grant(profile, self.ACTIVITY_REWARD)
            state["activity_signins"] = records
            self._save(profile, state)
        elif method != "GET":
            return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
        if method == "GET":
            cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiActivitySignin.get"))
            result = cls()
            result.day = int(record.get("day", 0))
            result.activity_id = activity_id
            result.signed = bool(record.get("date") == today)
            return 200, result
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiActivitySignin.post"))
        result = cls()
        if reward is not None:
            result.res_change.add().CopyFrom(reward)
        return 200, result

    def _everyday_signin(self, method: str, profile: Mapping[str, Any]):
        if method not in {"GET", "POST"}:
            return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
        state = self._state(profile)
        days = sorted({int(x) for x in state.get("everyday_signins", [])})
        reward = None
        if method == "POST" and state.get("everyday_date") != self._date():
            days.append((days[-1] + 1) if days else 1)
            state["everyday_signins"] = sorted(set(days))
            state["everyday_date"] = self._date()
            reward = self._grant(profile, self.EVERYDAY_REWARD)
            self._save(profile, state)
        if method == "GET":
            cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiEveryDaySignin.get"))
            result = cls(); result.signined_days.extend(days)
            return 200, result
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiEveryDaySignin.post"))
        result = cls(); result.signined_days.extend(days)
        if reward is not None:
            result.res_change.add().CopyFrom(reward)
        return 200, result

    def _continuous(self, method: str, path: str, body: Any, profile: Mapping[str, Any]):
        state = self._state(profile)
        today = self._date()
        if state.get("continuous_date") != today:
            state["continuous_days"] = int(state.get("continuous_days", 0)) + 1 if state.get("continuous_date") else 1
            state["continuous_date"] = today
            self._save(profile, state)
        lower = path.rstrip("/").lower()
        if lower.endswith("interruptprompt"):
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiContinuousLoginPrompt.result"))
            return 200, cls(is_interrupt=False)
        if lower.endswith("receiveprize"):
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            request = self._body_object(body)
            msg = self._request(body, "ApiContinuousLoginReceive")
            day = int(request.get("days", 0) or (getattr(msg, "days", 0) if msg else 0))
            if day <= 0:
                day = int(state.get("continuous_days", 0))
            rewards = {int(x) for x in state.get("continuous_rewards", [])}
            reward = None
            if day > 0 and day <= int(state.get("continuous_days", 0)) and day not in rewards:
                rewards.add(day); state["continuous_rewards"] = sorted(rewards)
                reward = self._grant(profile, self.CONTINUOUS_REWARD); self._save(profile, state)
            cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiContinuousLoginReceive.result"))
            result = cls()
            if reward is not None:
                result.res_change.add().CopyFrom(reward)
            return 200, result
        if method != "GET":
            return 405, {"error": "method_not_allowed", "message": "GET required"}
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName("ApiContinuousLogin.result"))
        result = cls(cur_continuous_login=int(state.get("continuous_days", 0)), max_continuous_login=7)
        result.receive_prize_record.extend(int(x) for x in state.get("continuous_rewards", []))
        return 200, result

    def _subscribe(self, method: str, body: Any, profile: Mapping[str, Any]):
        """Handle the local ``Subscribe`` preference without contacting SDKs.

        The retired client sends ``ApiSubscribe.op_type`` to toggle platform
        subscription prompts.  The original platform callback is unavailable
        offline, so the preference is persisted per account and exposed using
        the recovered response descriptor.  Local semantics are deliberately
        small and deterministic: 0 queries, 1 subscribes, and 2 unsubscribes.
        """
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        request = self._body_object(body)
        message = self._request(body, "ApiSubscribe")
        raw_op = request.get("opType", request.get("op_type"))
        if raw_op is None and message is not None:
            raw_op = getattr(message, "op_type", 0)
        try:
            op_type = int(raw_op or 0)
        except (TypeError, ValueError):
            return 400, {"error": "invalid_op_type", "message": "opType must be an integer"}

        state = self._state(profile)
        if op_type == 1:
            state["subscribed"] = True
        elif op_type == 2:
            state["subscribed"] = False
        elif op_type != 0:
            return 400, {"error": "invalid_op_type", "message": "opType must be 0, 1, or 2"}
        if op_type in {1, 2}:
            self._save(profile, state)

        result = self._message("ApiSubscribe.result")
        if result is None:
            return None
        result.errcode = 0
        result.is_subscribed = bool(state.get("subscribed", False))
        return 200, result

    def _message(self, full_name: str):
        """Construct an optional descriptor-backed response message."""
        try:
            cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName(full_name))
        except Exception:
            return None
        return cls()

    def _claim_activity_reward(self, profile: Mapping[str, Any], state: dict[str, Any], key: str,
                               reward: Mapping[str, Any] | None = None):
        """Grant a local activity reward once and return its dynamic delta."""
        claims = {str(value) for value in state.get("activity_claims", [])}
        if key in claims:
            return None
        claims.add(key)
        state["activity_claims"] = sorted(claims)
        return self._grant(profile, reward or self.ACTIVITY_REWARD)

    def _spend_gold(self, profile: Mapping[str, Any], amount: int = 1000):
        """Spend local starter gold through the shared economy balance code."""
        economy = getattr(self.game, "economy", None)
        if economy is None:
            return False, [], "economy_unavailable"
        return economy._change_resources(
            profile,
            [{"type": 7, "id": 0, "param": 0, "count": -abs(int(amount))}],
        )

    def _activity_claim_api(self, method: str, path: str, body: Any, profile: Mapping[str, Any]):
        """Handle the descriptor-backed activity mini-games in local mode.

        The retired service exposed many small endpoints.  Their original
        catalog is unavailable, so each local endpoint is deterministic and
        uses the real response descriptor when one is present.  Rewards are
        local gold and every claim is persisted in ``local_event_state``.
        """
        action = re.sub(r"[^a-z0-9]", "", (urlsplit(path or "").path or "").lower())
        request = self._body_object(body)
        state = self._state(profile)
        now = self._now()

        # Purple-pairs / puzzle activity.
        if "purblepairscreate" in action or "purplepairscreate" in action:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            result = self._message("ApiActivityPurblePairsCreate.result")
            if result is None:
                return None
            result.data.extend([1, 2, 3, 4])
            result.can_reward = True
            return 200, result
        if "purblepairsbalance" in action or "purplepairsbalance" in action:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            reward = self._claim_activity_reward(profile, state, "purple-pairs")
            self._save(profile, state)
            result = self._message("ApiActivityPurblePairsBalance.result")
            if result is None:
                return None
            if reward is not None:
                result.res_change.add().CopyFrom(reward)
            return 200, result

        # Gacha is local draw bookkeeping.  It never calls a payment provider.
        if "gachainfo" in action:
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            result = self._message("ApiGachaInfo.get")
            if result is None:
                return None
            info = result.gacha_info.add()
            info.id = int(request.get("id", 1) or 1)
            info.gacha_count_today = int(state.get("gacha_count", 0))
            info.next_get_purple_count = max(0, 10 - int(state.get("gacha_count", 0)) % 10)
            info.next_free_gacha_time = 0
            return 200, result
        if "gachatrade" in action:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            result = self._message("ApiGachaTrade.result")
            if result is None:
                return None
            ok, changes, error = self._spend_gold(profile, 1000)
            if not ok:
                return 409, {"error": error or "insufficient_resource"}
            state["gacha_count"] = int(state.get("gacha_count", 0)) + max(1, int(request.get("count", 1) or 1))
            state["gacha_score"] = int(state.get("gacha_score", 0)) + 1
            self._save(profile, state)
            result.gacha_count_today = int(state["gacha_count"])
            result.add_gacha_score = 1
            result.next_get_purple_count = max(0, 10 - state["gacha_count"] % 10)
            result.info.trade_id = int(state["gacha_count"])
            result.info.id = int(request.get("id", 1) or 1)
            result.info.count = 1
            # Keep the shared actor collection in sync so a draw is visible
            # in the next login bootstrap even though this activity handler
            # owns the wire response before LocalSystems.
            systems = getattr(self.game, "systems", None)
            if systems is not None:
                systems_state = systems._state(profile)
                actor_id = 1002 + (int(state["gacha_count"]) % 3)
                systems_state.setdefault("actors", {}).setdefault(
                    str(actor_id), {"id": actor_id, "level": 1, "star": 1, "exp": 0}
                )
                systems_state.setdefault("gacha_records", []).append(
                    {"id": actor_id, "quality": 1, "time": now}
                )
                systems._save(profile, systems_state)
                record = result.actor_record.add()
                record.id = actor_id; record.quality = 1; record.time_order = int(state["gacha_count"])
            for change in changes:
                result.info.res_change.add().CopyFrom(self._dynamic(change, delta=int(change.get("countDelta", 0))))
            return 200, result
        if "gachashoptrade" in action:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            result = self._message("ApiGachaShopTrade.post")
            if result is None:
                return None
            good_id = int(request.get("goodId", request.get("good_id", 1)) or 1)
            ok, spend_changes, error = self._spend_gold(profile, 1000)
            if not ok:
                return 409, {"error": error or "insufficient_resource"}
            reward = self._claim_activity_reward(profile, state, f"gacha-shop:{good_id}",
                                                  {"type": 11, "id": 20001, "count": 1, "param": 0})
            self._save(profile, state)
            for change in spend_changes:
                result.res_change.add().CopyFrom(self._dynamic(change, delta=int(change.get("countDelta", 0))))
            if reward is not None:
                result.res_change.add().CopyFrom(reward)
            return 200, result
        if "gachashop" in action:
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            result = self._message("ApiGachaShop.get")
            if result is None:
                return None
            result.next_refresh_time = now + 86400
            good = result.goods.add(); good.good_id = 1; good.cost.type = 7; good.cost.count = 1000
            good.good.type = 11; good.good.id = 20001; good.good.count = 1
            return 200, result
        if "gachapoolverify" in action:
            if method != "GET" and method != "POST":
                return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
            result = self._message("ApiGachaPoolVerify.result")
            if result is None:
                return None
            result.cur_server_time = now
            return 200, result

        if "activitybuffshop" in action:
            if method == "GET":
                result = self._message("ApiActivityBuffShop.get")
                if result is None:
                    return None
                entry = result.shop_info.add(); entry.goods_id = 1; entry.grade = 1
                return 200, result
            if method == "POST":
                result = self._message("ApiActivityBuffShop.post")
                if result is None:
                    return None
                good_id = int(request.get("goodsId", request.get("goods_id", 1)) or 1)
                ok, spend_changes, error = self._spend_gold(profile, 1000)
                if not ok:
                    return 409, {"error": error or "insufficient_resource"}
                reward = self._claim_activity_reward(profile, state, f"activity-buff-shop:{good_id}",
                                                      {"type": 11, "id": 20001, "count": 1, "param": 0})
                self._save(profile, state)
                for change in spend_changes:
                    result.res_change.add().CopyFrom(self._dynamic(change, delta=int(change.get("countDelta", 0))))
                if reward is not None:
                    result.res_change.add().CopyFrom(reward)
                return 200, result
            return 405, {"error": "method_not_allowed", "message": "GET or POST required"}

        # Deploy mission activity.  A fresh local guest sees one immediately
        # claimable mission, with rewards persisted by mission id.
        if "deploymissionsummary" in action:
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            result = self._message("ApiDeployMissionSummary.get")
            if result is None:
                return None
            result.accomplish = 0
            return 200, result
        if "deploymission" in action:
            if action.endswith("deploymission") or "deploymissionget" in action:
                if method != "GET":
                    return 405, {"error": "method_not_allowed", "message": "GET required"}
                result = self._message("ApiDeployMission.get")
                if result is None:
                    return None
                info = result.mission_info.add(); info.id = 1; info.status = 0; info.start_timestamp = now
                info.end_timestamp = now + 3600
                result.accomplish_num = 0
                return 200, result
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            if "reward" in action:
                type_name = "ApiDeployMissionReward.result"
            elif "speedup" in action:
                type_name = "ApiDeployMissionSpeedUp.result"
            elif "discard" in action:
                type_name = "ApiDeployMissionDiscard.result"
            else:
                type_name = "ApiDeployMissionAttend.post"
            result = self._message(type_name)
            if result is None:
                return None
            mission_id = int(request.get("id", request.get("missionId", 1)) or 1)
            reward = self._claim_activity_reward(profile, state, f"deploy:{mission_id}",
                                                  {"type": 7, "id": 0, "count": 100, "param": 0})
            self._save(profile, state)
            if hasattr(result, "res_change") and reward is not None:
                result.res_change.add().CopyFrom(reward)
            for field in ("attend_result", "reward_result", "speedup_result", "discard_result"):
                if field in result.DESCRIPTOR.fields_by_name:
                    setattr(result, field, True)
            return 200, result

        # Condition reward / achievement boxes.
        if "conditionreward" in action:
            if method == "GET":
                result = self._message("ApiConditionReward.get")
                if result is None:
                    return None
                result.has_reward_qualification = True
                result.is_reward_got = bool(state.get("condition_reward_got", False))
                result.manual_box_reward.type = 7; result.manual_box_reward.count = 100
                return 200, result
            if method == "POST":
                result = self._message("ApiConditionReward.post")
                if result is None:
                    return None
                reward = self._claim_activity_reward(profile, state, "condition-reward",
                                                      {"type": 7, "id": 0, "count": 100, "param": 0})
                state["condition_reward_got"] = True; self._save(profile, state)
                if reward is not None:
                    result.manual_box_res_change.add().CopyFrom(reward)
                return 200, result
            return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
        if "achievementsummary" in action:
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            result = self._message("ApiAchievementSummary.get")
            return (200, result) if result is not None else None
        if "achievementreward" in action:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            result = self._message("ApiAchievementReward.result")
            if result is None:
                return None
            reward = self._claim_activity_reward(profile, state, "achievement-reward",
                                                  {"type": 7, "id": 0, "count": 100, "param": 0})
            self._save(profile, state)
            if reward is not None:
                result.res_change.add().CopyFrom(reward)
            return 200, result

        # Gift code is local-only and accepts a small explicit code set.
        if "giftcode" in action or "getgift" in action:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            code = str(request.get("code", "")).strip().upper()
            result = self._message("ApiGiftCode.result")
            if result is None:
                return None
            if code in {"LOCAL-START", "LOCAL-TEST", "LJJC-LOCAL"} and code not in state.get("gift_codes", []):
                reward = self._claim_activity_reward(profile, state, f"gift:{code}",
                                                      {"type": 7, "id": 0, "count": 500, "param": 0})
                state["gift_codes"] = sorted(set(state.get("gift_codes", [])) | {code}); self._save(profile, state)
                if reward is not None and hasattr(result.gift_code_info, "res_change"):
                    result.gift_code_info.res_change.add().CopyFrom(reward)
            return 200, result

        # The APK contains several optional activity panels whose payload
        # descriptors are not present in the recovered descriptor set.  Keep
        # their local endpoints reachable with schema-shaped empty JSON.  This
        # allows the client to close those panels cleanly instead of treating
        # the retired server as unreachable, while all real claims above stay
        # typed and persisted.
        ignored_basic = ("activitysignin", "everydaysignin", "continuouslogin", "signin")
        optional_activity = (
            "activitytask", "activityexplore", "turntable", "digtreasure",
            "activitydispatch", "dispatch", "rechargerebate", "loginreward",
            "activitylogin", "activityrebate", "activitygroup", "activityedu",
        )
        if not any(token in action for token in ignored_basic) and any(token in action for token in optional_activity):
            if method not in {"GET", "POST"}:
                return 405, {"error": "method_not_allowed", "message": "GET or POST required"}
            kind = next((token for token in optional_activity if token in action), "activity")
            ident = str(request.get("id", request.get("activityId", request.get("subActivityId", 1))) or 1)
            if method == "POST":
                reward = self._claim_activity_reward(profile, state, f"optional:{kind}:{ident}",
                                                      {"type": 7, "id": 0, "count": 50, "param": 0})
                self._save(profile, state)
                changes = []
                if reward is not None:
                    changes.append({"type": 7, "id": 0, "count": 50, "countDelta": 50, "param": 0})
                return 200, {"ok": True, "claimed": reward is not None, "reward": changes, "resChange": changes}
            if "task" in action:
                return 200, {"tasks": [{"id": int(ident), "progress": 1, "maxProgress": 1, "rewardGot": f"optional:task:{ident}" in state.get("activity_claims", [])}], "reward": [], "received": []}
            if "dispatch" in action:
                return 200, {"tasks": [], "missionInfo": [], "accomplishNum": 0}
            if "turntable" in action:
                return 200, {"count": 0, "canReward": False, "reward": []}
            if "digtreasure" in action:
                return 200, {"grid": [], "layer": 0, "reward": []}
            if "rebate" in action:
                return 200, {"reward": [], "got": False}
            return 200, {}
        return None

    def _activity(self, method: str, path: str = ""):
        if method not in {"GET", "HEAD"}:
            return 405, {"error": "method_not_allowed", "message": "GET required"}
        path_name = (urlsplit(path or "").path or "").rstrip("/").lower()
        response_type = "ApiActivity.result"
        if path_name.endswith("/activity-preopen"):
            response_type = "ApiActivityPreOpen.result"
        elif path_name.endswith("/activity-open"):
            response_type = "ApiActivityOpen.result"
        cls = message_factory.GetMessageClass(self.game._pool.FindMessageTypeByName(response_type))
        now = self._now()
        # ``ApiActivity.result`` carries one activity entry.  The client uses
        # the activity type to decide which local panel to open; type 1 is a
        # retired dungeon activity and leaves the city entry inert.  Expose
        # the implemented local shop by default, while allowing diagnostics
        # and older clients to request the compatible sign-in/continuous-login
        # entries with ``?type=46``/``?type=25`` or a numeric path suffix.
        activity_type = 12  # ActivityType_Shop
        activity_id = 1
        schedule = getattr(self.game, "activity_schedule", None)
        schedule_snapshot = None
        if schedule is not None:
            try:
                schedule_snapshot = schedule.snapshot(now)
                active = schedule_snapshot.get("active", [])
                if active:
                    selected = active[0]
                    activity_type = int(selected.get("activityType", activity_type))
                    activity_id = int(selected.get("activityId", 1) or 1)
            except (TypeError, ValueError, AttributeError):
                # The city entry remains available if an optional schedule
                # file is malformed or an older test double lacks snapshot().
                activity_type, activity_id = 12, 1
        parsed = urlsplit(path or "")
        suffix = parsed.path.rstrip("/").rsplit("/", 1)[-1]
        query = parse_qs(parsed.query)
        requested = query.get("type", query.get("activityType", [suffix]))
        try:
            if requested and str(requested[0]).isdigit():
                activity_type = int(requested[0])
        except (TypeError, ValueError):
            activity_type = 12
        if schedule_snapshot is not None:
            active = schedule_snapshot.get("active", [])
            if not active:
                return 200, cls()
            if requested and str(requested[0]).isdigit():
                matched = None
                for phase in active:
                    try:
                        if int(phase.get("activityType", phase.get("type", 0))) == activity_type:
                            matched = phase
                            break
                    except (TypeError, ValueError):
                        continue
                if matched is None:
                    return 200, cls()
                try:
                    activity_id = int(matched.get("activityId", activity_id) or activity_id)
                except (TypeError, ValueError):
                    pass
        category = 4 if activity_type == 12 else 1
        activity = cls().result
        activity.type = activity_type; activity.activity_id = activity_id
        activity.time_preheat = "local"; activity.time_start = "local"; activity.time_end = "local"
        activity.timestamp_preheat = now; activity.timestamp_start = now; activity.timestamp_end = now + 86400 * 365
        selected_phase = None
        if schedule_snapshot is not None:
            for phase in schedule_snapshot.get("active", []):
                try:
                    if int(phase.get("activityType", phase.get("type", 0))) == activity_type:
                        selected_phase = phase
                        break
                except (TypeError, ValueError):
                    continue
            if selected_phase is not None:
                try:
                    day_start = int(selected_phase.get("dayStart", schedule_snapshot.get("cycleDay", 0)))
                    day_end = int(selected_phase.get("dayEnd", day_start + 1))
                    cycle_start = now - int(schedule_snapshot.get("cycleDay", 0)) * 86400
                    activity.timestamp_preheat = cycle_start + day_start * 86400
                    activity.timestamp_start = activity.timestamp_preheat
                    activity.timestamp_end = cycle_start + day_end * 86400
                except (TypeError, ValueError):
                    pass
        activity.forever = selected_phase is None or bool(selected_phase.get("forever", False))
        activity.category = category
        result = cls(); result.result.CopyFrom(activity)
        return 200, result

    def _handle_http_unlocked(self, method: str, path: str, body: Any, profile: Mapping[str, Any]):
        """Return ``(status, payload)`` for a route, or ``None``."""
        raw = (path or "").split("?", 1)[0].rstrip("/") or "/"
        route = raw[4:] if raw.startswith("/fci") else raw
        lower = route.lower(); method = method.upper()
        if lower in {"/activity", "/activity-preopen", "/activity-open"} or lower.startswith("/activity/"):
            return self._activity(method, path)
        activity_api = self._activity_claim_api(method, path, body, profile)
        if activity_api is not None:
            return activity_api
        if lower == "/signin": return self._signin(method, body, profile)
        if lower == "/signin/gift": return self._signin_gift(method, body, profile)
        if lower == "/activity-signin" or lower.startswith("/activity-signin/"):
            return self._activity_signin(method, route, profile)
        if lower == "/everyday-signin" or lower.startswith("/everyday-signin/"):
            return self._everyday_signin(method, profile)
        if lower.startswith("/continuouslogin"):
            return self._continuous(method, route, body, profile)
        if lower == "/subscribe":
            return self._subscribe(method, body, profile)
        return None


    def handle_http(self, method: str, path: str, body: Any, profile: Mapping[str, Any]):
        """Serialize claim and reward mutations for a local account."""
        with self._lock:
            return self._handle_http_unlocked(method, path, body, profile)



__all__ = ["LocalEvents"]

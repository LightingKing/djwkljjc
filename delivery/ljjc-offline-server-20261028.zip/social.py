"""Deterministic local social, bot, async-PVP and leaderboard compatibility.

The retired service is not contacted.  Every bot and message is generated
from a fixed seed and every player-specific mutation is persisted in the
existing game SQLite database.
"""

from __future__ import annotations

import json
import random
from contextlib import closing
from datetime import datetime, timezone
from typing import Any, Mapping, Optional
from urllib.parse import urlsplit


Body = bytes | bytearray | str | None
Response = tuple[int, Any]


def _json(body: Body) -> dict[str, Any]:
    if body is None:
        return {}
    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return dict(value) if isinstance(value, Mapping) else {}


class LocalBotPool:
    """Stable bot records shared by friend, assist, PVP and rank screens."""

    NAMES = ("御坂训练员", "黑雪姬", "桐人练习生", "亚丝娜助手", "司波机器人", "深雪陪练", "逢坂大河", "夏娜演示员")

    def __init__(self, *, seed: int = 20261028, count: int = 24) -> None:
        rng = random.Random(seed)
        self._bots: list[dict[str, Any]] = []
        for index in range(1, count + 1):
            level = 8 + rng.randrange(1, 45)
            score = 850 + rng.randrange(0, 700)
            actors = [1001 + rng.randrange(0, 8), 1001 + rng.randrange(0, 8), 1001 + rng.randrange(0, 8)]
            self._bots.append({
                "playerId": f"local-bot-{index:03d}",
                "name": self.NAMES[(index - 1) % len(self.NAMES)] + str(index),
                "level": level,
                "avatar": 1001 + (index % 6),
                "score": score,
                "actors": actors,
                "online": bool(index % 3),
            })

    def all(self) -> list[dict[str, Any]]:
        return [dict(bot, actors=list(bot["actors"])) for bot in self._bots]

    def get(self, player_id: str) -> dict[str, Any] | None:
        for bot in self._bots:
            if str(bot["playerId"]) == str(player_id):
                return dict(bot, actors=list(bot["actors"]))
        return None

    def pick(self, account_id: int, *, offset: int = 0) -> dict[str, Any]:
        index = (int(account_id) + int(offset)) % len(self._bots)
        return dict(self._bots[index], actors=list(self._bots[index]["actors"]))


class LocalSocial:
    """Persistent local social surface owned by a :class:`LocalGame`."""

    def __init__(self, game: Any, *, clock=None, bots: LocalBotPool | None = None) -> None:
        self.game = game
        self._lock = game._lock
        self._clock = clock or game._now
        self.bots = bots or LocalBotPool()
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS local_social_state (
                    account_id INTEGER PRIMARY KEY,
                    state_json TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )

    def _now(self) -> int:
        return int(self._clock())

    @staticmethod
    def _default_state() -> dict[str, Any]:
        return {
            "friends": ["local-bot-001", "local-bot-002"],
            "blocked": [],
            "likes": 0,
            "messages": [],
            "pvp": {"rating": 1000, "wins": 0, "losses": 0, "matches": []},
        }

    def _state(self, profile: Mapping[str, Any]) -> dict[str, Any]:
        account_id = int(profile["account_id"])
        with self._lock, closing(self.game._connect()) as connection, connection:
            row = connection.execute("SELECT state_json FROM local_social_state WHERE account_id = ?", (account_id,)).fetchone()
            if row is None:
                state = self._default_state()
                connection.execute(
                    "INSERT INTO local_social_state(account_id,state_json,updated_at) VALUES (?,?,?)",
                    (account_id, json.dumps(state, separators=(",", ":")), self._now()),
                )
                return state
            try:
                value = json.loads(row["state_json"] or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                value = {}
            state = value if isinstance(value, dict) else {}
            defaults = self._default_state()
            for key, default in defaults.items():
                if key not in state:
                    state[key] = default
            state.setdefault("pvp", {}).setdefault("rating", 1000)
            state["pvp"].setdefault("wins", 0); state["pvp"].setdefault("losses", 0); state["pvp"].setdefault("matches", [])
            return state

    def _save(self, profile: Mapping[str, Any], state: Mapping[str, Any]) -> None:
        with self._lock, closing(self.game._connect()) as connection, connection:
            connection.execute(
                "UPDATE local_social_state SET state_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(dict(state), ensure_ascii=False, separators=(",", ":")), self._now(), int(profile["account_id"])),
            )

    @staticmethod
    def _route(path: str) -> str:
        return urlsplit(path or "").path.rstrip("/").casefold() or "/"

    def _friend(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        # Preserve the historical protobuf seams handled by LocalSystems;
        # the JSON social surface uses the explicit friend/ routes below.
        if route in {"/fci/friendlist", "/fci/relation/applyfriend"}:
            return None
        if not any(token in route for token in ("/fci/friend/", "/fci/socialfriend", "/fci/relation/friend/")) and route not in {"/fci/friend", "/fci/relation/friend"}:
            return None
        if not any(token in route for token in ("list", "recommend", "apply", "recall", "delete", "block", "like")) and route not in {"/fci/friend", "/fci/relation/friend"}:
            return None
        friends = [str(item) for item in state.setdefault("friends", [])]
        payload = _json(body)
        if method == "GET" and ("list" in route or "recommend" in route or route in {"/fci/friend", "/fci/relation/friend"}):
            ids = friends if "recommend" not in route else [bot["playerId"] for bot in self.bots.all()]
            rows = []
            for player_id in ids:
                bot = self.bots.get(player_id)
                if bot is not None:
                    bot["isFriend"] = player_id in friends
                    rows.append(bot)
            return 200, {"friends": rows, "result": rows, "recommend": rows if "recommend" in route else []}
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        target = str(payload.get("playerId", payload.get("player_id", payload.get("targetId", "")))).strip()
        if not target:
            target = self.bots.pick(int(profile["account_id"]))["playerId"]
        bot = self.bots.get(target)
        if bot is None:
            return 404, {"error": "local_bot_not_found"}
        if "recall" in route or "delete" in route:
            state["friends"] = [value for value in friends if value != target]
            self._save(profile, state)
            return 200, {"ok": True, "playerId": target, "removed": True}
        if "block" in route:
            blocked = set(str(item) for item in state.setdefault("blocked", [])); blocked.add(target)
            state["blocked"] = sorted(blocked); state["friends"] = [value for value in friends if value != target]
            self._save(profile, state)
            return 200, {"ok": True, "playerId": target, "blocked": True}
        if "like" in route:
            state["likes"] = int(state.get("likes", 0)) + 1
            self._save(profile, state)
            return 200, {"ok": True, "playerId": target, "likeCount": state["likes"]}
        if target not in friends:
            friends.append(target); state["friends"] = friends
            self._save(profile, state)
        return 200, {"ok": True, "playerId": target, "friend": bot, "isFriend": True}

    def _assist(self, method: str, route: str, profile: Mapping[str, Any]) -> Optional[Response]:
        if not any(token in route for token in ("assistant", "assistants", "dungeonassist")):
            return None
        if method != "GET":
            return 405, {"error": "method_not_allowed", "message": "GET required"}
        state = self._state(profile)
        rows = [self.bots.get(item) for item in state.get("friends", [])]
        rows = [row for row in rows if row is not None]
        return 200, {"assistants": rows, "result": rows}

    def _chat(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        if not any(token in route for token in ("/chat", "/danmu", "/player-message", "/recent-contact")):
            return None
        messages = state.setdefault("messages", [])
        if method == "GET":
            if "recent-contact" in route:
                contacts = [self.bots.get(item) for item in state.get("friends", [])]
                return 200, {"contacts": [item for item in contacts if item is not None]}
            return 200, {"messages": messages[-50:], "danmu": messages[-50:]}
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        payload = _json(body)
        text = str(payload.get("message", payload.get("text", payload.get("content", "")))).strip()
        if not text:
            return 400, {"error": "empty_message"}
        if len(text) > 128:
            return 400, {"error": "message_too_long"}
        message = {"id": len(messages) + 1, "playerId": str(profile.get("player_id", "local")), "name": str(profile.get("name", "Local Guest")), "text": text, "createdAt": self._now()}
        messages.append(message); del messages[:-100]
        self._save(profile, state)
        return 200, {"ok": True, "message": message, "messages": messages[-50:]}

    def _pvp(self, method: str, route: str, body: Body, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        if route in {"/fci/asyncpvprecord", "/fci/asyncpvpmatch", "/fci/match_mirror"}:
            return None
        if not any(token in route for token in ("/fci/asyncpvp/", "/fci/match-mirror/", "/fci/initasyncpvprobot")):
            return None
        pvp = state.setdefault("pvp", {"rating": 1000, "wins": 0, "losses": 0, "matches": []})
        if method == "GET" and any(token in route for token in ("record", "info", "rank")):
            return 200, {"rating": int(pvp.get("rating", 1000)), "wins": int(pvp.get("wins", 0)), "losses": int(pvp.get("losses", 0)), "matches": list(pvp.get("matches", []))[-20:]}
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "POST required"}
        payload = _json(body)
        opponent = self.bots.pick(int(profile["account_id"]), offset=len(pvp.get("matches", [])))
        if any(token in route for token in ("battle", "settle", "result")):
            win = bool(payload.get("win", payload.get("isWin", True)))
            delta = 25 if win else -20
            pvp["rating"] = max(0, int(pvp.get("rating", 1000)) + delta)
            pvp["wins" if win else "losses"] = int(pvp.get("wins" if win else "losses", 0)) + 1
            match = {"opponent": opponent["playerId"], "win": win, "delta": delta, "rating": pvp["rating"], "time": self._now()}
            pvp.setdefault("matches", []).append(match); del pvp["matches"][:-50]
            self._save(profile, state)
            return 200, {"ok": True, "result": match, "rating": pvp["rating"]}
        return 200, {"ok": True, "match": {"opponent": opponent, "ticket": len(pvp.get("matches", [])) + 1}, "rating": pvp["rating"]}

    def _rank(self, method: str, route: str, profile: Mapping[str, Any], state: dict[str, Any]) -> Optional[Response]:
        if not any(token in route for token in ("/rank", "ranking", "leaderboard", "ranklist")):
            return None
        if method != "GET":
            return 405, {"error": "method_not_allowed", "message": "GET required"}
        pvp = state.get("pvp", {})
        player = {"playerId": str(profile.get("player_id", "local")), "name": str(profile.get("name", "Local Guest")), "level": int(profile.get("level", 1)), "score": int(pvp.get("rating", 1000)), "isSelf": True}
        rows = [player] + [dict(bot, isSelf=False) for bot in self.bots.all()]
        rows.sort(key=lambda item: (-int(item.get("score", 0)), str(item.get("playerId"))))
        for index, row in enumerate(rows, 1):
            row["rank"] = index
        return 200, {"ranking": rows[:100], "result": rows[:100], "self": next(row for row in rows if row["isSelf"])}

    def handle_http(self, method: str, path: str, body: Body, profile: Mapping[str, Any]) -> Optional[Response]:
        with self._lock:
            method = method.upper(); route = self._route(path); state = self._state(profile)
            for handler in (
                lambda: self._friend(method, route, body, profile, state),
                lambda: self._assist(method, route, profile),
                lambda: self._chat(method, route, body, profile, state),
                lambda: self._pvp(method, route, body, profile, state),
                lambda: self._rank(method, route, profile, state),
            ):
                result = handler()
                if result is not None:
                    return result
            return None


__all__ = ["LocalBotPool", "LocalSocial"]

"""Thread-safe local push session registry.

The retired client keeps a long-lived WebSocket open after login.  HTTP
handlers and gameplay modules therefore need a small, transport-independent
way to deliver a message to the account's active connection.  ``PushService``
owns only session membership and fan-out; protobuf encoding remains the
responsibility of the caller, so this layer cannot invent an official schema.

All account selectors are local identifiers (normally ``openId``).  No
network or third-party push provider is contacted.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Callable


class PushServiceError(ValueError):
    """Raised when a push session or event is malformed."""


@dataclass(frozen=True)
class PushEvent:
    """A message ready for delivery through a local push connection."""

    message_type: str
    data: bytes
    seq_cs_received: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.message_type, str) or not self.message_type.strip():
            raise PushServiceError("message_type must be a non-empty string")
        if not isinstance(self.data, (bytes, bytearray, memoryview)):
            raise PushServiceError("push data must be bytes")
        if self.seq_cs_received is not None and int(self.seq_cs_received) < 0:
            raise PushServiceError("seq_cs_received must be non-negative")


def account_key(account: Mapping[str, Any] | str | int) -> str:
    """Return the stable local selector used by the session registry."""

    if isinstance(account, Mapping):
        for name in ("openId", "open_id", "player_id", "account_id", "id"):
            value = account.get(name)
            if value is not None and str(value).strip():
                return str(value)
        raise PushServiceError("account has no local identifier")
    value = str(account).strip()
    if not value:
        raise PushServiceError("account selector is empty")
    return value


class PushService:
    """Track authenticated connections and fan out local events.

    A user may have multiple sessions (for example a desktop emulator and a
    phone), so ``publish`` sends to every active session for the account.  A
    failed write removes only that session and does not hide the exception
    from the audit callback.  ``send_sc`` is expected to be thread-safe; the
    built-in ``push._Connection`` serializes its writes.
    """

    def __init__(self, audit_log: Callable[..., Any] | Callable[[dict[str, Any]], Any] | None = None) -> None:
        self._lock = threading.RLock()
        self._sessions: dict[str, dict[int, Any]] = {}
        self._audit_log = audit_log

    def _audit(self, **fields: Any) -> None:
        if self._audit_log is None:
            return
        safe = {"kind": "push_service", **fields}
        try:
            if hasattr(self._audit_log, "write"):
                self._audit_log.write(**safe)
            else:
                self._audit_log(safe)
        except Exception:
            # Observability must never make a game connection fail.
            pass

    def register(self, connection: Any, account: Mapping[str, Any] | str | int) -> str:
        if connection is None or not callable(getattr(connection, "send_sc", None)):
            raise PushServiceError("connection must provide send_sc")
        key = account_key(account)
        with self._lock:
            self._sessions.setdefault(key, {})[id(connection)] = connection
        self._audit(action="register", account=key, sessions=self.connection_count(key))
        return key

    def unregister(self, connection: Any, account: Mapping[str, Any] | str | int | None = None) -> bool:
        keys = [account_key(account)] if account is not None else None
        removed = False
        with self._lock:
            selected = keys if keys is not None else list(self._sessions)
            for key in selected:
                sessions = self._sessions.get(key)
                if not sessions:
                    continue
                if sessions.pop(id(connection), None) is not None:
                    removed = True
                if not sessions:
                    self._sessions.pop(key, None)
        if removed:
            self._audit(action="unregister", sessions=self.connection_count(keys[0]) if keys else None)
        return removed

    def connection_count(self, account: Mapping[str, Any] | str | int | None = None) -> int:
        with self._lock:
            if account is None:
                return sum(len(value) for value in self._sessions.values())
            return len(self._sessions.get(account_key(account), {}))

    def accounts(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(sorted(self._sessions))

    def publish(
        self,
        account: Mapping[str, Any] | str | int,
        message_type: str,
        data: bytes,
        *,
        seq_cs_received: int | None = None,
    ) -> int:
        event = PushEvent(message_type, data, seq_cs_received)
        key = account_key(account)
        with self._lock:
            targets = tuple(self._sessions.get(key, {}).values())
        delivered = 0
        for connection in targets:
            try:
                ack = connection.last_client_sequence if event.seq_cs_received is None else event.seq_cs_received
                connection.send_sc(int(ack), event.message_type, event.data)
                delivered += 1
            except (BrokenPipeError, ConnectionError, OSError):
                self.unregister(connection, key)
                self._audit(action="delivery_failed", account=key, message_type=event.message_type)
        self._audit(action="publish", account=key, message_type=event.message_type, delivered=delivered)
        return delivered

    def publish_json(
        self,
        account: Mapping[str, Any] | str | int,
        message_type: str,
        payload: Any,
        *,
        seq_cs_received: int | None = None,
    ) -> int:
        """Publish a compact UTF-8 JSON payload for local-only envelopes.

        This is useful for events whose protobuf descriptor has not yet been
        recovered.  Typed game messages should call ``publish`` with their
        serialized protobuf bytes instead.
        """

        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return self.publish(account, message_type, data, seq_cs_received=seq_cs_received)

    def red_point(self, account: Mapping[str, Any] | str | int, payload: Any) -> int:
        return self.publish_json(account, "ScRedPointData", payload)

    def mail(self, account: Mapping[str, Any] | str | int, payload: Any) -> int:
        return self.publish_json(account, "ScMail", payload)

    def payment(self, account: Mapping[str, Any] | str | int, payload: Any) -> int:
        return self.publish_json(account, "ScPurchaseDelevery", payload)

    def chat(self, account: Mapping[str, Any] | str | int, payload: Any) -> int:
        return self.publish_json(account, "ScChat", payload)


__all__ = ["PushEvent", "PushService", "PushServiceError", "account_key"]

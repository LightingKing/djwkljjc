"""Minimal, persistent local game state for the original LJJC client.

This module implements only the authenticated local guest seam.  It uses the
extracted protobuf descriptor set to build the real bootstrap messages used by
``PushService``; it does not contact Tencent or claim that a third-party
account has logged in.  Shop and recharge calls are handled by the separate
local-only ``LocalEconomy`` sandbox and never contact an external payment
provider.

The production local defaults are explicitly marked as local policy in
``data/local-defaults.json``: actor 1001, scene 0, and descriptor-backed
resource types 6/7.  Observed ActorInfo rows are used for actor attributes;
initial resources and progression remain local policy because the original
PlayerInitConfig is unavailable.
Callers can pass ``None``/empty lists to retain an empty bootstrap while
investigating a different profile.
"""

from __future__ import annotations

import json
import shutil
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Tuple

from google.protobuf import descriptor_pb2, descriptor_pool, empty_pb2, duration_pb2, json_format, message_factory, timestamp_pb2

from server.core.clock import recover_resource

try:
    from .entering import handle_http as handle_entering_http
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from entering import handle_http as handle_entering_http
try:
    from .dungeon import LocalDungeons
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from dungeon import LocalDungeons
try:
    from .events import LocalEvents
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from events import LocalEvents
try:
    from .economy import LocalEconomy
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from economy import LocalEconomy
try:
    from .systems import LocalSystems
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from systems import LocalSystems
try:
    from .social import LocalSocial
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from social import LocalSocial
try:
    from .realtime_pvp import LocalRealtimePvp
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from realtime_pvp import LocalRealtimePvp
try:
    from .profile_features import LocalProfileFeatures
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from profile_features import LocalProfileFeatures
try:
    from .storage.compat import (
        configure_legacy_connection,
        ensure_unified_store,
        resolve_unified_store_path,
        shared_store_lock,
    )
except ImportError:  # pragma: no cover - direct PYTHONPATH execution
    from storage.compat import (
        configure_legacy_connection,
        ensure_unified_store,
        resolve_unified_store_path,
        shared_store_lock,
    )


Body = bytes | bytearray | str | None
Response = Tuple[int, Dict[str, Any]]
Message = Tuple[str, bytes]


_DEFAULTS_PATH = Path(__file__).parent / "data" / "local-defaults.json"
_ACTOR_INFO_PATH = Path(__file__).parent / "data" / "config" / "ActorInfo.json"
_PLAYER_LEVEL_INIT_PATH = Path(__file__).parent / "data" / "config" / "PlayerLevelInitConfig.json"
_ECONOMY_POLICY_PATH = Path(__file__).parent / "data" / "server-only" / "economy.yaml"
_FALLBACK_LOCAL_DEFAULTS: Dict[str, Any] = {
    "scene_id": 0,
    "actor_ids": [1001],
    "resources": [
        {"type": 6, "id": 0, "count": 120, "param": 0},
        {"type": 7, "id": 0, "count": 20000, "param": 0},
    ],
}


def _load_energy_policy() -> Dict[str, int]:
    """Load the local power recovery rule from the reviewed economy config.

    The retired service's recovery table is unavailable, so this policy is
    explicitly local and comes from ``data/server-only/economy.yaml``.  A
    conservative fallback keeps old installs readable if the optional config
    file is absent or malformed.
    """

    fallback = {"type": 6, "id": 0, "param": 0, "capacity": 120, "recovery_seconds": 360, "amount": 1}
    try:
        import yaml

        raw = yaml.safe_load(_ECONOMY_POLICY_PATH.read_text(encoding="utf-8"))
        resource = raw.get("resources", {}).get("player_power", {}) if isinstance(raw, Mapping) else {}
        if not isinstance(resource, Mapping):
            return fallback
        value = dict(fallback)
        value["type"] = int(resource.get("type", value["type"]))
        value["capacity"] = max(0, int(resource.get("capacity", value["capacity"])))
        value["recovery_seconds"] = max(1, int(resource.get("recoverySeconds", value["recovery_seconds"])))
        value["amount"] = max(1, int(resource.get("recoveryAmount", value["amount"])))
        return value
    except (ImportError, OSError, TypeError, ValueError, AttributeError):
        return fallback


def _load_local_defaults() -> Dict[str, Any]:
    """Load reviewed local-only defaults, with a safe code fallback."""

    try:
        data = json.loads(_DEFAULTS_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("defaults must be an object")
        actor_ids = data.get("actor_ids")
        resources = data.get("resources")
        if not isinstance(actor_ids, list) or not all(isinstance(value, int) for value in actor_ids):
            raise ValueError("actor_ids must be integer list")
        if not isinstance(resources, list) or not all(isinstance(value, dict) for value in resources):
            raise ValueError("resources must be object list")
        return data
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return dict(_FALLBACK_LOCAL_DEFAULTS)


def _load_actor_info() -> dict[int, dict[str, Any]]:
    """Load observed ActorInfo rows without treating a partial export as full."""

    try:
        payload = json.loads(_ACTOR_INFO_PATH.read_text(encoding="utf-8"))
        rows = payload.get("rows", []) if isinstance(payload, Mapping) else []
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return {}
    result: dict[int, dict[str, Any]] = {}
    if not isinstance(rows, list):
        return result
    for raw in rows:
        if not isinstance(raw, Mapping):
            continue
        try:
            actor_id = int(raw.get("id", 0))
        except (TypeError, ValueError):
            continue
        if actor_id <= 0:
            continue
        attrs: list[dict[str, Any]] = []
        for item in raw.get("attrs", []) or []:
            if not isinstance(item, Mapping):
                continue
            try:
                attr_type = int(item.get("type", 0))
                value = int(item.get("value", 0))
            except (TypeError, ValueError):
                continue
            if attr_type <= 0 or value < 0:
                continue
            attrs.append({
                "type": attr_type,
                "value": value,
                "isRatio": bool(item.get("isRatio", False)),
            })
        result[actor_id] = {
            "attrs": attrs,
            "quality": max(1, int(raw.get("quality", 1) or 1)),
        }
    return result


def _load_tutorial_steps(defaults: Mapping[str, Any]) -> list[dict[str, int]]:
    """Load tutorial IDs and sequence from the extracted table.

    The checked-in Tutorial table is a partial runtime sample (its metadata
    reports more observed rows than are stored), so using only those rows would
    silently remove later tutorial steps.  The fallback lives in
    ``data/local-defaults.json`` rather than in executable code and can be
    replaced when a complete table is recovered.
    """
    config_path = Path(__file__).parent / "data" / "config" / "Tutorial.json"
    try:
        payload = json.loads(config_path.read_text(encoding="utf-8"))
        rows = payload.get("rows", []) if isinstance(payload, dict) else []
        observed = int(payload.get("observedCount", len(rows))) if isinstance(payload, dict) else len(rows)
        steps_by_id: dict[int, int] = {}
        for row in rows:
            if not isinstance(row, Mapping) or not str(row.get("id", "")).isdigit():
                continue
            tutorial_id = int(row["id"])
            try:
                sequence = int(row.get("sequence", tutorial_id))
            except (TypeError, ValueError):
                sequence = tutorial_id
            steps_by_id[tutorial_id] = sequence
        if steps_by_id and observed <= len(rows):
            return [
                {"id": tutorial_id, "sequence": sequence}
                for tutorial_id, sequence in sorted(steps_by_id.items(), key=lambda item: (item[1], item[0]))
            ]
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        pass
    fallback = defaults.get("tutorial_ids", []) if isinstance(defaults, Mapping) else []
    if isinstance(fallback, list):
        values = sorted({int(value) for value in fallback if isinstance(value, int) and value > 0})
        if values:
            return [{"id": value, "sequence": index} for index, value in enumerate(values, start=1)]
    return []


def _load_initial_level(defaults: Mapping[str, Any]) -> int:
    """Read the first observed player level from the extracted config.

    ``PlayerInitConfig`` is unavailable in the captured APK, but the first
    ``PlayerLevelInitConfig`` row is present and explicitly records level 1.
    Using that row keeps profile creation data-driven while retaining a safe
    local fallback for older archives that do not include the table.
    """

    try:
        payload = json.loads(_PLAYER_LEVEL_INIT_PATH.read_text(encoding="utf-8"))
        rows = payload.get("rows", []) if isinstance(payload, Mapping) else []
        if isinstance(rows, list) and rows and isinstance(rows[0], Mapping):
            level = int(rows[0].get("level", 0))
            if level > 0:
                return level
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        pass
    try:
        level = int(defaults.get("initial_level", 1))
        return level if level > 0 else 1
    except (AttributeError, TypeError, ValueError):
        return 1


def _normalise_resource_rows(value: Any) -> list[dict[str, int]]:
    """Return a safe, JSON-compatible resource list from a saved profile.

    Old local builds wrote the resource list as JSON and a crashed or manually
    interrupted write could leave one malformed row.  Login and passive
    recovery must remain available in that situation; silently skipping the
    malformed row is safer than turning a damaged save into a server error or
    allowing a negative balance to reach the client.
    """

    if not isinstance(value, list):
        return []
    result: list[dict[str, int]] = []
    for raw in value:
        if not isinstance(raw, Mapping):
            continue
        try:
            resource_type = int(raw.get("type", 0))
            resource_id = int(raw.get("id", 0))
            count = max(0, int(raw.get("count", 0)))
            param = int(raw.get("param", 0))
        except (TypeError, ValueError, OverflowError):
            continue
        if resource_type < 0 or resource_id < 0 or param < 0:
            continue
        entry = {"type": resource_type, "id": resource_id, "count": count}
        # ``param`` was optional in the original JSON seam.  Preserve its
        # absence so a legacy profile does not change shape merely because it
        # was opened by a newer server.
        if "param" in raw:
            entry["param"] = param
        result.append(entry)
    return result


_LOCAL_DEFAULTS = _load_local_defaults()
_LOCAL_TUTORIAL_STEPS = _load_tutorial_steps(_LOCAL_DEFAULTS)
_LOCAL_TUTORIAL_IDS = [step["id"] for step in _LOCAL_TUTORIAL_STEPS]
_LOCAL_TUTORIAL_SEQUENCE = {step["id"]: step["sequence"] for step in _LOCAL_TUTORIAL_STEPS}
_LOCAL_DEFAULT_ACTOR_IDS = [int(value) for value in _LOCAL_DEFAULTS.get("actor_ids", [])]
_LOCAL_DEFAULT_RESOURCES = [dict(value) for value in _LOCAL_DEFAULTS.get("resources", [])]
_LOCAL_DEFAULT_SIGNBOARD = dict(_LOCAL_DEFAULTS.get("signboard", {"signboard": 101, "unlockedSignboardId": [101], "checkSignboardTime": 0}))
_LOCAL_DEFAULT_ACTOR_TEMPLATE = dict(_LOCAL_DEFAULTS.get("actor", {}))
_LOCAL_INITIAL_LEVEL = _load_initial_level(_LOCAL_DEFAULTS)
_ACTOR_INFO = _load_actor_info()


def _message_pool(descriptor_path: Path) -> descriptor_pool.DescriptorPool:
    """Load the extracted descriptor set, skipping only known bad candidates."""

    data = descriptor_pb2.FileDescriptorSet.FromString(descriptor_path.read_bytes())
    pool = descriptor_pool.Default()
    pending: list[descriptor_pb2.FileDescriptorProto] = []
    for file_descriptor in data.file:
        # A bytes-valued syntax is evidence of a concatenated metadata stream,
        # not a usable FileDescriptorProto.  Do not coerce it into a schema.
        if isinstance(file_descriptor.syntax, bytes):
            continue
        try:
            pool.FindFileByName(file_descriptor.name)
        except KeyError:
            pending.append(file_descriptor)
    while pending:
        remaining: list[descriptor_pb2.FileDescriptorProto] = []
        for file_descriptor in pending:
            try:
                pool.Add(file_descriptor)
            except Exception:
                remaining.append(file_descriptor)
        if len(remaining) == len(pending):
            # Optional activity descriptors may remain unavailable.  The
            # bootstrap graph is checked below and must still resolve.
            break
        pending = remaining
    return pool


def _class(pool: descriptor_pool.DescriptorPool, full_name: str):
    return message_factory.GetMessageClass(pool.FindMessageTypeByName(full_name))


def _auth_token(authorization: Optional[str]) -> Optional[str]:
    if not authorization:
        return None
    parts = authorization.strip().split(None, 1)
    # The original client uses ``Authorization: Token <access-token>`` for
    # post-login FCI requests.  Keep AccountToken for the local account seam
    # and older test clients; both schemes still go through the same local
    # verifier and neither is accepted without a valid stored token.
    if len(parts) != 2 or parts[0].lower() not in {"token", "accounttoken"}:
        return None
    return parts[1].strip() or None


def _route(path: str) -> str:
    route = (path or "").split("?", 1)[0] or "/"
    if route != "/":
        route = route.rstrip("/") + "/"
    return route


def _body_object(body: Body) -> Mapping[str, Any]:
    """Decode the local JSON seam without treating arbitrary bytes as JSON."""

    if body is None:
        return {}
    raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
    if not raw:
        return {}
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, Mapping) else {}


class LocalGame:
    """Authenticated local player profile and protobuf login bootstrap."""

    def __init__(
        self,
        state_dir: str | Path,
        accounts: Any,
        *,
        descriptor_path: str | Path | None = None,
        clock: Optional[Callable[[], int]] = None,
        initial_actor_id: Optional[int] = _LOCAL_DEFAULT_ACTOR_IDS[0] if _LOCAL_DEFAULT_ACTOR_IDS else None,
        initial_actor_ids: Optional[Iterable[int]] = None,
        initial_resources: Optional[Iterable[Mapping[str, int]]] = _LOCAL_DEFAULT_RESOURCES,
        initial_level: Optional[int] = _LOCAL_INITIAL_LEVEL,
        scene_id: int = int(_LOCAL_DEFAULTS.get("scene_id", 0)),
        scene_random: bool = False,
        unified_store_path: str | Path | None = None,
    ) -> None:
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.unified_store_path = resolve_unified_store_path(self.state_dir, unified_store_path)
        if self.unified_store_path is not None:
            ensure_unified_store(self.unified_store_path)
            self.db_path = self.unified_store_path
        else:
            self.db_path = self.state_dir / "game.sqlite3"
        self.accounts = accounts
        self._clock = clock or (lambda: int(time.time()))
        self.energy_policy = _load_energy_policy()
        # Serialize all profile mutations for a database path, including when
        # two local game objects are opened by a test or a hot-reload tool.
        # SQLite's busy timeout handles external processes; this shared lock
        # prevents same-process lost updates before they reach SQLite.
        self._lock = shared_store_lock(self.db_path)
        self.initial_actor_id = initial_actor_id
        if initial_actor_ids is None:
            self.initial_actor_ids = [int(initial_actor_id)] if initial_actor_id is not None else []
        else:
            self.initial_actor_ids = [int(actor_id) for actor_id in initial_actor_ids]
            if initial_actor_id is None and self.initial_actor_ids:
                self.initial_actor_id = self.initial_actor_ids[0]
        self.initial_resources = [dict(item) for item in (initial_resources or [])]
        try:
            parsed_level = int(initial_level if initial_level is not None else _LOCAL_INITIAL_LEVEL)
        except (TypeError, ValueError, OverflowError):
            parsed_level = _LOCAL_INITIAL_LEVEL
        self.initial_level = max(1, parsed_level)
        self.scene_id = int(scene_id)
        self.scene_random = bool(scene_random)
        schema_path = Path(descriptor_path) if descriptor_path else Path(__file__).parent / "data" / "descriptor_set.pb"
        self._pool = _message_pool(schema_path)
        # Fail early if the bootstrap graph is not present; optional activity
        # descriptors are deliberately not part of this check.
        self._types = {
            name: _class(self._pool, name)
            for name in (
                "ScLoginBegin",
                "ScLoginTutorial",
                "DBGamePlayer.Actors",
                "DBGamePlayer.EquipPackage",
                "DBGamePlayer.ItemPackage",
                "ScLoginEnd",
                # ApiChapterInfo.result is the typed result payload carried
                # inside RestfulResponse.message (response type 1).  Keeping
                # this nested descriptor, rather than the JSON envelope,
                # preserves uint32 map keys for Unity's PB decoder.
                "ApiChapterInfo.result",
                # Chapter red-point bindings request each chapter detail as a
                # separate typed ``ApiChapterInfo.get`` resource.
                "ApiChapterInfo.get",
                # Standard Story/Normal scenes PATCH this exact message after
                # the client-side fight logic reaches a terminal state.
                "FightActiveData",
                # Normal chapter entry uses a wireformat ApiDungeon request
                # (Story entry uses the small JSON seam).  Keep the real
                # descriptor available so LocalDungeons can accept both
                # observed request shapes.
                "ApiDungeon",
                "ApiAutoFightConf",
                "ApiTutorial",
            )
        }
        self._initialize()
        self.dungeons = LocalDungeons(self, clock=self._clock)
        # Shop and payment state lives in its own SQLite file.  The economy
        # handler receives the authenticated account alongside the profile so
        # resource changes are written back to game_profiles atomically.
        self.economy = LocalEconomy(
            self.state_dir,
            self,
            clock=self._clock,
            unified_store_path=self.unified_store_path,
        )
        # Sign-in and activity claims share the game profile database so their
        # resource deltas survive service restarts and remain visible in the
        # next login bootstrap.
        self.events = LocalEvents(self, clock=self._clock)
        # Actor/card/equipment/mail/relation/PVP state is local-only and
        # intentionally separate from the retired service's unavailable data.
        self.systems = LocalSystems(self, clock=self._clock)
        self.social = LocalSocial(self, clock=self._clock)
        # RacePVP/BurstLink use a separate deterministic local match state so
        # real-time rounds cannot collide with async-PVP or social records.
        self.realtime_pvp = LocalRealtimePvp(self, clock=self._clock)
        # Player profile, notice, collection and web-vote state is kept in a
        # separate local table so it can evolve without changing the legacy
        # bootstrap schema.  It is still in the same SQLite/WAL store.
        self.profile_features = LocalProfileFeatures(self, clock=self._clock)
        self._migrate_profiles()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(str(self.db_path), timeout=10)
        connection.row_factory = sqlite3.Row
        configure_legacy_connection(connection)
        return connection

    def _initialize(self) -> None:
        with self._lock, closing(self._connect()) as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS game_profiles (
                    account_id INTEGER PRIMARY KEY,
                    player_id TEXT NOT NULL UNIQUE,
                    level INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    scene_id INTEGER NOT NULL,
                    scene_random INTEGER NOT NULL,
                    actor_id INTEGER,
                    resources_json TEXT NOT NULL,
                    actor_ids_json TEXT NOT NULL DEFAULT '[]',
                    signboard_json TEXT NOT NULL DEFAULT '{}',
                    tutorials_json TEXT NOT NULL DEFAULT '{}',
                    tutorial_steps_json TEXT NOT NULL DEFAULT '{}',
                    auto_fight_json TEXT NOT NULL DEFAULT '{}',
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )
            columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(game_profiles)")
            }
            if "actor_ids_json" not in columns:
                connection.execute(
                    "ALTER TABLE game_profiles ADD COLUMN actor_ids_json TEXT NOT NULL DEFAULT '[]'"
                )
            if "signboard_json" not in columns:
                connection.execute(
                    "ALTER TABLE game_profiles ADD COLUMN signboard_json TEXT NOT NULL DEFAULT '{}'"
                )
            if "tutorials_json" not in columns:
                connection.execute(
                    "ALTER TABLE game_profiles ADD COLUMN tutorials_json TEXT NOT NULL DEFAULT '{}'"
                )
            if "tutorial_steps_json" not in columns:
                connection.execute(
                    "ALTER TABLE game_profiles ADD COLUMN tutorial_steps_json TEXT NOT NULL DEFAULT '{}'"
                )
            if "auto_fight_json" not in columns:
                connection.execute(
                    "ALTER TABLE game_profiles ADD COLUMN auto_fight_json TEXT NOT NULL DEFAULT '{}'"
                )
            # Recovery state is separate from the profile JSON so a legacy
            # profile can be upgraded without rewriting its saved resources.
            # The ledger table records every passive grant for diagnostics and
            # rollback/audit tooling; it is deliberately local-only.
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS local_resource_recovery (
                    account_id INTEGER PRIMARY KEY,
                    resource_type INTEGER NOT NULL,
                    resource_id INTEGER NOT NULL DEFAULT 0,
                    param INTEGER NOT NULL DEFAULT 0,
                    capacity INTEGER NOT NULL,
                    interval_seconds INTEGER NOT NULL,
                    amount_per_interval INTEGER NOT NULL,
                    last_recovery_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS local_resource_ledger (
                    entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    account_id INTEGER NOT NULL,
                    operation TEXT NOT NULL CHECK(operation IN ('grant','consume')),
                    resource_type INTEGER NOT NULL,
                    resource_id INTEGER NOT NULL,
                    param INTEGER NOT NULL,
                    delta INTEGER NOT NULL,
                    balance_after INTEGER NOT NULL CHECK(balance_after >= 0),
                    reason TEXT NOT NULL,
                    idempotency_key TEXT,
                    created_at INTEGER NOT NULL,
                    UNIQUE(account_id, idempotency_key)
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_local_resource_ledger_account_time "
                "ON local_resource_ledger(account_id, created_at, entry_id)"
            )

    def _migration_backup_path(self) -> Path:
        """Choose a non-overwriting backup path for a profile migration."""

        base = self.db_path.with_name(self.db_path.name + ".preconfig-migration.bak")
        if not base.exists():
            return base
        index = 1
        while True:
            candidate = self.db_path.with_name(
                self.db_path.name + f".preconfig-migration.{index}.bak"
            )
            if not candidate.exists():
                return candidate
            index += 1

    def _migrate_profiles(self) -> None:
        """Apply newly verified non-empty defaults without overwriting state.

        A profile created by an earlier build may have no actor/resources
        because runtime config was unavailable.  Once the caller supplies a
        verified config value, fill only those still-empty columns.  Existing
        actor IDs and resource lists are preserved.  A byte-for-byte SQLite
        backup is made before the first write and is never overwritten.
        """

        if self.initial_actor_id is None and not self.initial_resources:
            return
        updates: list[tuple[int, Optional[int], Optional[str], Optional[str], Optional[str]]] = []
        with self._lock, closing(self._connect()) as connection, connection:
            rows = connection.execute(
                "SELECT account_id, actor_id, actor_ids_json, resources_json, signboard_json FROM game_profiles"
            ).fetchall()
            for row in rows:
                actor_id = row["actor_id"]
                try:
                    actor_ids = json.loads(row["actor_ids_json"] or "[]")
                except (TypeError, ValueError):
                    actor_ids = []
                resources_json = row["resources_json"]
                signboard_json = row["signboard_json"] or "{}"
                try:
                    resources = json.loads(resources_json)
                except (TypeError, ValueError):
                    # Malformed historical state is left untouched.
                    continue
                new_actor = actor_id
                new_actor_ids_json: Optional[str] = None
                new_resources_json: Optional[str] = None
                new_signboard_json: Optional[str] = None
                if new_actor is None and self.initial_actor_id is not None:
                    new_actor = int(self.initial_actor_id)
                if not actor_ids:
                    actor_ids_to_store = (
                        [int(new_actor)]
                        if new_actor is not None
                        else list(self.initial_actor_ids)
                    )
                    if actor_ids_to_store:
                        new_actor_ids_json = json.dumps(actor_ids_to_store, separators=(",", ":"))
                if resources == [] and self.initial_resources:
                    new_resources_json = json.dumps(self.initial_resources, separators=(",", ":"))
                try:
                    signboard = json.loads(signboard_json)
                except (TypeError, ValueError):
                    signboard = {}
                if not isinstance(signboard, dict) or not signboard.get("signboard"):
                    new_signboard_json = json.dumps(_LOCAL_DEFAULT_SIGNBOARD, separators=(",", ":"))
                if new_actor != actor_id or new_actor_ids_json is not None or new_resources_json is not None or new_signboard_json is not None:
                    # Keep the existing actor_id/resources semantics while
                    # carrying the expanded multi-actor list separately.
                    updates.append((int(row["account_id"]), new_actor, new_actor_ids_json, new_resources_json, new_signboard_json))
            if not updates:
                return
            backup_path = self._migration_backup_path()
            shutil.copy2(self.db_path, backup_path)
            now = self._now()
            for account_id, actor_id, actor_ids_json, resources_json, signboard_json in updates:
                assignments = ["actor_id = ?", "updated_at = ?"]
                params: list[Any] = [actor_id, now]
                if actor_ids_json is not None:
                    assignments.insert(1, "actor_ids_json = ?")
                    params.insert(1, actor_ids_json)
                if resources_json is not None:
                    assignments.insert(1, "resources_json = ?")
                    params.insert(1, resources_json)
                if signboard_json is not None:
                    assignments.insert(1, "signboard_json = ?")
                    params.insert(1, signboard_json)
                params.append(account_id)
                connection.execute(
                    f"UPDATE game_profiles SET {', '.join(assignments)} WHERE account_id = ?",
                    params,
                )

    def _now(self) -> int:
        return int(self._clock())

    def _recover_passive_resources(
        self,
        connection: sqlite3.Connection,
        account_id: int,
        resources: list[dict[str, Any]],
    ) -> int:
        """Apply elapsed local power recovery while a profile is read.

        ``resources_json`` remains the compatibility source consumed by the
        client.  A small recovery-state row provides a monotonic marker, and
        each non-zero grant is written to ``local_resource_ledger`` in the
        same SQLite transaction.  This makes login, reconnect, and any other
        profile read converge on one deterministic balance without requiring a
        background worker.
        """

        policy = self.energy_policy
        resource_type = int(policy.get("type", 6))
        resource_id = int(policy.get("id", 0))
        param = int(policy.get("param", 0))
        capacity = int(policy.get("capacity", 120))
        interval_seconds = int(policy.get("recovery_seconds", 360))
        amount = int(policy.get("amount", 1))
        entry = next(
            (
                item
                for item in resources
                if isinstance(item, Mapping)
                and int(item.get("type", -1)) == resource_type
                and int(item.get("id", 0)) == resource_id
                and int(item.get("param", 0)) == param
            ),
            None,
        )
        # Do not invent a resource for profiles deliberately created without
        # local defaults.  Such profiles remain valid empty bootstrap data.
        if entry is None or capacity <= 0:
            return self._now()
        now = self._now()
        state = connection.execute(
            "SELECT last_recovery_at FROM local_resource_recovery WHERE account_id = ?",
            (int(account_id),),
        ).fetchone()
        if state is None:
            connection.execute(
                """
                INSERT INTO local_resource_recovery
                (account_id, resource_type, resource_id, param, capacity,
                 interval_seconds, amount_per_interval, last_recovery_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (int(account_id), resource_type, resource_id, param, capacity,
                 interval_seconds, amount, now, now),
            )
            return now
        try:
            previous = int(state[0])
            current = max(0, int(entry.get("count", 0)))
            recovered = recover_resource(
                balance=min(current, capacity),
                last_recovery_at=previous,
                now=now,
                capacity=capacity,
                interval_seconds=interval_seconds,
                amount_per_interval=amount,
            )
        except (TypeError, ValueError):
            # A clock rollback or damaged marker must never mint currency.
            # Re-anchor to the current server time and leave the balance as-is.
            connection.execute(
                "UPDATE local_resource_recovery SET last_recovery_at = ?, updated_at = ? WHERE account_id = ?",
                (now, now, int(account_id)),
            )
            return now
        entry["count"] = int(recovered.balance)
        if recovered.recovered > 0:
            idempotency_key = f"energy-recovery:{int(account_id)}:{previous}:{now}"
            connection.execute(
                """
                INSERT OR IGNORE INTO local_resource_ledger
                (account_id, operation, resource_type, resource_id, param, delta,
                 balance_after, reason, idempotency_key, created_at)
                VALUES (?, 'grant', ?, ?, ?, ?, ?, 'passive_energy_recovery', ?, ?)
                """,
                (int(account_id), resource_type, resource_id, param,
                 int(recovered.recovered), int(recovered.balance), idempotency_key, now),
            )
        connection.execute(
            """
            UPDATE local_resource_recovery
            SET capacity = ?, interval_seconds = ?, amount_per_interval = ?,
                last_recovery_at = ?, updated_at = ?
            WHERE account_id = ?
            """,
            (capacity, interval_seconds, amount, int(recovered.last_recovery_at), now, int(account_id)),
        )
        if recovered.recovered > 0:
            connection.execute(
                "UPDATE game_profiles SET resources_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(resources, separators=(",", ":")), now, int(account_id)),
            )
        return now

    def _profile(self, account: Mapping[str, Any]) -> Dict[str, Any]:
        account_id = int(account["accountId"])
        with self._lock, closing(self._connect()) as connection, connection:
            row = connection.execute(
                "SELECT * FROM game_profiles WHERE account_id = ?", (account_id,)
            ).fetchone()
            if row is None:
                now = self._now()
                player_id = f"local-{account_id}"
                resources_json = json.dumps(self.initial_resources, separators=(",", ":"))
                connection.execute(
                    """
                    INSERT OR IGNORE INTO game_profiles
                    (account_id, player_id, level, name, scene_id, scene_random,
                     actor_id, resources_json, actor_ids_json, signboard_json,
                     tutorials_json, tutorial_steps_json, auto_fight_json, created_at, updated_at)
                    VALUES (?, ?, ?, '', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        account_id,
                        player_id,
                        self.initial_level,
                        self.scene_id,
                        int(self.scene_random),
                        self.initial_actor_id,
                        resources_json,
                        json.dumps(self.initial_actor_ids, separators=(",", ":")),
                        json.dumps(_LOCAL_DEFAULT_SIGNBOARD, separators=(",", ":")),
                        json.dumps({str(tutorial_id): 0 for tutorial_id in _LOCAL_TUTORIAL_IDS}, separators=(",", ":")),
                        json.dumps({str(tutorial_id): 0 for tutorial_id in _LOCAL_TUTORIAL_IDS}, separators=(",", ":")),
                        json.dumps({"banedSkills": {}}, separators=(",", ":")),
                        now,
                        now,
                    ),
                )
                row = connection.execute(
                    "SELECT * FROM game_profiles WHERE account_id = ?", (account_id,)
                ).fetchone()
            result = dict(row)
            raw_resources = result.pop("resources_json")
            try:
                decoded_resources = json.loads(raw_resources)
            except (TypeError, ValueError, json.JSONDecodeError):
                decoded_resources = []
            result["resources"] = _normalise_resource_rows(decoded_resources)
            # Repair malformed legacy JSON once, while keeping the account,
            # actor and progression columns untouched.  This makes later
            # logins deterministic and gives the recovery/ledger code a
            # canonical shape to operate on.
            if result["resources"] != decoded_resources:
                connection.execute(
                    "UPDATE game_profiles SET resources_json = ?, updated_at = ? WHERE account_id = ?",
                    (
                        json.dumps(result["resources"], separators=(",", ":")),
                        self._now(),
                        int(account_id),
                    ),
                )
            self._recover_passive_resources(connection, int(account_id), result["resources"])
            try:
                raw_actor_ids = json.loads(result.pop("actor_ids_json") or "[]")
            except (TypeError, ValueError, json.JSONDecodeError):
                raw_actor_ids = []
            result["actor_ids"] = []
            if isinstance(raw_actor_ids, list):
                for value in raw_actor_ids:
                    try:
                        actor_id = int(value)
                    except (TypeError, ValueError, OverflowError):
                        continue
                    if actor_id > 0 and actor_id not in result["actor_ids"]:
                        result["actor_ids"].append(actor_id)
            if not result["actor_ids"] and result["actor_id"] is not None:
                try:
                    actor_id = int(result["actor_id"])
                except (TypeError, ValueError, OverflowError):
                    actor_id = 0
                if actor_id > 0:
                    result["actor_ids"] = [actor_id]
            try:
                result["signboard"] = json.loads(result.pop("signboard_json") or "{}")
            except (TypeError, ValueError):
                result["signboard"] = {}
            try:
                raw_tutorials = json.loads(result.pop("tutorials_json") or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                raw_tutorials = {}
            result["tutorials"] = {}
            if isinstance(raw_tutorials, Mapping):
                for key, value in raw_tutorials.items():
                    try:
                        result["tutorials"][str(key)] = 1 if int(value) else 0
                    except (TypeError, ValueError, OverflowError):
                        continue
            for tutorial_id in _LOCAL_TUTORIAL_IDS:
                result["tutorials"].setdefault(str(tutorial_id), 0)
            try:
                raw_tutorial_steps = json.loads(result.pop("tutorial_steps_json") or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                raw_tutorial_steps = {}
            result["tutorial_steps"] = {}
            if isinstance(raw_tutorial_steps, Mapping):
                for key, value in raw_tutorial_steps.items():
                    try:
                        result["tutorial_steps"][str(key)] = max(0, int(value))
                    except (TypeError, ValueError, OverflowError):
                        continue
            for tutorial_id in _LOCAL_TUTORIAL_IDS:
                result["tutorial_steps"].setdefault(str(tutorial_id), 0)
            try:
                result["auto_fight"] = json.loads(result.pop("auto_fight_json") or "{}")
            except (TypeError, ValueError):
                result["auto_fight"] = {}
            if not isinstance(result["auto_fight"], dict):
                result["auto_fight"] = {}
            baned_skills = result["auto_fight"].get("banedSkills", {})
            clean_skills: dict[str, int] = {}
            if isinstance(baned_skills, Mapping):
                for key, value in baned_skills.items():
                    try:
                        parsed = int(value)
                    except (TypeError, ValueError, OverflowError):
                        continue
                    if parsed in (0, 1):
                        clean_skills[str(key)] = parsed
            result["auto_fight"]["banedSkills"] = clean_skills
            result["scene_random"] = bool(result["scene_random"])
            return result

    def _authorized(self, authorization: Optional[str]) -> Tuple[Optional[Dict[str, Any]], Optional[Response]]:
        token = _auth_token(authorization)
        account = self.accounts.verify_access_token(token or "")
        if account is None:
            return None, (401, {"error": "invalid_account_token", "message": "local Token or AccountToken required"})
        return account, None

    def _resource_message(self, profile: Mapping[str, Any]):
        # Resource IDs are only emitted when explicitly supplied from verified
        # local config; no resource/paid currency is fabricated here.
        return [dict(item) for item in profile["resources"]]

    def _tutorial_http(
        self,
        method: str,
        path: str,
        body: Body,
        profile: Mapping[str, Any],
    ) -> Optional[Response]:
        route = _route(path)
        prefix = "/fci/tutorial/"
        if not route.startswith(prefix):
            return None
        suffix = route[len(prefix) :].strip("/")
        method = method.upper()
        if suffix == "":
            if method != "GET":
                return 405, {"error": "method_not_allowed", "message": "GET required"}
            return 200, [
                {
                    "id": tutorial_id,
                    "sequence": int(_LOCAL_TUTORIAL_SEQUENCE.get(tutorial_id, tutorial_id)),
                    "status": int(profile["tutorials"].get(str(tutorial_id), 0)),
                    "step": int(profile.get("tutorial_steps", {}).get(str(tutorial_id), 0)),
                }
                for tutorial_id in _LOCAL_TUTORIAL_IDS
            ]
        parts = suffix.split("/")
        if not parts[0].isdigit():
            return None
        tutorial_id = int(parts[0])
        if tutorial_id not in _LOCAL_TUTORIAL_IDS:
            return 501, {"error": "tutorial_not_implemented", "tutorialId": tutorial_id}
        if len(parts) > 1:
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            raw_step = parts[1]
            if not raw_step.isdigit():
                return 400, {"error": "invalid_tutorial_step", "tutorialId": tutorial_id}
            step = int(raw_step)
            # Manager_TutorialManager posts every reached TutorialStep and
            # only sends the final PUT once the tutorial is complete.  Keep
            # the highest reached step so a reconnect can resume safely; a
            # repeated or out-of-order POST is idempotent and never regresses
            # the saved progress.
            current_steps = dict(profile.get("tutorial_steps", {}))
            current = int(current_steps.get(str(tutorial_id), 0) or 0)
            if step > current:
                current_steps[str(tutorial_id)] = step
                with self._lock, closing(self._connect()) as connection, connection:
                    connection.execute(
                        "UPDATE game_profiles SET tutorial_steps_json = ?, updated_at = ? WHERE account_id = ?",
                        (
                            json.dumps(current_steps, separators=(",", ":")),
                            self._now(),
                            int(profile["account_id"]),
                        ),
                    )
            # Step progress is local and intentionally has no reward/result
            # side effect; the subsequent PUT carries status=1 when needed.
            return 200, {}
        if method != "PUT":
            return 405, {"error": "method_not_allowed", "message": "PUT required"}
        request = _body_object(body)
        raw_status = request.get("status")
        raw_force_finish = request.get("stepForceFinish", request.get("step_force_finish", False))
        force_finish = bool(raw_force_finish)
        if raw_status is None and body is not None:
            try:
                message = self._types["ApiTutorial"]()
                raw = bytes(body) if not isinstance(body, str) else body.encode("utf-8")
                message.ParseFromString(raw)
                raw_status = int(message.status)
                force_finish = bool(message.step_force_finish)
            except (TypeError, ValueError):
                raw_status = None
        try:
            status = int(raw_status if raw_status is not None else 0)
        except (TypeError, ValueError):
            return 400, {"error": "invalid_tutorial_status"}
        status = 1 if status else 0
        if status:
            # Tutorial rows are ordered by the recovered sequence field (or
            # the reviewed local fallback sequence).  Completing a later
            # step before every preceding step leaves the client in a state
            # the original flow cannot represent, so reject that transition
            # while still allowing an explicit reset to status 0.
            sequence = int(_LOCAL_TUTORIAL_SEQUENCE.get(tutorial_id, tutorial_id))
            previous_ids = [
                previous_id
                for previous_id in _LOCAL_TUTORIAL_IDS
                if int(_LOCAL_TUTORIAL_SEQUENCE.get(previous_id, previous_id)) < sequence
            ]
            if any(int(profile["tutorials"].get(str(previous_id), 0)) != 1 for previous_id in previous_ids):
                return 409, {
                    "error": "tutorial_locked",
                    "tutorialId": tutorial_id,
                    "requiredTutorialIds": previous_ids,
                }
        tutorials = dict(profile["tutorials"])
        tutorial_steps = dict(profile.get("tutorial_steps", {}))
        tutorials[str(tutorial_id)] = status
        if status == 0:
            # Resetting a tutorial also resets its step cursor.  This mirrors
            # a fresh local tutorial while retaining other tutorial states.
            tutorial_steps[str(tutorial_id)] = 0
        with self._lock, closing(self._connect()) as connection, connection:
            connection.execute(
                "UPDATE game_profiles SET tutorials_json = ?, tutorial_steps_json = ?, updated_at = ? WHERE account_id = ?",
                (
                    json.dumps(tutorials, separators=(",", ":")),
                    json.dumps(tutorial_steps, separators=(",", ":")),
                    self._now(),
                    int(profile["account_id"]),
                ),
            )
        return 200, {}

    @staticmethod
    def _normalise_baned_skills(value: Any) -> Optional[Dict[str, int]]:
        if not isinstance(value, Mapping):
            return None
        result: Dict[str, int] = {}
        for key, raw_value in value.items():
            try:
                skill_state = int(raw_value)
            except (TypeError, ValueError):
                return None
            if skill_state not in (0, 1):
                return None
            result[str(key)] = skill_state
        return result

    def _auto_fight_http(
        self,
        method: str,
        path: str,
        body: Body,
        profile: Mapping[str, Any],
    ) -> Optional[Response]:
        route = _route(path)
        if route != "/fci/auto-fight-conf/":
            return None
        method = method.upper()
        current = profile.get("auto_fight", {})
        if not isinstance(current, Mapping):
            current = {}
        current_skills = self._normalise_baned_skills(current.get("banedSkills", {})) or {}
        if method == "GET":
            return 200, {"banedSkills": current_skills}
        if method != "POST":
            return 405, {"error": "method_not_allowed", "message": "GET or POST required"}

        request = _body_object(body)
        requested: Any = request.get("configureSkills", request.get("banedSkills"))
        skills = self._normalise_baned_skills(requested)
        if skills is None and body is not None:
            # The native Restifizer request is a raw ApiAutoFightConf
            # protobuf whose configureSkills map has string keys and uint32
            # 0/1 values.  Keep the JSON seam above for local diagnostics.
            try:
                message = self._types["ApiAutoFightConf"]()
                message.ParseFromString(bytes(body) if not isinstance(body, str) else body.encode("utf-8"))
                skills_field = getattr(message, "configureSkills", None)
                if skills_field is None:
                    skills_field = getattr(message, "configure_skills", {})
                skills = self._normalise_baned_skills(dict(skills_field))
            except (TypeError, ValueError):
                skills = None
        if skills is None:
            return 400, {"error": "invalid_auto_fight_config"}
        stored = {"banedSkills": skills}
        with self._lock, closing(self._connect()) as connection, connection:
            connection.execute(
                "UPDATE game_profiles SET auto_fight_json = ?, updated_at = ? WHERE account_id = ?",
                (json.dumps(stored, separators=(",", ":")), self._now(), int(profile["account_id"])),
            )
        return 200, stored

    def _append_local_actor(self, actors: Any, actor_id: int, uid: int, index: int) -> None:
        """Append a schema-complete local test actor.

        The IDs/model fields come from the live ActorConfig sample.  When an
        observed ActorInfo row exists, its attributes and quality are used;
        missing rows retain the reviewed local fallback because the table is
        explicitly partial.
        """

        actor = actors.player_actors.add()
        actor.id = int(actor_id)
        actor.uid = int(uid)
        actor.level = int(_LOCAL_DEFAULT_ACTOR_TEMPLATE.get("local_test_level", 1))
        actor.cur_exp = 0
        actor.star = int(_LOCAL_DEFAULT_ACTOR_TEMPLATE.get("local_test_star", 1))
        observed = _ACTOR_INFO.get(int(actor_id), {})
        actor.quality = int(observed.get("quality", _LOCAL_DEFAULT_ACTOR_TEMPLATE.get("local_test_quality", 1)))
        actor.actor_skin = 0
        actor.default_index = int(index)
        actor.is_normal = True
        actor.is_new = True
        actor.is_new_card = True
        skills = _LOCAL_DEFAULT_ACTOR_TEMPLATE.get("local_test_skills", [])
        if isinstance(skills, list):
            for skill_id in skills:
                skill = actor.skills.add()
                skill.id = int(skill_id)
                skill.level = 1
                skill.is_read = False
        attrs: Any = observed.get("attrs")
        if not isinstance(attrs, list) or not attrs:
            attrs = _LOCAL_DEFAULT_ACTOR_TEMPLATE.get("local_test_attributes", {})
        if isinstance(attrs, Mapping):
            attrs = [
                {"type": attr_type, "value": value, "isRatio": False}
                for attr_type, value in attrs.items()
            ]
        if isinstance(attrs, list):
            for item in attrs:
                if not isinstance(item, Mapping):
                    continue
                attr = actor.attrs.add()
                attr.type = int(item.get("type", 0))
                attr.value = int(item.get("value", 0))
                attr.is_ratio = bool(item.get("isRatio", item.get("is_ratio", False)))

    def login_messages(self, account: Mapping[str, Any]) -> List[Message]:
        """Return the exact bootstrap push message names and protobuf bytes."""

        profile = self._profile(account)
        now_ms = self._now() * 1000
        messages: list[Message] = []

        begin = self._types["ScLoginBegin"](
            player_id=str(profile["player_id"]),
            social_picture="",
            utc_offset_seconds=0,
            time_ms_server=now_ms,
        )
        messages.append(("ScLoginBegin", begin.SerializeToString()))
        tutorial = self._types["ScLoginTutorial"]()
        for tutorial_id in _LOCAL_TUTORIAL_IDS:
            entry = tutorial.tutorial_info.add()
            entry.id = tutorial_id
            entry.sequence = int(_LOCAL_TUTORIAL_SEQUENCE.get(tutorial_id, tutorial_id))
            entry.status = int(profile["tutorials"].get(str(tutorial_id), 0))
        messages.append(("ScLoginTutorial", tutorial.SerializeToString()))

        actors = self._types["DBGamePlayer.Actors"]()
        actors.unlocked_skins.append(0)
        actor_ids = profile.get("actor_ids") or []
        if not actor_ids and profile["actor_id"] is not None:
            actor_ids = [profile["actor_id"]]
        # LocalSystems owns sandbox gacha/actor state.  Include newly drawn
        # actors and their level/star progress in the next login bootstrap so
        # a reconnect reflects local gameplay rather than resetting the view.
        try:
            system_actors = self.systems._state(profile).get("actors", {})
            if isinstance(system_actors, Mapping):
                actor_ids = list(dict.fromkeys([int(value) for value in actor_ids] + [int(key) for key in system_actors if str(key).isdigit()]))
        except Exception:
            system_actors = {}
        for index, actor_id in enumerate(actor_ids):
            uid = index + 1
            self._append_local_actor(actors, int(actor_id), uid, index)
            stored_actor = system_actors.get(str(actor_id), {}) if isinstance(system_actors, Mapping) else {}
            if isinstance(stored_actor, Mapping):
                actors.player_actors[-1].level = int(stored_actor.get("level", actors.player_actors[-1].level))
                actors.player_actors[-1].star = int(stored_actor.get("star", actors.player_actors[-1].star))
                actors.player_actors[-1].cur_exp = int(stored_actor.get("exp", actors.player_actors[-1].cur_exp))
            actors.actor_id_map[int(actor_id)] = uid
        messages.append(("DBGamePlayer.Actors", actors.SerializeToString()))

        equips = self._types["DBGamePlayer.EquipPackage"]()
        messages.append(("DBGamePlayer.EquipPackage", equips.SerializeToString()))
        items = self._types["DBGamePlayer.ItemPackage"]()
        messages.append(("DBGamePlayer.ItemPackage", items.SerializeToString()))

        end = self._types["ScLoginEnd"]()
        end.base_info.level = int(profile["level"])
        end.base_info.name = str(profile["name"])
        end.base_info.home_back_ground.current = int(profile["scene_id"])
        end.base_info.home_back_ground.is_random = bool(profile["scene_random"])
        for resource in self._resource_message(profile):
            entry = end.base_resource.add()
            for field in ("type", "id", "count", "param"):
                if field in resource:
                    setattr(entry, field, int(resource[field]))
        messages.append(("ScLoginEnd", end.SerializeToString()))
        return messages

    def _chapter_result_message(self, profile: Mapping[str, Any], *, compact: bool = True):
        """Build the real typed ``ApiChapterInfo.result`` protobuf payload."""

        message = self._types["ApiChapterInfo.result"]()
        # ParseDict performs the schema conversion, including converting the
        # JSON-looking map keys ("1", "1001", "2011", ...) to uint32 map
        # keys.  It also rejects accidental fields instead of silently
        # inventing a response shape.
        json_format.ParseDict(self.dungeons.chapter_snapshot(profile, compact=compact), message)
        return message

    def _chapter_detail_message(self, profile: Mapping[str, Any], chapter_id: int):
        """Build the typed ``ApiChapterInfo.get`` payload used by red points."""

        message = self._types["ApiChapterInfo.get"]()
        json_format.ParseDict(self.dungeons.chapter_detail(profile, chapter_id), message)
        return message

    def _handle_http_unlocked(
        self,
        method: str,
        path: str,
        body: Body = None,
        content_type: Optional[str] = None,
        authorization: Optional[str] = None,
    ) -> Optional[Response]:
        """Handle the smallest post-login HTTP profile surface.

        Unknown paths return ``None`` for the existing fixture router.  The
        returned dictionaries are raw JSON objects; the parent server adds the
        original client's RestfulResponse envelope.
        """

        route = _route(path)
        routes = {
            "/fci/login/": "login",
            "/fci/guild-player/": "guild",
            "/fci/dungeon/chapter/": "dungeon",
            "/fci/applylist/": "applylist",
        }
        action = routes.get(route)
        # Chapter details are a separate REST resource from the chapter
        # summary.  The client reads these paths while binding red points,
        # and expects the typed ``ApiChapterInfo.get`` response envelope.
        if action is None and route.startswith("/fci/dungeon/chapter/"):
            chapter_id = route[len("/fci/dungeon/chapter/") :].strip("/")
            if chapter_id.isdigit():
                action = "dungeon"
        if action is None:
            # Leave non-FCI paths (patch/clientupdate/fixtures) to the parent
            # fixture router; authenticating them here would turn them into
            # a misleading 401 before a fixture can answer.
            if not route.startswith("/fci/"):
                return None
            # Entering routes are authenticated with the same local access
            # token, then delegated to the evidence-bounded entering module.
            account, error = self._authorized(authorization)
            if error is not None:
                return error
            assert account is not None
            profile = self._profile(account)
            economy_profile = dict(profile)
            economy_profile["account"] = account
            events_result = self.events.handle_http(method, path, body, profile)
            if events_result is not None:
                return events_result
            social_result = self.social.handle_http(method, path, body, profile)
            if social_result is not None:
                return social_result
            realtime_result = self.realtime_pvp.handle_http(method, path, body, profile)
            if realtime_result is not None:
                return realtime_result
            systems_result = self.systems.handle_http(method, path, body, profile)
            if systems_result is not None:
                return systems_result
            # Profile features fills the notice/web-activity seams that are
            # outside LocalSystems' player profile implementation.
            profile_result = self.profile_features.handle_http(method, path, body, profile)
            if profile_result is not None:
                return profile_result
            economy_result = self.economy.handle_http(method, path, body, economy_profile)
            if economy_result is not None:
                return economy_result
            auto_fight_result = self._auto_fight_http(method, path, body, profile)
            if auto_fight_result is not None:
                return auto_fight_result
            tutorial_result = self._tutorial_http(method, path, body, profile)
            if tutorial_result is not None:
                return tutorial_result
            dungeon_result = self.dungeons.handle_http(method, path, body, profile)
            if dungeon_result is not None:
                return dungeon_result
            return handle_entering_http(method, path, profile)

        account, error = self._authorized(authorization)
        if error is not None:
            return error
        assert account is not None
        profile = self._profile(account)
        economy_profile = dict(profile)
        economy_profile["account"] = account
        events_result = self.events.handle_http(method, path, body, profile)
        if events_result is not None:
            return events_result
        social_result = self.social.handle_http(method, path, body, profile)
        if social_result is not None:
            return social_result
        realtime_result = self.realtime_pvp.handle_http(method, path, body, profile)
        if realtime_result is not None:
            return realtime_result
        systems_result = self.systems.handle_http(method, path, body, profile)
        if systems_result is not None:
            return systems_result
        profile_result = self.profile_features.handle_http(method, path, body, profile)
        if profile_result is not None:
            return profile_result
        economy_result = self.economy.handle_http(method, path, body, economy_profile)
        if economy_result is not None:
            return economy_result
        method = method.upper()
        if action == "login":
            if method != "POST":
                return 405, {"error": "method_not_allowed", "message": "POST required"}
            # The Lua callback ignores this response body.  Return an empty
            # local object rather than claiming a remote operation succeeded.
            return 200, {}
        if action == "dungeon":
            # Keep the chapter route in the dungeon module so the exact same
            # local chapter graph is used by direct dungeon requests and the
            # post-login PushService request.
            if route == "/fci/dungeon/chapter/" and method == "GET":
                # Keep the compact graph used by the original bootstrap.  A
                # per-chapter detail request exposes later configured rows.
                return 200, self._chapter_result_message(profile, compact=True)
            if route.startswith("/fci/dungeon/chapter/") and method == "GET":
                chapter_id = route[len("/fci/dungeon/chapter/") :].strip("/")
                if chapter_id.isdigit():
                    return 200, self._chapter_detail_message(profile, int(chapter_id))
            result = self.dungeons.handle_http(method, path, body, profile)
            if result is not None:
                return result
            return 501, {"error": "dungeon_route_not_implemented"}
        if method != "GET":
            return 405, {"error": "method_not_allowed", "message": "GET required"}
        if action == "guild":
            return 200, {
                "guildId": 0,
                "type": 0,
                "rentActor": 0,
                "rentedActors": {},
                "limitEndTime": 0,
                "donateLimitEndTime": 0,
                "guildDungeonLimitEndTime": 0,
                "guildScoreRecord": 0,
            }
        return 200, []

    def handle_http(
        self,
        method: str,
        path: str,
        body: Body = None,
        content_type: Optional[str] = None,
        authorization: Optional[str] = None,
    ) -> Optional[Response]:
        """Serialize one authenticated dispatch across all local modules.

        HTTP handlers can be called concurrently by ``ThreadingHTTPServer``.
        Holding the per-profile/process lock for the complete dispatch keeps
        the read-modify-write resource ledger and the adjacent JSON state
        updates atomic, while the underlying modules continue to use the same
        re-entrant lock for direct unit-test calls.
        """

        with self._lock:
            return self._handle_http_unlocked(method, path, body, content_type, authorization)


__all__ = ["LocalGame", "Message"]

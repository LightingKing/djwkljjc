"""Configuration-backed dungeon metadata for the local compatibility server.

The extracted JSON tables are runtime samples.  This loader exposes both the
rows available in the checkout and their completeness metadata so gameplay
code can use reviewed rows without claiming that a partial export is the full
retired server catalog.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Mapping


@dataclass(frozen=True)
class DungeonConfig:
    chapter_rows: tuple[Mapping[str, Any], ...]
    reward_rows: tuple[Mapping[str, Any], ...]
    chapter_observed_count: int
    reward_observed_count: int
    chapter_source: str
    reward_source: str
    fallback_used: bool = False

    @property
    def chapter_complete(self) -> bool:
        return self.chapter_observed_count <= len(self.chapter_rows)

    @property
    def reward_complete(self) -> bool:
        return self.reward_observed_count <= len(self.reward_rows)

    @property
    def all_normal_ids(self) -> tuple[int, ...]:
        values: set[int] = set()
        for row in self.chapter_rows:
            if int(row.get("type", 0) or 0) != 2:
                continue
            for value in row.get("dungeonId", []) or []:
                try:
                    values.add(int(value))
                except (TypeError, ValueError):
                    continue
        return tuple(sorted(values))

    @property
    def supported_normal_ids(self) -> tuple[int, ...]:
        """Return the first configured chapter that has a complete row.

        The current export contains chapter rows 1-6 but the table metadata
        says 35 rows were observed.  The local UI therefore advertises the
        first chapter (the only chapter whose resources are verified by the
        existing smoke flow) while keeping ``all_normal_ids`` available for
        later expansion once the full export is recovered.
        """
        if self.chapter_rows:
            first = min(self.chapter_rows, key=lambda row: int(row.get("chapterIndex", row.get("chapterId", 1)) or 1))
            ids = tuple(sorted({int(value) for value in first.get("dungeonId", []) or []}))
            if ids:
                return ids
        return (1, 2, 3, 4, 5, 6, 7, 8)

    @property
    def story_ids(self) -> tuple[int, ...]:
        ids: set[int] = set()
        for row in self.reward_rows:
            value = row.get("dungeonId")
            try:
                dungeon_id = int(value)
            except (TypeError, ValueError):
                continue
            if dungeon_id in (2011, 2012, 2013):
                ids.add(dungeon_id)
        return tuple(sorted(ids)) or (2011, 2012, 2013)

    def reward_row(self, dungeon_id: int) -> Mapping[str, Any] | None:
        target = int(dungeon_id)
        for row in self.reward_rows:
            try:
                if int(row.get("dungeonId")) == target:
                    return row
            except (TypeError, ValueError):
                continue
        return None

    def provenance(self) -> dict[str, Any]:
        return {
            "chapterSource": self.chapter_source,
            "chapterObservedCount": self.chapter_observed_count,
            "chapterRowCount": len(self.chapter_rows),
            "chapterComplete": self.chapter_complete,
            "rewardSource": self.reward_source,
            "rewardObservedCount": self.reward_observed_count,
            "rewardRowCount": len(self.reward_rows),
            "rewardComplete": self.reward_complete,
            "fallbackUsed": self.fallback_used,
        }


def _read_table(path: Path) -> tuple[tuple[Mapping[str, Any], ...], int, str, bool]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("table root is not an object")
        rows = payload.get("rows", [])
        if not isinstance(rows, list):
            raise ValueError("table rows is not a list")
        records = tuple(row for row in rows if isinstance(row, Mapping))
        observed = int(payload.get("observedCount", len(records)))
        source = str((payload.get("sourceFiles") or [str(path)])[0])
        return records, observed, source, False
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return (), 0, str(path), True


def load_dungeon_config(root: str | Path | None = None) -> DungeonConfig:
    base = Path(root) if root is not None else Path(__file__).resolve().parents[2]
    chapter_path = base / "data" / "config" / "ChapterInfo.json"
    reward_path = base / "data" / "config" / "DungeonReward.json"
    chapter_rows, chapter_count, chapter_source, chapter_fallback = _read_table(chapter_path)
    reward_rows, reward_count, reward_source, reward_fallback = _read_table(reward_path)
    return DungeonConfig(
        chapter_rows=chapter_rows,
        reward_rows=reward_rows,
        chapter_observed_count=chapter_count,
        reward_observed_count=reward_count,
        chapter_source=chapter_source,
        reward_source=reward_source,
        fallback_used=chapter_fallback or reward_fallback,
    )


__all__ = ["DungeonConfig", "load_dungeon_config"]

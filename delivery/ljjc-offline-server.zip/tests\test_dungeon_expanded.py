from __future__ import annotations

import json
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

from accounts import LocalAccounts
from dungeon import ALL_NORMAL_DUNGEON_IDS, DUNGEON_CONFIG
from game import LocalGame
try:
    from tests.test_dungeon import DungeonTests
except ModuleNotFoundError:  # unittest discover adds tests/ directly to sys.path
    from test_dungeon import DungeonTests


class ExpandedDungeonTests(unittest.TestCase):
    def _setup(self):
        temp = tempfile.TemporaryDirectory()
        root = Path(temp.name)
        accounts = LocalAccounts(root / "accounts")
        game = LocalGame(root / "game", accounts)
        account = DungeonTests._guest_account(accounts)
        with closing(accounts._connect()) as connection:
            token = connection.execute(
                "SELECT access_token FROM accounts WHERE account_id = ?",
                (account["accountId"],),
            ).fetchone()[0]
        return temp, game, "Token " + token

    def test_configured_later_chapter_stage_is_playable(self):
        temp, game, auth = self._setup()
        try:
            request = game._types["ApiDungeon"]()
            request.dungeon_id = 9  # ChapterInfo chapter 2, first stage.
            status, entered = game.handle_http(
                "POST", "/fci/dungeon/", request.SerializeToString(), "application/wireformat", auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(entered["baseInfo"]["dungeonId"], 9)
            self.assertEqual(entered["baseInfo"]["dungeonType"], 2)
            active = game._types["FightActiveData"]()
            active.dungeonType = 2
            active.stageID = 9
            active.gameRound = 2
            active.winTeam = 1
            self.assertEqual(
                game.handle_http(
                    "PATCH", f"/fci/dungeon/{entered['dungeonUid']}/active/",
                    active.SerializeToString(), "application/wireformat", auth,
                ),
                (200, {}),
            )
            status, result = game.handle_http(
                "POST", f"/fci/dungeon/{entered['dungeonUid']}/balance",
                json.dumps({"stars": 2, "targetsDone": [1, 3]}).encode(),
                "application/json", auth,
            )
            self.assertEqual(status, 200)
            self.assertEqual(result["dungeonId"], 9)
            self.assertEqual(result["stars"], 2)
            self.assertEqual(result["balanceInfo"]["targetsDone"], [1, 3])
            self.assertEqual(result["balanceInfo"]["difficulty"], "normal")
        finally:
            temp.cleanup()

    def test_hard_mode_persists_and_full_chapter_graph_is_typed(self):
        temp, game, auth = self._setup()
        try:
            status, entered = game.handle_http(
                "POST", "/fci/dungeon/", json.dumps({"dungeonId": 10, "difficulty": "hard"}).encode(),
                "application/json", auth,
            )
            self.assertEqual(status, 200)
            self.assertTrue(entered["baseInfo"]["isChallengeMode"])
            self.assertEqual(entered["baseInfo"]["difficulty"], "hard")
            status, chapter = game.handle_http("GET", "/fci/dungeon/chapter/2", b"", "application/wireformat", auth)
            self.assertEqual(status, 200)
            self.assertEqual(chapter.record_chapter.chapter_id, 2)
            self.assertIn(9, chapter.record_dungeons)
        finally:
            temp.cleanup()

    def test_every_observed_chapter_stage_is_enterable(self):
        """All IDs present in ChapterInfo are exposed through the local seam.

        ChapterInfo is still marked partial, so this does not claim the
        missing historical rows were recovered.  It prevents a regression
        where the server silently falls back to the first chapter and makes
        the observed later chapters unreachable.
        """

        temp, game, auth = self._setup()
        try:
            self.assertEqual(len(DUNGEON_CONFIG.chapter_rows), 6)
            self.assertGreaterEqual(len(ALL_NORMAL_DUNGEON_IDS), 80)
            for dungeon_id in ALL_NORMAL_DUNGEON_IDS:
                status, payload = game.handle_http(
                    "POST",
                    "/fci/dungeon/",
                    json.dumps({"dungeonId": int(dungeon_id)}).encode(),
                    "application/json",
                    auth,
                )
                self.assertEqual(status, 200, dungeon_id)
                self.assertEqual(payload["baseInfo"]["dungeonId"], int(dungeon_id))
                self.assertEqual(payload["baseInfo"]["dungeonType"], 2)
        finally:
            temp.cleanup()

    def test_stage_metadata_exposes_only_captured_enemy_rows(self):
        """The partial DungeonMonster export must remain explicit at runtime."""

        temp, game, auth = self._setup()
        try:
            status, stage = game.handle_http(
                "GET", "/fci/dungeon/stage/1", b"", "application/json", auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(stage["status"], "configured")
            self.assertEqual(stage["dungeonId"], 1)
            self.assertEqual(stage["monsterId"], [3004001, 3003001, 1008005, 4001098, 0, 0])
            self.assertEqual(stage["completeness"], "partial")

            status, missing = game.handle_http(
                "GET", "/fci/dungeon/stage/9", b"", "application/json", auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(missing["status"], "unavailable")
            self.assertEqual(missing["dungeonId"], 9)

            status, entered = game.handle_http(
                "POST", "/fci/dungeon/", json.dumps({"dungeonId": 1}).encode(), "application/json", auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(entered["baseInfo"]["stageMetadata"]["status"], "configured")
            self.assertEqual(entered["baseInfo"]["stageMetadata"]["source"], "data/config/DungeonMonster.json")
        finally:
            temp.cleanup()

    def test_story_metadata_exposes_captured_rows_without_claiming_full_story(self):
        """StoryDungeon evidence is queryable but stays separate from rewards."""

        temp, game, auth = self._setup()
        try:
            status, story = game.handle_http(
                "GET", "/fci/dungeon/story/1001", b"", "application/json", auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(story["status"], "configured")
            self.assertEqual(story["dungeonId"], 1001)
            self.assertEqual(story["monsterId"], [1002309, 0, 0, 2012098, 2014098, 2108098])
            self.assertEqual(story["level"], [1, 1, 1, 1, 1, 1])
            self.assertEqual(story["source"], "data/config/StoryDungeon.json")
            self.assertEqual(story["completeness"], "partial")

            status, missing = game.handle_http(
                "GET", "/fci/dungeon/story/1005", b"", "application/json", auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(missing["status"], "unavailable")
            self.assertEqual(missing["dungeonId"], 1005)

            status, method_error = game.handle_http(
                "POST", "/fci/dungeon/story/1001", b"{}", "application/json", auth
            )
            self.assertEqual(status, 405)
            self.assertEqual(method_error["error"], "method_not_allowed")
        finally:
            temp.cleanup()


if __name__ == "__main__":
    unittest.main()

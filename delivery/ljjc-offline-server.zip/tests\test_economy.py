from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
import sys

from google.protobuf import message_factory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from accounts import LocalAccounts
from game import LocalGame
from server.core.clock import ServerClock


class EconomyRoutesTests(unittest.TestCase):
    @staticmethod
    def _guest(accounts: LocalAccounts) -> tuple[dict, str]:
        first = accounts.handle("POST", "/AccountSession/", b"", "application/wireformat")
        account_token = "AccountToken " + first[1]["accountToken"]
        entry = accounts.handle(
            "POST", "/EntryReg/", b'{"entryType":"guest"}', "application/json", account_token
        )[1]["entry"]["entry"]
        accounts.handle("POST", "/Account/", b'{"entryType":"guest"}', "application/json", account_token)
        second = accounts.handle("POST", "/AccountSession/", b"", "application/wireformat")
        second_token = "AccountToken " + second[1]["accountToken"]
        auth_body = b"\x0a" + bytes((len(entry),)) + entry.encode() + b"\x12\x05guest"
        auth = accounts.handle("POST", "/Auth/", auth_body, "application/wireformat", second_token)
        account = accounts.verify_access_token(auth[1]["tokenAccess"])
        assert account is not None
        with closing(accounts._connect()) as connection:
            token = connection.execute(
                "SELECT access_token FROM accounts WHERE account_id = ?", (account["accountId"],)
            ).fetchone()[0]
        return account, "Token " + token

    def test_shop_purchase_spends_gold_and_persists(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, auth = self._guest(accounts)
            status, shops = game.handle_http("GET", "/fci/Shop", authorization=auth)
            self.assertEqual(status, 200)
            self.assertEqual(shops.DESCRIPTOR.full_name, "ApiShop.result")
            self.assertEqual(shops.base_info.shopId, 1)
            status, goods = game.handle_http("GET", "/fci/Shop/1/Goods", authorization=auth)
            self.assertEqual(status, 200)
            self.assertEqual(goods.DESCRIPTOR.full_name, "ApiShopGoods.get")
            self.assertEqual(goods.get[0].shopGoodId, 10001)
            status, result = game.handle_http(
                "POST",
                "/fci/ShopTrade/",
                json.dumps({"shopId": 1, "shopGoodId": 10001}).encode(),
                "application/json",
                auth,
            )
            self.assertEqual(status, 200)
            self.assertEqual(result.DESCRIPTOR.full_name, "ApiShopTrade.result")
            self.assertEqual(result.buy_count, 1)
            self.assertEqual(result.res_change[0].base_res.count_delta, -1000)
            profile = game._profile(account)
            self.assertEqual(next(r["count"] for r in profile["resources"] if r["type"] == 7), 19000)
            self.assertEqual(
                next(r["count"] for r in profile["resources"] if r["type"] == 11 and r["id"] == 20001),
                1,
            )
            game_again = LocalGame(root / "game", accounts)
            status, goods_again = game_again.handle_http("GET", "/fci/Shop/1/Goods", authorization=auth)
            self.assertEqual(status, 200)
            self.assertEqual(goods_again.get[0].buy_count_record, 1)

    def test_shop_goods_post_refresh_uses_descriptor_and_local_cost(self):
        """M4.7 refresh is a typed local mutation with an auditable cost."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, auth = self._guest(accounts)
            shop_cls = message_factory.GetMessageClass(
                game._pool.FindMessageTypeByName("ApiShopGoods")
            )
            request = shop_cls(refresh_free=False)
            status, result = game.handle_http(
                "POST",
                "/fci/Shop/1/Goods",
                request.SerializeToString(),
                "application/wireformat",
                auth,
            )
            self.assertEqual(status, 200)
            self.assertEqual(result.DESCRIPTOR.full_name, "ApiShopGoods.post")
            self.assertEqual(result.refresh_count, 1)
            self.assertEqual(len(result.info), 3)
            self.assertEqual(result.res_change[0].base_res.count_delta, -10000)
            game_again = LocalGame(root / "game", accounts)
            status, shop = game_again.handle_http(
                "GET", "/fci/Shop", authorization=auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(shop.refresh_count, 1)

    def test_shop_get_applies_overdue_daily_refresh(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            now = [1_800_000_000]
            clock = ServerClock(source=lambda: now[0])
            accounts = LocalAccounts(root / "accounts", clock=clock.now)
            game = LocalGame(root / "game", accounts, clock=clock.now)
            account, auth = self._guest(accounts)
            status, _trade = game.handle_http(
                "POST",
                "/fci/ShopTrade/",
                b'{"shopId":1,"shopGoodId":10001}',
                "application/json",
                auth,
            )
            self.assertEqual(status, 200)
            status, before = game.handle_http(
                "GET", "/fci/Shop/1/Goods", authorization=auth
            )
            self.assertEqual((status, before.get[0].buy_count_record), (200, 1))
            # Force the persisted boundary into the past while keeping the
            # account session valid; the server clock still drives the
            # refresh decision.
            state = game.economy._state({"accountId": account["accountId"]})
            state["shop"][0]["nextRefreshTime"] = now[0] - 1
            game.economy._save_state({"accountId": account["accountId"]}, state)
            now[0] += 1
            status, after = game.handle_http(
                "GET", "/fci/Shop/1/Goods", authorization=auth
            )
            self.assertEqual((status, after.get[0].buy_count_record), (200, 0))
            status, shop = game.handle_http("GET", "/fci/Shop", authorization=auth)
            self.assertEqual(status, 200)
            self.assertEqual(shop.refresh_count, 1)

    def test_shop_free_refresh_is_available_once_per_local_day(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            _account, auth = self._guest(accounts)
            status, free = game.handle_http(
                "POST", "/fci/Shop/1/Goods", b'{"refreshFree":true}', "application/json", auth
            )
            self.assertEqual(status, 200)
            self.assertEqual(len(free.res_change), 0)
            status, duplicate = game.handle_http(
                "POST", "/fci/Shop/1/Goods", b'{"refreshFree":true}', "application/json", auth
            )
            self.assertEqual((status, duplicate["error"]), (409, "shop_free_refresh_unavailable"))

    def test_resource_batch_rejects_duplicate_costs_atomically(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, _auth = self._guest(accounts)
            profile = game._profile(account)
            before = next(item["count"] for item in profile["resources"] if item["type"] == 7)
            ok, changes, error = game.economy._change_resources(
                profile,
                [
                    {"type": 7, "id": 0, "param": 0, "count": -(before // 2)},
                    {"type": 7, "id": 0, "param": 0, "count": -(before // 2 + 1)},
                ],
            )
            self.assertFalse(ok)
            self.assertEqual((changes, error), ([], "insufficient_resource"))
            after = next(item["count"] for item in game._profile(account)["resources"] if item["type"] == 7)
            self.assertEqual(after, before)

    def test_mall_info_and_trade_are_persistent_and_grant_the_good(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, auth = self._guest(accounts)
            status, info = game.handle_http("GET", "/fci/mall-info/", authorization=auth)
            self.assertEqual((status, info.DESCRIPTOR.full_name), (200, "ApiMallInfo.result"))
            status, trade = game.handle_http(
                "POST",
                "/fci/mall-trade/",
                json.dumps({"id": 1}).encode(),
                "application/json",
                auth,
            )
            self.assertEqual((status, trade.DESCRIPTOR.full_name), (200, "ApiMallTrade.result"))
            self.assertEqual(trade.buy_count, 1)
            profile = game._profile(account)
            self.assertEqual(next(r["count"] for r in profile["resources"] if r["type"] == 7), 19000)
            self.assertEqual(
                next(r["count"] for r in profile["resources"] if r["type"] == 11 and r["id"] == 20001),
                1,
            )
            game_again = LocalGame(root / "game", accounts)
            status, info_again = game_again.handle_http("GET", "/fci/mall-info/", authorization=auth)
            self.assertEqual(status, 200)
            self.assertEqual(info_again.mall_record.summary[1].buy_count, 1)

    def test_recharge_model_sandbox_routes_cover_local_rewards_without_real_payment(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, auth = self._guest(accounts)

            status, info = game.handle_http("GET", "/fci/recharge/info/", authorization=auth)
            self.assertEqual(status, 200)
            self.assertTrue(info["sandbox"])
            self.assertGreaterEqual(len(info["fixedRechargeInfo"]), 3)

            status, checked = game.handle_http(
                "POST", "/fci/recharge/before-buy-check/", b'{"rechargeId":11}', "application/json", auth
            )
            self.assertEqual((status, checked["sandbox"]), (200, True))
            status, free = game.handle_http(
                "POST", "/fci/recharge/free/", b'{"rechargeId":11}', "application/json", auth
            )
            self.assertEqual((status, free["sandbox"]), (200, True))

            status, voucher = game.handle_http(
                "POST", "/fci/recharge/voucher/", b'{"rechargeId":51}', "application/json", auth
            )
            self.assertEqual(status, 200)
            status, duplicate = game.handle_http(
                "POST", "/fci/recharge/voucher/", b'{"rechargeId":51}', "application/json", auth
            )
            self.assertEqual((status, duplicate["error"]), (409, "recharge_reward_already_claimed"))

            for path, body in (
                ("/fci/recharge/gift-box/", {"giftboxId": 4005}),
                ("/fci/recharge/first-reward/", {}),
                ("/fci/recharge/month-card/reward/", {"monthCardCfgId": 1}),
                ("/fci/recharge/permit/buy-level/", {"permitId": 1, "level": 1}),
                ("/fci/recharge/permit/task-reward/", {"permitId": 1, "level": 1}),
                ("/fci/recharge/permit/level-reward/", {"permitId": 1, "level": 1}),
                ("/fci/recharge/platform-active-code/", {"code": "LOCAL-TEST-1"}),
            ):
                status, payload = game.handle_http(
                    "POST", path, json.dumps(body).encode(), "application/json", auth
                )
                self.assertEqual(status, 200, (path, payload))
                self.assertTrue(payload["sandbox"])

            status, duplicate_gift = game.handle_http(
                "POST", "/fci/recharge/gift-box/", b'{"giftboxId":4005}', "application/json", auth
            )
            self.assertEqual((status, duplicate_gift["error"]), (409, "recharge_reward_already_claimed"))

            paid = next(r["count"] for r in game._profile(account)["resources"] if r["type"] == 5)
            self.assertGreaterEqual(paid, 60 + 300 + 300 + 60 + 30 + 50 + 50 + 100)

    def test_concurrent_one_time_voucher_claim_is_serialized(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, auth = self._guest(accounts)

            def claim():
                return game.handle_http(
                    "POST", "/fci/recharge/voucher/", b'{"rechargeId":51}', "application/json", auth
                )[0]

            with ThreadPoolExecutor(max_workers=8) as pool:
                statuses = list(pool.map(lambda _index: claim(), range(8)))
            self.assertEqual(statuses.count(200), 1)
            self.assertEqual(statuses.count(409), 7)
            paid = next(r["count"] for r in game._profile(account)["resources"] if r["type"] == 5)
            self.assertEqual(paid, 300)

    def test_concurrent_claims_from_two_game_instances_are_serialized(self):
        """A hot reload must not reopen the same store with a private lock."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            account, auth = self._guest(accounts)
            game_a = LocalGame(root / "game", accounts)
            game_b = LocalGame(root / "game", accounts)
            game_a._profile(account)

            def claim(game):
                return game.handle_http(
                    "POST", "/fci/recharge/voucher/", b'{"rechargeId":51}',
                    "application/json", auth
                )[0]

            with ThreadPoolExecutor(max_workers=2) as pool:
                statuses = list(pool.map(claim, (game_a, game_b)))
            self.assertEqual(statuses.count(200), 1)
            self.assertEqual(statuses.count(409), 1)
            paid = next(r["count"] for r in game_a._profile(account)["resources"] if r["type"] == 5)
            self.assertEqual(paid, 300)

    def test_recharge_uses_one_time_local_sandbox_token(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, auth = self._guest(accounts)
            body = json.dumps({"productId": "local.sandbox.60", "count": 1}).encode()
            status, touch = game.handle_http("POST", "/fci/purchasetouch", body, "application/json", auth)
            self.assertEqual(status, 200)
            self.assertEqual(touch.DESCRIPTOR.full_name, "ApiPurchaseTouchProduct.result")
            self.assertTrue(touch.is_sandbox)
            token = touch.trade_data
            status, rejected = game.handle_http(
                "POST", "/fci/purchasedelevery", b'{"transactionReceipt":"remote-receipt"}', "application/json", auth
            )
            self.assertEqual(status, 402)
            self.assertEqual(rejected["error"], "payment_verification_required")
            status, delivered = game.handle_http(
                "POST",
                "/fci/purchasedelevery",
                json.dumps({"tradeData": token}).encode(),
                "application/json",
                auth,
            )
            self.assertEqual(status, 200)
            self.assertEqual(delivered.DESCRIPTOR.full_name, "ApiPurchaseDelevery.result")
            self.assertTrue(delivered.transaction_id)
            paid = next(r["count"] for r in game._profile(account)["resources"] if r["type"] == 5)
            self.assertEqual(paid, 60)
            status, duplicate = game.handle_http(
                "POST",
                "/fci/purchasedelevery",
                json.dumps({"tradeData": token}).encode(),
                "application/json",
                auth,
            )
            self.assertEqual(status, 402)
            self.assertEqual(duplicate["error"], "payment_verification_required")

    def test_admin_billing_snapshot_lists_delivery_without_tokens(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, auth = self._guest(accounts)
            body = json.dumps({"productId": "local.sandbox.60", "count": 1}).encode()
            status, touch = game.handle_http("POST", "/fci/purchasetouch", body, "application/json", auth)
            self.assertEqual(status, 200)
            token = touch.trade_data
            snapshot = game.economy.admin_billing_snapshot()
            self.assertEqual(snapshot["pendingOrderCount"], 1)
            self.assertNotIn(token, json.dumps(snapshot, ensure_ascii=False))
            status, delivered = game.handle_http(
                "POST", "/fci/purchasedelevery", json.dumps({"tradeData": token}).encode(), "application/json", auth
            )
            self.assertEqual(status, 200)
            snapshot = game.economy.admin_billing_snapshot()
            self.assertEqual(snapshot["pendingOrderCount"], 0)
            self.assertEqual(snapshot["totalRecords"], 1)
            self.assertEqual(snapshot["records"][0]["productId"], "local.sandbox.60")
            self.assertEqual(snapshot["records"][0]["transactionId"], delivered.transaction_id)

    def test_native_wireformat_shop_and_sandbox_purchase_requests_are_accepted(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            accounts = LocalAccounts(root / "accounts")
            game = LocalGame(root / "game", accounts)
            account, auth = self._guest(accounts)

            shop_cls = message_factory.GetMessageClass(
                game._pool.FindMessageTypeByName("ApiShopTrade")
            )
            trade = shop_cls(shop_id=1, index=0)
            trade.info.shopGoodId = 10001
            status, shop_result = game.handle_http(
                "POST",
                "/fci/ShopTrade/",
                trade.SerializeToString(),
                "application/wireformat",
                auth,
            )
            self.assertEqual(status, 200)
            self.assertEqual(shop_result.DESCRIPTOR.full_name, "ApiShopTrade.result")
            self.assertEqual(shop_result.buy_count, 1)

            touch_cls = message_factory.GetMessageClass(
                game._pool.FindMessageTypeByName("ApiPurchaseTouchProduct")
            )
            touch = touch_cls(product_id="local.sandbox.60", count=1)
            status, pending = game.handle_http(
                "POST",
                "/fci/purchasetouch/",
                touch.SerializeToString(),
                "application/wireformat",
                auth,
            )
            self.assertEqual(status, 200)
            self.assertEqual(pending.DESCRIPTOR.full_name, "ApiPurchaseTouchProduct.result")

            delivery_cls = message_factory.GetMessageClass(
                game._pool.FindMessageTypeByName("ApiPurchaseDelevery")
            )
            delivery = delivery_cls(trade_data=pending.trade_data)
            status, delivered = game.handle_http(
                "POST",
                "/fci/purchasedelevery/",
                delivery.SerializeToString(),
                "application/wireformat",
                auth,
            )
            self.assertEqual(status, 200)
            self.assertEqual(delivered.DESCRIPTOR.full_name, "ApiPurchaseDelevery.result")
            self.assertTrue(delivered.transaction_id)

    def test_month_card_uses_configured_six_am_reset_bucket(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            now = [1767247140]  # 2026-01-01 05:59 UTC
            clock = ServerClock(source=lambda: now[0])
            accounts = LocalAccounts(root / "accounts", clock=clock.now)
            game = LocalGame(root / "game", accounts, clock=clock.now)
            game.daily_key = lambda value=None: clock.daily_key(value, refresh_at="06:00:00")
            account, auth = self._guest(accounts)

            status, _first = game.handle_http(
                "POST", "/fci/recharge/month-card/reward/", b'{"monthCardCfgId":1}', "application/json", auth
            )
            self.assertEqual(status, 200)
            status, duplicate = game.handle_http(
                "POST", "/fci/recharge/month-card/reward/", b'{"monthCardCfgId":1}', "application/json", auth
            )
            self.assertEqual((status, duplicate["error"]), (409, "month_card_reward_already_claimed"))

            now[0] += 60
            status, _second = game.handle_http(
                "POST", "/fci/recharge/month-card/reward/", b'{"monthCardCfgId":1}', "application/json", auth
            )
            self.assertEqual(status, 200)
            paid = next(item["count"] for item in game._profile(account)["resources"] if item["type"] == 5)
            self.assertEqual(paid, 60)


if __name__ == "__main__":
    unittest.main()
